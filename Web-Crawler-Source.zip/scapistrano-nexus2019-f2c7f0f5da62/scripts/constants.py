#coding: utf-8

ONLY_LOGS = False
ONLY_BUGS = False

if ONLY_LOGS:
    COLLECT_FILES = False
    COLLECT_IMAGES = False
    COLLECT_VIDEOS = False
    COLLECT_ARTICLES = False
    COLLECT_FORUM = False
    COLLECT_POSTS = False
    COLLECT_BUGS = False
    COLLECT_LOGS = True
    COLLECT_STATS = False
elif ONLY_BUGS:
    COLLECT_FILES = False
    COLLECT_IMAGES = False
    COLLECT_VIDEOS = False
    COLLECT_ARTICLES = False
    COLLECT_FORUM = False
    COLLECT_POSTS = False
    COLLECT_BUGS = True
    COLLECT_LOGS = False
    COLLECT_STATS = False
else:
    COLLECT_FILES = True
    COLLECT_IMAGES = True
    COLLECT_VIDEOS = True
    COLLECT_ARTICLES = True
    COLLECT_FORUM = True
    COLLECT_POSTS = True
    COLLECT_BUGS = True
    COLLECT_LOGS = True
    COLLECT_STATS = True

COLLECTING_MODS_LIMIT = 50

COLLECT_DELAY = 10

FILES = 1
IMAGES = 2
VIDEOS = 3
ARTICLES = 4
POSTS = 5
FORUM = 6
BUGS = 7
LOGS = 8
STATS = 9

def tab_name(tab):
    if tab == None:
        return "None"
    elif tab == FILES:
        return "File"
    elif tab == IMAGES:
        return "Image"
    elif tab == VIDEOS:
        return "Video"
    elif tab == ARTICLES:
        return "Article"
    elif tab == POSTS:
        return "Post"
    elif tab == FORUM:
        return "Forum"
    elif tab == BUGS:
        return "Bug"
    elif tab == LOGS:
        return "Log"
    elif tab == STATS:
        return "Stat"
    else:
        return str(tab)

def get_collect_list(collect_bugs=COLLECT_BUGS):
    flags = []
    if COLLECT_FILES == True:
        flags.append(FILES)

    if COLLECT_IMAGES == True:
        flags.append(IMAGES)

    if COLLECT_VIDEOS == True:
        flags.append(VIDEOS)

    if COLLECT_ARTICLES == True:
        flags.append(ARTICLES)

    if COLLECT_FORUM == True:
        flags.append(FORUM)

    if COLLECT_POSTS == True:
        flags.append(POSTS)

    if (collect_bugs == True) and (COLLECT_BUGS == True):
        flags.append(BUGS)

    if COLLECT_LOGS == True:
        flags.append(LOGS)

    if COLLECT_STATS == True:
        flags.append(STATS)
    return flags

def get_condition(tab):
    if tab == None:
        return ""
    elif tab == FILES:
        return "(files_finalized = FALSE AND collecting_files = FALSE)"
    elif tab == IMAGES:
        return "(images_finalized = FALSE AND collecting_images = FALSE)"
    elif tab == VIDEOS:
        return "(videos_finalized = FALSE AND collecting_videos = FALSE)"
    elif tab == ARTICLES:
        return "(articles_finalized = FALSE AND collecting_articles = FALSE)"
    elif tab == FORUM:
        return "(forum_finalized = FALSE AND collecting_forum = FALSE)"
    elif tab == POSTS:
        return "(posts_finalized = FALSE AND collecting_posts = FALSE)"
    elif tab == BUGS:
        return "(bugs_finalized = FALSE AND collecting_bugs = FALSE)"
    elif tab == LOGS:
        return "(logs_finalized = FALSE AND collecting_logs = FALSE)"
    elif tab == STATS:
        return "(statistics_finalized = FALSE AND collecting_statistics = FALSE)"

def get_collect_condition(collect_bugs=COLLECT_BUGS):
    str_condition = ""
    collect_list = get_collect_list(collect_bugs)
    if len(collect_list) > 0:
        for index, collect in enumerate(collect_list):
            if index > 0:
                str_condition += " OR "
            str_condition += get_condition(collect)
    return str_condition

def get_condition_count(tab):
    if tab == None:
        return ""
    elif tab == FILES:
        return "files_finalized"
    elif tab == IMAGES:
        return "images_finalized"
    elif tab == VIDEOS:
        return "videos_finalized"
    elif tab == ARTICLES:
        return "articles_finalized"
    elif tab == FORUM:
        return "forum_finalized"
    elif tab == POSTS:
        return "posts_finalized"
    elif tab == BUGS:
        return "bugs_finalized"
    elif tab == LOGS:
        return "logs_finalized"
    elif tab == STATS:
        return "statistics_finalized"

def get_collect_condition_count():
    str_condition = ""
    collect_list = get_collect_list()
    if len(collect_list) > 0:
        for index, collect in enumerate(collect_list):
            if index > 0:
                str_condition += " AND "
            str_condition += get_condition_count(collect)
    return str_condition

def get_next_incomplete_tab(c_mod, collect_bugs=COLLECT_BUGS):
    if 1 == 2:
        return None
    elif (COLLECT_FILES == True) and (c_mod.files_finalized == False) and (c_mod.collecting_files == False):
         return FILES
    elif (COLLECT_IMAGES == True) and (c_mod.images_finalized == False) and (c_mod.collecting_images == False):
         return IMAGES
    elif (COLLECT_VIDEOS == True) and (c_mod.videos_finalized == False) and (c_mod.collecting_videos == False):
         return VIDEOS
    elif (COLLECT_ARTICLES == True) and (c_mod.articles_finalized == False) and (c_mod.collecting_articles == False):
         return ARTICLES
    elif (COLLECT_FORUM == True) and (c_mod.forum_finalized == False) and (c_mod.collecting_forum == False):
        return FORUM
    elif (COLLECT_POSTS == True) and (c_mod.posts_finalized == False) and (c_mod.collecting_posts == False):
       return POSTS
    elif (collect_bugs == True) and (COLLECT_BUGS == True) and (c_mod.bugs_finalized == False) and (c_mod.collecting_bugs == False):
         return BUGS
    elif (COLLECT_LOGS == True) and (c_mod.logs_finalized == False) and (c_mod.collecting_logs == False):
        return LOGS
    elif (COLLECT_STATS == True) and (c_mod.statistics_finalized == False) and (c_mod.collecting_statistics == False):
        return STATS
    else:
        return None

def get_collecting_tab(tab):
    if tab == None:
        return ""
    elif tab == FILES:
        return "collecting_files"
    elif tab == IMAGES:
        return "collecting_images"
    elif tab == VIDEOS:
        return "collecting_videos"
    elif tab == ARTICLES:
        return "collecting_articles"
    elif tab == FORUM:
        return "collecting_forum"
    elif tab == POSTS:
        return "collecting_posts"
    elif tab == BUGS:
        return "collecting_bugs"
    elif tab == LOGS:
        return "collecting_logs"
    elif tab == STATS:
        return "collecting_statistics"
