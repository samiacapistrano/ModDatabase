# -*- coding: utf-8 -*-
from bs4 import BeautifulSoup

from scripts.function_util import getPagingNumber
from scripts.function_util import addingSelenium
from scripts.function_util import formatDescribedDateMonth
from manager.models import Video
from manager.models import Mod
from scripts.function_util import setDateTimeNow
import time


def getVideo(link_abas,soupContent,modObj):

    browser = addingSelenium(link_abas)
    divVideosAuthor = soupContent.find("div", attrs={'id': 'list-modvideos-1'})
    divVideosUser = soupContent.find("div", attrs={'id': 'list-modvideos-2'})

    scriptAuthor = divVideosAuthor.find_all("script")
    listPagAuthor= None
    if scriptAuthor:
        for aux2 in scriptAuthor:
            if '"page"' in aux2.text:
                listPagAuthor = getPagingNumber(aux2.string)
                break


    if listPagAuthor:
        videosUser = False
        for page_index in range(1, int(listPagAuthor[-1].replace('\'', '')) + 1):
            if len(listPagAuthor) > 1 and page_index != 1:
                browser.refresh()
                browser.execute_script(
                    "return window.RH_ModVideosList1.Send('1page', '" + str(page_index) + "');")
                time.sleep(2)
                soupContent = BeautifulSoup(browser.page_source, 'lxml')
            ulVideos = soupContent.find("ul", attrs={'id': 'mod_video_list_1'})
            videos = ulVideos.find_all("li", attrs={'class': 'image-tile video-tile video-mod-page'})

            getDateVideos(modObj, videos, videosUser)


    scriptUser = divVideosUser.find_all("script")
    listPagUser = None
    if scriptUser:
        for aux2 in scriptUser:
            if '"page"' in aux2.text:
                listPagUser = getPagingNumber(aux2.string)
                break


    if listPagUser:
        videosUser = True
        for page_index in range(1, int(listPagUser[-1].replace('\'', '')) + 1):
            if len(listPagUser) > 1 and page_index != 1:
                browser.refresh()
                browser.execute_script(
                    "return window.RH_ModVideosList2.Send('2page', '" + str(page_index) + "');")
                time.sleep(2)
                soupContent = BeautifulSoup(browser.page_source, 'lxml')

            ulVideos = soupContent.find("ul", attrs={'id': 'mod_video_list_2'})
            videos = ulVideos.find_all("li", attrs={'class': 'image-tile video-tile video-mod-page'})
            getDateVideos(modObj, videos, videosUser)


def getDateVideos(modObj, videos, videosUser):

    for listVd in videos:
        videoObj = Video()
        videoObj.begin_date = setDateTimeNow()

        videoObj.uploaded_date = formatDescribedDateMonth(listVd.find("div", attrs={'class': 'author'}).text)
        videoObj.name = listVd.h3.text.encode('utf-8')
        videoObj.videosUser = videosUser

        if Mod.objects.filter(name=modObj.name, url=modObj.url):
            modAux = Mod.objects.get(name=modObj.name, url=modObj.url)
            videoObj.mod = modAux
        else:
            print "Erro ao associar Mod ao Arquivo"
        videoObj.finish_date = setDateTimeNow()
        videoObj.save()
