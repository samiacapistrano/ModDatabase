# -*- coding: utf-8 -*-
import os

import django
from bs4 import BeautifulSoup
#from selenium.webdriver.common.keys import Keys
#from selenium.webdriver.support.wait import WebDriverWait
#from selenium.common.exceptions import NoSuchElementException

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import ui
from selenium.webdriver.support.ui import WebDriverWait

from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import *
from selenium.webdriver.common import actions
from  selenium.webdriver.common.action_chains import ActionChains
import time


#./manage.py shell < scripts/script_get_mods_info.py --settings=mysite.settings_samia
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mysite.settings_samia")
django.setup()


from scripts.function_util import addingSelenium, formateDateM_AM_PM
from manager.models import Changelogs, ListChange, Mod, ModPageActivity, AuthorActivity
from scripts.function_util import setDateTimeNow


def getLogs(link_abas, idMod, modURL):

    browser = addingSelenium(link_abas)
    soup = BeautifulSoup(browser.page_source, 'html.parser')
    modObj = Mod.objects.get(nexus_id_mod=idMod, url=modURL)

    accordion = soup.find('dl', {'class': 'accordion'})
    dts = accordion.find_all('dt')
    wait = WebDriverWait(browser, 3)

    for k in range(1, len(dts) + 1):

        if dts[k-1].text.strip().__eq__("Changelogs"):
            linkClick1 = browser.find_element_by_xpath(
                '//*[@id="section"]/div/div[2]/div[2]/div/div[2]/div/div/div/dl/dt[' + str(k) + ']')

            openAccordion(browser, wait, linkClick1)

            div = soup.find_all('div', {'class': 'log-block'})
            ads = wait.until(EC.element_to_be_clickable((By.ID, 'Brid_63812665')))

            ul = div[k - 1].find('ul', {'class': 'change-logs'})
            lis = ul.find_all('li', recursive=False)
            for li in lis:
                changelogsObj = Changelogs()
                changelogsObj.mod = modObj

                h3 = li.find('h3')
                changelogsObj.version = h3.text.strip()

                ul2 = li.find('ul', {'class': 'arrowlist'})

                lis2 = ul2.find_all('li')
                for li2 in lis2:
                    listChange = ListChange()
                    listChange.begin_date = setDateTimeNow()
                    listChange.change = li2.text.strip()

                    changelogsObj.save()

                    listChange.changelog = changelogsObj
                    listChange.finish_date = setDateTimeNow()
                    listChange.save()

            openAccordion(browser, wait, linkClick1)


        elif dts[k-1].text.strip().__eq__("Author's activity"):

            linkClick2 = browser.find_element_by_xpath(
                '//*[@id="section"]/div/div[2]/div[2]/div/div[2]/div/div/div/dl/dt[' + str(k) + ']')
            openAccordion(browser, wait, linkClick2)

            classLog = soup.find("div", attrs={"class": "log-block"}).h3
            if classLog:

                ads = wait.until(EC.element_to_be_clickable((By.ID, 'Brid_63812665')))
                clinkbotton(browser, 'ModActionLogExpanderLoadButtonauthor',wait)

            soup = BeautifulSoup(browser.page_source, 'html.parser')
            div = soup.find_all('div', {'class': 'log-block'})

            uls = div[k-1].find_all('ul', {'class': 'action-log'})
            for ul in uls:
                lis = ul.find_all('li', recursive=False)
                for li in lis:
                    authorActivityObj = AuthorActivity()
                    authorActivityObj.begin_date = setDateTimeNow()
                    authorActivityObj.mod = modObj

                    date = li.find('div',{'class':'log-modified'})
                    if date:
                        datetext = date.text.split("|")
                        authorActivityObj.date = formateDateM_AM_PM(datetext[0])

                    author = li.find('a')

                    authorLink = author.get('href')
                    authorActivityObj.user_url = authorLink

                    authorName = author.text.strip()
                    authorActivityObj.user = authorName

                    divLogChange = li.find('div',{'class':'log-change'})
                    title = divLogChange.find('h4')
                    if title:
                        authorActivityObj.title = title.text
                    content = divLogChange.find('p')
                    if content:
                        authorActivityObj.content = content.text

                    authorActivityObj.finish_date = setDateTimeNow()
                    authorActivityObj.save()
                    print "Autor Salvo"


            openAccordion(browser,wait,linkClick2)

        elif dts[k-1].text.strip().__eq__("Mod page activity"):
            linkClick3 = browser.find_element_by_xpath(
                '//*[@id="section"]/div/div[2]/div[2]/div/div[2]/div/div/div/dl/dt[' + str(k) + ']')

            openAccordion(browser,wait,linkClick3)

            classLog = soup.find("div", attrs={"class": "log-block"}).h3
            #if classLog:
            ads = wait.until(EC.element_to_be_clickable((By.ID, 'Brid_63812665')))
            clinkbotton(browser, 'ModActionLogExpanderLoadButtonusers',wait)

            soup = BeautifulSoup(browser.page_source, 'html.parser')
            div = soup.find_all('div', {'class': 'log-block'})

            uls = div[k - 1].find_all('ul', {'class': 'action-log'})

            for ul in uls:
                lis = ul.find_all('li', recursive=False)
                for li in lis:
                    modPageActivityObj = ModPageActivity()
                    modPageActivityObj.begin_date = setDateTimeNow()
                    modPageActivityObj.mod = modObj

                    date = li.find('div', {'class': 'log-modified'})
                    if date:
                        datetext = date.text.split("|")
                        modPageActivityObj.date = formateDateM_AM_PM(datetext[0])

                    author = li.find('a')

                    authorLink = author.get('href')
                    modPageActivityObj.user_url = authorLink

                    authorName = author.text.strip()
                    modPageActivityObj.user = authorName

                    divLogChange = li.find('div', {'class': 'log-change'})

                    title = divLogChange.find('h4')
                    if title:
                        modPageActivityObj.title = title.text

                    content = divLogChange.find('p')
                    if content:
                        modPageActivityObj.content = content.text

                    modPageActivityObj.finish_date = setDateTimeNow()
                    modPageActivityObj.save()

            openAccordion(browser,wait,linkClick3)



    else:
            print dts[k - 1].text.strip()

    browser.close()

def openAccordion(browser, wait, element):

    gotoElement(browser, element)
    browser.execute_script("window.scrollTo(0,document.body.scrolltop)")
    gotoElement(browser, element)
    closeADS(wait, browser)
    try:
        element.click()
    except:
        closeADS(wait, browser)
        element.click()



def gotoElement(browser, element):
    actions = ActionChains(browser)
    actions.move_to_element(element)
    try:
        actions.perform()
        actions.reset_actions()
    except:
        print "Erro no goToElement"
        browser.refresh()
        try:
            actions.perform()
            actions.reset_actions()
        except:
            print "Erro no goToElement - ir até o elemento"




def closeADS(wait,browser):

    ads = wait.until(EC.element_to_be_clickable((By.ID, 'Brid_63812665')))

    try:
        webdriver.ActionChains(browser).send_keys(Keys.ESCAPE).perform()
    except:
        pass

    try:
        divLogChange = browser.find_element_by_class_name('video-ad clearfix')
        divLogChange['style'] = "z-index: -10000000;"
    except:
        pass




def clinkbotton(browser,buttonName,wait):

    #clearfix act - log - container  open
    loadMoreItemsLinkClik = None
    loadMoreItemsLinkClik = browser.find_element_by_id(buttonName)

    if loadMoreItemsLinkClik and loadMoreItemsLinkClik.is_displayed():
        print "visivél"
        try:
            element = wait.until(EC.element_to_be_clickable((By.ID, buttonName)))
            if element:
                try:
                    gotoElement(browser, element)
                    element.send_keys(Keys.SPACE)
                except:
                    pass


        except TimeoutException:
            try:
                element = wait.until(EC.invisibility_of_element_located((By.ID, buttonName)))
            except TimeoutException:
                element = wait.until(EC.element_to_be_clickable((By.ID, buttonName)))
                element.send_keys(Keys.SPACE)
        #browser.execute_script("window.scrollTo(0,document.body.scrollHeight)")

        element = None
        clinkbotton(browser,buttonName,wait);
    else:
        print "invisivel"