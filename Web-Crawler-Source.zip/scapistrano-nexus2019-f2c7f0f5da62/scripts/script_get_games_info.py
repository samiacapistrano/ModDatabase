import datetime
import json
import re
import urllib2

from bs4 import BeautifulSoup

from manager.models import Game
from scripts.function_util import setDateTimeNow

site = "https://www.nexusmods.com/"
hdr = { 'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'}

r = urllib2.Request(site, headers=hdr)

try:
   page = urllib2.urlopen(r)
except urllib2.HTTPError,e:
   print e.fp.read()

# content = page.read()
# print (content)

web = urllib2.urlopen(r)
soup = BeautifulSoup(web.read(), 'lxml')
data = soup.find_all("script")

pattern = re.compile('var json = (.*?);')
script = soup.find("script",text=pattern)
m = re.search('var json = (.+)[,;]{1}', str(script))
if m:
    found = m.group(1)

jdata = json.loads(found)

for d in jdata:
    game = Game()
    game.begin_date = setDateTimeNow()
    for key, value in d.iteritems():
        if (key=='approved_date'):
            # print key, datetime.datetime.fromtimestamp(value)
            game.approved_date = datetime.datetime.fromtimestamp(value)
        elif (key=='forum_url'):
            game.forum_url = value
        elif(key=='mods'):
            game.amount_mods = value
        elif(key=='name'):
            game.name = value
        elif(key=='downloads'):
            game.amount_downloads = value
        elif(key=='domain_name'):
            game.domain_name = value
        elif(key=='id'):
            game.nexus_id = value
        elif(key=='name_lower'):
            game.name_lower = value
        elif(key=='file_count'):
            game.file_count = value
        elif(key=='genre'):
            game.genre = value
        elif(key=='nexusmods_url'):
            game.nexusmods_url = value
            # print key, value
    # print ("-------------------")
    game.capturing_mods_finalized = False
#    print game.name
    game.finish_date = setDateTimeNow()
    
    try:
        gameSelect = Game.objects.filter(domain_name = game.domain_name)
        if not gameSelect:
            game.save()
            print "Save:",game.domain_name
    except Exception as e:
        print "Error: Exception:",str(e)

print len(jdata)

