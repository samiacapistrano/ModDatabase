#coding: utf-8

import atexit
import json
import re
import sys
import time
import traceback
import urllib2
import warnings
import bs4
import requests
import os

from bs4 import BeautifulSoup
from datetime import datetime
from django.db.models import Sum
from Logger import Logger
from urllib2 import HTTPError

from scripts.function_util import formatDateTime
from scripts.function_util import formaDateMonthYears
from scripts.function_util import criarBrowser
from scripts.function_util import sendEmail
from scripts.function_util import setDateTimeNow
from scripts.function_util import getBrowser

from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException

from manager.models import Modder

warnings.filterwarnings("ignore", category=RuntimeWarning)
logger = Logger()

class ModderCollector():
    global logger
    global setDateTimeNow
    global bs4
    global NoSuchElementException

    TESTING = False
    DEBUG = False

    modder = None
    hdr = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 '
                + '(KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
    }

    all_modders_count = 0
    finished_modders_count = 0
    collecting_modders_count = 0
    progress_msg_len = 0

    user_browser = None

    def __init__(self):
        global atexit
        atexit.register(self.exit)

    def collect_basic_info(self):
        logger.info(" ----------- Collecting Modder's ----------- ")
        try:
            self.all_modders_count = self.count_all_modders()
            start_time = time.time()

            while True:
                self.finished_modders_count = self.count_complete_modders()
                self.incomplete_games_count = self.all_modders_count - self.finished_modders_count

                collect_complete = self.finished_modders_count == self.all_modders_count
                if collect_complete:
                    print ""
                    logger.success("All Modder's finished.")
                    break

                modder = None
                modders = self.get_next_incomplete_modder()
                if modders and len(modders) > 0:
                    modder = modders[0]
                    self.collect_modder_basic_info(modder, None)
                else:
                    self.collecting_modders_count = self.count_collecting_modders()
                    if self.collecting_modders_count > 0:
                        print ""
                        logger.info("There are no Modder available to collect.")
                        logger.info("processing Modder's: " + str(self.collecting_modders_count)
                                + " waiting for completion...")
                        logger.wait_message("Next check in 30 seconds.", 30)
                        continue
                    else:
                        break

            print ""
        except Exception as e:
            print ""
            self.stop_modder_collecting()
            str_modder = ". "
            if self.modder:
                str_modder = " - Modder Id:" + str(self.modder.id) + ". "
            logger.error("Exception" + str_modder + str(e))
            traceback.print_exc()
        print ""
        logger.info("Collect time: %.0f second(s)." % (time.time() - start_time))
        logger.info(" ------------------ Collect finished ---------------- ")
        return

    def collect_modder_basic_info(self, modder=None, modder_id=None):
        if modder_id:
            self.modder = self.get_modder_by_id(modder_id)
        elif modder:
            self.modder = modder
        else:
            modders = self.get_next_incomplete_modder()
            if modders and len(modders) > 0:
                self.modder = modders[0]
            else:
                print ""
                logger.info("There is no modders available. Collect finished.")
                return

        modder_url = self.modder.url_perfil_modder
        if not modder_url:
            print ""
            logger.info("Modder doesn't have url. Id: " + self.modder.id + ".")
            return

        if self.modder.running:
            print ""
            logger.info("Modder " + str(modder_url) + " already in processing.")
            return

        if self.modder.modder_capture_finished:
            print ""
            logger.info("Modder " + str(modder_url) + " already completed.")
            return

        if not self.TESTING:
            self.modder.running = True
            self.modder.save()
        self.modder.begin_date = setDateTimeNow()

        try:
            soup = self.soup_collect(modder_url)
            name_div = soup.findAll("div", attrs={'class': 'user-identity clearfix'})
            name = ""
            if name_div:
                name = name_div[0].h1.text.encode('utf-8')


            error_div = soup.find("div", attrs={'id': 'user-error-notice'})
            if error_div:
                print ""
                error_msg = error_div.text.strip().replace('\n',' ')
                logger.error("Falha ao coletar dados do Modder ID:" + str(self.modder.id) + " " + error_msg)
                self.modder.error_msg = str(error_msg)
                self.modder.error = True
                self.modder.save()
                self.stop_modder_collecting()
                return

            # logger.info(self.modder.url_perfil_modder)

            ul_data = soup.findAll("ul", attrs={'class': 'stats clearfix'})
            for dt_modder in ul_data[0]:
                if isinstance(dt_modder, bs4.element.Tag):
                    text = dt_modder.text.strip("\n").split("\n")
                    if text and len(text[2]) > 2:
                        if (text[1].__eq__("Endorsements given")):
                            self.modder.amount_endorsements =int(str(text[2]).replace(",",""))
                        elif(text[1].__eq__("Profile views")):
                            self.modder.amount_views =int(str(text[2]).replace(",",""))
                        elif(text[1].__eq__("Topics")):
                            self.modder.amount_topic  =int(str(text[2]).replace(",",""))
                        elif (text[1].__eq__("Posts")):
                            self.modder.amount_posts =int(str(text[2]).replace(",",""))
                        elif (text[1].__eq__("Kudos")):
                            self.modder.amount_kudos =str(text[2]).replace(",","")
                        else:
                            pass
                            # TODO verificar
                        # logger.info("Dado desconhecido" + str(text[1]))
            # TODO rever isso está um for desnecessario eu acho
            data_info = soup.find("div", {"id": "fileinfo"})
            for dt_info in data_info:
                if isinstance(dt_info, bs4.element.Tag):
                    text = dt_info.text.strip("\n").split("\n")
                    if not ("User information" in text):
                        if (text[0].__eq__("Status")):
                            self.modder.status = str(text[1])
                        elif(text[0].__eq__("Real name")):
                            if text and len(text) > 1:
                                self.modder.real_name = text[1].encode('utf-8')
                        elif(text[0].__eq__("Last active")):
                            times = dt_info.findAll("time")
                            self.modder.last_active_date = formatDateTime(str(times[0]['datetime']))
                        elif (text[0].__eq__("Join date")):
                            times = dt_info.findAll("time")
                            self.modder.join_active_date = formatDateTime(str(times[0]['datetime']))
                        elif (text[0].__eq__("Country")):
                            if text[1].__eq__("Not specified"):
                                self.modder.country = text[1].encode('utf-8')
                            else:
                                self.modder.country = text[2].encode('utf-8')
                        else:
                            pass
                            # TODO verificar
                            # logger.info("Dado desconhecido" + str(text[2]))
            mod_tabs = soup.find("ul", attrs={"class":"modtabs"})
            list_user_tab = mod_tabs.find_all("li")
            for user_tab in list_user_tab:
                text = user_tab.text.strip("\n").split("\n")
                if (text[0].__eq__("User Files")):
                    self.modder.amount_user_files = int(str(text[1]).replace(",",""))
                elif (text[0].__eq__("User Images")):
                    self.modder.amount_user_images = int(str(text[1]).replace(",",""))
                elif (text[0].__eq__("User Videos")):
                    self.modder.amount_user_videos = int(str(text[1]).replace(",",""))
                elif (text[0].__eq__("Friends")):
                    self.modder.amount_friends = int(str(text[1]).replace(",",""))
                else:
                    pass
                    # TODO verificar
                    # logger.info("Dado desconhecido" + str(text))

        except Exception as e:
            logger.error("Falha ao coletar dados do Modder ID:" + str(self.modder.id) + " "  + str(e))
            traceback.print_exc()
            self.stop_modder_collecting()
            return


        forum_urls = soup.find_all("a", attrs={'class': 'btn inline-flex'})
        forum_url = None
        for url in forum_urls:
            if isinstance(url, bs4.element.Tag):
                if str(url.text.strip()).__eq__("Forum Profile"):
                    forum_url = url.get('href')
                    break

        if not forum_url:
            print ""
            logger.info("Forum_url Not Found.")

            self.modder.modder_capture_finished = True
            self.modder.finish_date = setDateTimeNow()
            self.modder.running = False
            if not self.TESTING:
                self.modder.save()
            return

        # TODO perguntar pra Samia
        # self.modder.url_perfil_modder = forum_url
        self.modder.url_forum = forum_url
        try:
            res = self.request_url(forum_url)

            if res.status_code == 403:
                soup_error = BeautifulSoup(res.text, 'html.parser')
                title = soup_error.find("p", attrs={'class': 'ipsType_sectiontitle'})
                if title:
                    error = str(title.text).strip()

                    if error.__eq__("This member is no longer active."):
                        print ""
                        logger.info("Modder is no longer active. Id:" + str(self.modder.id) + ".")
                        self.modder.is_active = False

                    elif error.__eq__("You are not permitted to view member profiles."):
                        # logger.info("You are not permitted to view member profiles.")

                        print ""
                        logger.info("Não autorizado. Enviar e-mail.")
                        # self.enviar_email("Perdeu a sessão. Favor logar no nexusmods.com.")

                        while res.status_code == 403:
                            print ""
                            logger.info("Aguardando logon no nexusmods.")
                            logger.wait_message("Nova verificação em 5 minutos.", 150)
                            res = self.request_url(forum_url)
                else:
                    print ""
                    logger.error("Failed to identify 403 error type.")
                    self.stop_modder_collecting()
                    return

            elif res.status_code != 200:
                print ""
                logger.error("Request forum_url Failed. Status code: " + str(res.status_code))
                self.stop_modder_collecting()
                return
            else:
                self.modder.is_active = True
        except Exception as e:
            logger.error("Falha ao acessar o forum do Modder ID:" + str(self.modder.id) + ". " + str(e))
            traceback.print_exc()
            self.stop_modder_collecting()
            return

        # Collect forum
        try:
            if self.modder.is_active:
                soup_forum = BeautifulSoup(res.text, 'html.parser')

                if self.DEBUG:
                    user_name = ""
                    user = soup_forum.find("a", attrs={'id': 'user_link'})
                    if user:
                        user_name = str(user.text)

                    forum_username = ""
                    forum_user = soup_forum.find("span", attrs={'class': 'fn nickname'})
                    if forum_user:
                        forum_username = str(forum_user.text)

                    print ""
                    logger.info("Url: " + modder_url)
                    logger.success("Successful request. Welcome " + user_name)
                    logger.info("Forum user: " + forum_username)

                user_profile = soup_forum.find_all("div", attrs={'class': 'general_box clearfix'})
                for profile in user_profile:
                    list_profile = profile.find_all("li", attrs={'class': 'clear clearfix'})
                    for li in list_profile:
                        text = li.text.strip("\n").split("\n")
                        if (text[0].__eq__("Group")):
                            if len(text) > 1:
                                self.modder.group = text[1]
                        elif (text[0].__eq__("Active Posts")):
                            self.modder.amount_active_post = text[1].replace(',', '.')
                        elif (text[0].__eq__("Profile Views")):
                            self.modder.amouny_profile_views = text[1]
                        elif (text[0].__eq__("Member Title")):
                            self.modder.memberTitle = text[1]
                        elif (text[0].__eq__("Age")):
                            if text[1].__eq__("Age Unknown"):
                                self.modder.age = None
                            else:
                                self.modder.age =  text[1]
                        elif (text[0].__eq__("Birthday")):
                            if text[1].__eq__("Birthday Unknown"):
                                self.modder.birthday = self.modder.birthday = None
                            else:
                                data = str(text[1]).strip("\n").split(" ")
                                if len(data) == 2:
                                    self.modder.birthday = self.modder.birthday = None
                                else:
                                    try:
                                        self.modder.birthday = formaDateMonthYears(text[1])
                                    except ValueError:
                                        print ""
                                        logger.info("Modder with invalid Date. ID:" + str(self.modder.id) + ".")
                                        print ""
                        # Exception: list index out of range
                        elif text and len(text) > 2:
                            if (text[0].__eq__("Gender")):
                                self.modder.genre = text[2]
                            elif (text[0].__eq__("Country")):
                                self.modder.country = text[2]
                            elif (text[0].__eq__("Monitor Size")):
                                self.modder.monitorSize = text[2]
                            elif (text[0].__eq__("Website URL")):
                                self.modder.websiteURL = text[2]
                            elif (text[0].__eq__("Interests")):
                                self.modder.interests = text[2]
                            elif (text[0].__eq__("Currently Playing")):
                                self.modder.currentlyPlaying = text[2]
                            elif (text[0].__eq__("Favourite Game")):
                                self.modder.favouriteGame = text[2]
                            elif (text[0].__eq__("Processor")):
                                self.modder.processor = text[2]
                            elif (text[0].__eq__("Memory")):
                                self.modder.memory = text[2]
                            elif (text[0].__eq__("Motherboard")):
                                self.modder.motherboard = text[2]
                            elif (text[0].__eq__("Real Name")):
                                self.modder.realName = text[2]
                            elif (text[0].__eq__("Graphics Card:")):
                                self.modder.graphicsCard = text[2]
                            elif (text[0].__eq__("Location")):
                                self.modder.location = text[2]
                            elif (text[0].__eq__("Processor")):
                                self.modder.processor = text[2]
                            else:
                                # TODO verificar
                                pass
        except Exception as e:
            msg = "Falha ao coletar dados do forum. Exception:" + str(e)
            self.modder.error_msg = str(msg)
            self.modder.error = True
            self.modder.save()
            logger.error("Falha ao coletar dados do forum. Modder ID:" + str(self.modder.id) + ". " + str(e))
            traceback.print_exc()
            self.stop_modder_collecting()
            return

        # custom_fields__other
        self.modder.modder_capture_finished = True
        self.modder.finish_date = setDateTimeNow()
        self.modder.running = False

        if not self.TESTING:
            self.modder.save()

        if not self.all_modders_count:
            self.all_modders_count = self.count_all_modders()

        self.print_count_progress()

        if self.DEBUG:
            pass
            # logger.info("Url: " + modder_url)
            # logger.info("Name: " + name)
            # logger.info("Endorsements: " + str(self.modder.amount_endorsements))
            # logger.info("Views: " + str(self.modder.amount_views))
            # logger.info("Topics: " + str(self.modder.amount_topic))
            # logger.info("Posts: " + str(self.modder.amount_posts))
            # logger.info("Kudos: " + str(self.modder.amount_kudos))

            # logger.info("Status: " + str(self.modder.status))
            # logger.info("Real Name: " + str(self.modder.real_name))
            # logger.info("Last active date: " + str(self.modder.last_active_date))
            # logger.info("Join active date: " + str(self.modder.join_active_date))
            # logger.info("Country: " + str(self.modder.country))

            # logger.info("Files: " + str(self.modder.amount_user_files))
            # logger.info("Images: " + str(self.modder.amount_user_images))
            # logger.info("Videos: " + str(self.modder.amount_user_videos))
            # logger.info("Friends: " + str(self.modder.amount_friends))
            # logger.info("forum_url: " + forum_url)

            # logger.info("Group: " + str(self.modder.group))
            # logger.info("Amount_active_post: " + str(self.modder.amount_active_post))
            # logger.info("Amouny_profile_views: " + str(self.modder.amouny_profile_views))
            # logger.info("MemberTitle: " + str(self.modder.memberTitle))
            # logger.info("Age: " + str(self.modder.age))
            # logger.info("Age: " + str(self.modder.age))
            # logger.info("Birthday: " + str(self.modder.birthday))
            # logger.info("Birthday: " + str(self.modder.birthday))
            # logger.info("Birthday: " + str(self.modder.birthday))
            # logger.info("Genre: " + str(self.modder.genre))
            # logger.info("Country: " + str(self.modder.country))
            # logger.info("MonitorSize: " + str(self.modder.monitorSize))
            # logger.info("WebsiteURL: " + str(self.modder.websiteURL))
            # logger.info("Interests: " + str(self.modder.interests))
            # logger.info("CurrentlyPlaying: " + str(self.modder.currentlyPlaying))
            # logger.info("FavouriteGame: " + str(self.modder.favouriteGame))
            # logger.info("Processor: " + str(self.modder.processor))
            # logger.info("Memory: " + str(self.modder.memory))
            # logger.info("Motherboard: " + str(self.modder.motherboard))
            # logger.info("RealName: " + str(self.modder.realName))
            # logger.info("GraphicsCard: " + str(self.modder.graphicsCard))
            # logger.info("Location: " + str(self.modder.location))
            # logger.info("Processor: " + str(self.modder.processor))
        return

    def get_next_incomplete_modder(self):
        return Modder.objects.filter(
            modder_capture_finished=False,
            running=False
        ).exclude(error = True).order_by('id')[:1]

    def get_modder_by_id(self, modder_id):
        return Modder.objects.get(id = modder_id)

    def exit(self):
        self.stop_modder_collecting()
        print ""
        logger.info("End of execution.")

    def stop_modder_collecting(self):
        if not self.TESTING and self.modder:
            self.modder.running = False
            self.modder.save()

    def soup_collect(self, url):
        r = urllib2.Request(url, headers=self.hdr)
        web = urllib2.urlopen(r)
        return BeautifulSoup(web.read(), 'lxml')

    def request_url(self, url):
        attempts = 0
        success = False
        while not success and attempts < 3:
            attempts += 1
            try:
                str_cookies = self.read_cookie()
                success = True
            except Exception as e:
                if attempts < 4:
                    logger.info("Error on reading cookie file. Attempt: " + str(attempts))
                else:
                    logger.error("Failed to read cookie file.")
                    traceback.print_exc()
                    return None
            time.sleep(0.5)

        if not str_cookies:
            logger.error("Cookie is empty")
            return None

        # str_cookies = '__cfduid=d3cfa5c32400aa207a24716d506c7ef1c1580832300; _ga=GA1.2.1814146475.1580832302; _hjid=b10a6eee-a891-457a-8f3d-59cd7a5b6db4; __qca=P0-954301779-1580832303017; __gads=ID=6cb18a3b7edb49aa:T=1580832305:S=ALNI_MakTHKcmqjFgAVjCzmyCqFQs6eRmw; _gid=GA1.2.1367561788.1581774469; member_id=52041081; pass_hash=60d32c4bcedc74762e39b31de9e19455; _pk_ref.1.81c5=%5B%22%22%2C%22%22%2C1582306883%2C%22https%3A%2F%2Fwww.nexusmods.com%2F%22%5D; _pk_id.1.81c5=547d2e980f185821.1582239692.4.1582306883.1582306883.; _pk_ses.1.81c5=1; _app_session=rShMUUG8LZ%2Fz8qOwnIjBPxyvr2yV7UNQLqQNeqkvnHBBZetcZCwfO1%2B2wkI4c6IVHe2%2BvFuuwhar3IEiwvTgBIFAMVr3ay1NpDTXXLNbqK1Haj0xCzqysQCEw3S3gQs5gBCeUkb6bo0sM3FOw6VAC1Is7obG8fSCRhqZU%2F7aIS0UfTJEmx7mHGhwmHNRx2ZOeR1uhTHCOFLqcfcmG4rln1wz7AN1zyeY%2BcTVXT%2F%2B1wY71S35GY9J3O1NTq7Z%2Fl9uWe43Ya1%2F7n6Lj2GWg3lzpOYYXa6MrTQ70Tyg%2B6QPNQksJzRKL0OrIya4007reJWJgsAda3g0uCboJAF5vYUUHmtzVDjbRMVirZnvtpCfvqAF%2Fuyu5x1MWv2IhmddpplLVIaNV%2BasDmOkpLOq5BNBlPfP026PhAFHdINHGGrWPz0eUB6J3DIrJ2pFJeJ0XxxGcZWqyzOc%2B92aCCS%2BP4KcdwaDmeiu34es50S2UrRML4pOTOx3vt%2B4cKfCznHnwPOr3YqOHBWgX5rzun8TdQWIdQ1hSO8IHpEMMF5wZjTH8MJ8rX8NXVQ%2FzqOCf2X1lUglbCnMe3ruDGW%2Fvbb4JQajtWMVoosDx%2B%2Folm5gbtZBdbm37zKEKDx6n7LKSe4BWiFzBB%2BYH53aJwzGkQnUYUyegSnAqPrRxj%2B8kywnIFVf8XMAfc58yQ93sFOj3c%2BWJ3sxoZq%2Fvfu5SPAFO23vqW3Wy5Xxh%2BlbjTmo66W8f3hzM6x1ueqM5f56fT%2F85Y9bJranOhv4pz8xp2mWjBw%2FZXBqdzY%3D--vhj8x%2BiAy5TVGxeX--KuQBvrExZ%2FjFMRbduG4M1Q%3D%3D; jwt_fingerprint=0961fb55cef5db8a031cb1113d79c7fb; sid=yzyAxzBCvtzyAEFDBsuAtwxBvEHvsGGtCGBtzutA; _gat_UA-144086054-1=1'
        header = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'accept-encoding': 'gzip, deflate, br',
            'accept-language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
            'cache-control': 'max-age=0',
            'cookie': "'" + str_cookies + "'",
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.106 Safari/537.36'
        }
        return requests.get(url, headers=header)

    def logon(self):
        WAIT = WebDriverWait(self.user_browser, 150)

        self.user_browser.get("https://users.nexusmods.com/auth/sign_in")

        try:
            time.sleep(1)
            self.user_browser.find_element_by_id('user_login').send_keys('SCapistrano')
            time.sleep(1)
            self.user_browser.find_element_by_id('password').send_keys('Samia22121964')
            btn_login = WAIT.until(
                EC.element_to_be_clickable((By.NAME, "commit"))
            )
            time.sleep(1)
            btn_login.click()

            WAIT.until(
                EC.url_to_be("https://users.nexusmods.com/user/edit")
            )
            time.sleep(1)
            btn_home = WAIT.until(
                EC.element_to_be_clickable((By.CLASS_NAME, "left-link"))
            )
            btn_home.click()

            WAIT.until(
                EC.url_to_be("https://www.nexusmods.com/")
            )

            time.sleep(1)
            WAIT.until(
                lambda driver: self.user_browser.execute_script('return document.readyState') == 'complete'
            )
            logger.info("Page loaded")
            time.sleep(1)

            # while(True):
            print ""
            logger.info("Getting cookies...")
            cookie = self.get_cookie(self.user_browser)
            if cookie == "":
                logger.error("Cookie is empty.")

            logger.info("Saving cookies...")
            self.save_cookie(cookie)

        except Exception as e:
            print "Error: " + str(e)
            traceback.print_exc()

    def get_cookie(self, browser):
        try:
            browser_cookies = browser.get_cookies()

            cookies_dict = {}
            for cookie in browser_cookies:
                cookies_dict[cookie['name']] = cookie['value']

            str_cookies = ""
            for key, value in cookies_dict.items():
                if len(str_cookies) == 0:
                    str_cookies += key + '=' + value
                else:
                    str_cookies += '; ' + key + '=' + value
            return str_cookies
        except Exception as e:
            logger.error("Error on getting browser cookie." + str(e))
            traceback.print_exc()

    def save_cookie(self, cookie):
        try:
            cookie_file = open('cookie.txt', 'w+')
            cookie_file.write(cookie)
            cookie_file.close()
        except Exception as e:
            logger.error("Error on saving cookie file." + str(e))
            traceback.print_exc()

    def read_cookie(self):
        try:
            cookie = None
            cookie_file = open("cookie.txt","r")
            cookie = cookie_file.read()
            cookie_file.close()
            return cookie
        except Exception as e:
            logger.error("Error on reading cookie file." + str(e))
            traceback.print_exc()

    def count_all_modders(self):
        return Modder.objects.count()

    def count_complete_modders(self):
        return Modder.objects.filter(
            modder_capture_finished = True,
            running = False
        ).count()

    def count_collecting_modders(self):
        return Modder.objects.filter(
            running = True,
        ).count()

    def print_count_progress(self):
        status_count = "%3d" % self.finished_modders_count + "/" + "%3d" % self.all_modders_count
        progress = logger.get_progress_bar(
            self.finished_modders_count, self.all_modders_count, 30, True, "Count")
        status_msg = progress + status_count + " Modder id: " + str(self.modder.id) + "    "
        logger.print_inline(status_msg, self.progress_msg_len)
        self.progress_msg_len = len(status_msg)

    def login_loop(self):
        self.user_browser = getBrowser(False)
        time.sleep(1)
        self.logon()
        while(True):
            logger.wait_message("Browser refresh and check in 10 minutes...", 600)
            logged = self.user_logged()
            if not logged:
                self.logon()
            time.sleep(1)

    def user_logged(self):
        WAIT = WebDriverWait(self.user_browser, 150)

        self.user_browser.refresh()
        WAIT.until(
            lambda driver: self.user_browser.execute_script('return document.readyState') == 'complete'
        )
        time.sleep(1)

        try:
            login_button = self.user_browser.find_element_by_id("login")
            if not login_button:
                return True
        except NoSuchElementException:
            return True

        logger.info("Session expired. Trying to log in again.")
        return False

