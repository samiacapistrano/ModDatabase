import atexit
import django
import os
import sys
import time
import urllib2
import warnings

from bs4 import BeautifulSoup
from django.conf import settings
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import TimeoutException

from scripts.script_get_mods_info import allDataMod
from scripts.script_get_logs import getLogs
from scripts.function_util import getPagingNumber
from scripts.function_util import tranformationOfComputerMeasureUnit
from scripts.function_util import formatDescribedDate
from scripts.function_util import tranformationAmount
from scripts.function_util import addingSelenium

from manager.models import Game
from manager.models import Mod

warnings.filterwarnings("ignore", category=RuntimeWarning) 
reload(sys)
sys.setdefaultencoding('utf-8')

class ModInfoCollector:
    not_games_collecting = None
    not_games_incomplete = None
    games_collecting_count = None
    incomplete_games_count = None
    game = None
    statusMsgLen = 0
    statusMsg2Len = 0
    start_page = None

    def __init__(self):
        global django
        global atexit
        global time
        os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mysite.settings_samia")    
        django.setup()
        atexit.register(self.exit)
        self.spinner = self.spinning_cursor()
        
    def collect_mods_info(self):
        try:
            while not self.collect_mods_complete():
                if self.not_games_incomplete:
                    if self.not_games_collecting:
                        print "INFO: Todos os Game's ja foram concluidos."
                        return
                    else:
                        print "INFO: Nao ha Game's disponiveis para coleta."
                        print "INFO: Game's em processamento:",self.games_collecting_count," aguardando conclusao..."
                        self.waiting_message('Nova verificacao em:', 60)
                else:
                    incomplete_games = self.get_incomplete_games()
                    print "INFO: Iniciando Coleta dos Mod's."
                    for game in incomplete_games:
                        self.game = game
                        self.collect_game_mods_info(self.game, None, None)
                    print "INFO: Coleta de Mod's finalizada."
                time.sleep(1)
            
        except Exception as e:
            print "ERROR: ",str(e)

    def collect_game_mods_info(self, game, game_id, page):
        global urllib2
        global BeautifulSoup
        global getPagingNumber
        global addingSelenium
        global WebDriverWait
        global EC
        global TimeoutException
        global By
        global Keys

        try:
            if game_id:
                game = self.get_game_by_id(game_id)
                if not game:
                    print "ERROR: Falha ao consultar o Game com Id:",game_id,'.'
                    return
                else:
                    self.game = game
            elif not game:
                print "ERROR: Parametro Game ou game_id e necessario."
                return
            else:
                self.game = game
        except:
            print "ERROR: Falha ao processar o Game.",
            return
        
        try:
            if self.game.getting_basic_information:
                print "INFO: Game:" + self.game.domain_name + " ja esta em processamento."
                return

            if self.game.capturing_mods_finalized:
                print "INFO: Game:" + self.game.domain_name + " ja foi concluido."
                return
            
            game_mods = self.game.amount_mods
            if game_mods == 0:
                print "INFO: Game:" + self.game.domain_name + " nao possui Mod's."
                self.game.capturing_mods_finalized = True
                self.game.save()
                return
            
            # Persistindo no banco que a coleta para o Game esta em execucao 
            self.game.getting_basic_information = True
            self.game.save()

            # Game URL
            site = self.game.nexusmods_url + "/mods"

            # Start Page
            if not page:
                # Inicia a coleta apartir da ultima pagina coletada - 10
                if self.game.last_page_collected and self.game.last_page_collected > 10:
                    self.start_page = self.game.last_page_collected - 10
                else:
                    self.start_page = 1
            else:
                self.start_page = page

            countMods = self.get_game_mods_count(self.game.id)
            print "INFO: Iniciando coleta, id:",self.game.id," Game:",self.game.domain_name," Page:",self.start_page

            hdr = {
                'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
            }
            
            r = urllib2.Request(site, headers=hdr)
            web = urllib2.urlopen(r)
            soup = BeautifulSoup(web.read(), 'lxml')

            pagination = None
            script = soup.find_all("script")
            if script:
                for aux2 in script:
                    if '"page"' in aux2.text:
                        pagination = getPagingNumber(aux2.string)
                        break
            
            browser = addingSelenium(site)
            time.sleep(1)
            
            #  Verify if pagination exists
            pag_element = browser.find_elements_by_class_name('pagination')
            if (not pag_element) or (not len(pag_element) > 0) or (pagination is None):
                print "INFO: O Game:" + self.game.domain_name + " nao possui Mod's."
                self.game.capturing_mods_finalized = True
                self.game.getting_basic_information = False
                self.game.save()
                return
            
            lastPage = int(pagination[-1]) + 1
            
            count_pages = 0
            for page_index in range(self.start_page, lastPage):
                
                # Refresh the browser after 100 pages 
                count_pages += 1
                if count_pages == 100:
                    count_pages = 0
                    browser.refresh()


                if len(pagination) > 5:
                    next = WebDriverWait(browser, 10).until(
                        EC.element_to_be_clickable((By.CLASS_NAME, "icon-arrow-thin")))
                    browser.execute_script("return window.RH_ModList.Send('page', '" + str(page_index) + "');", next)
                    try:
                        wait = WebDriverWait(browser, 4)
                        element = wait.until(EC.visibility_of_element_located((By.CLASS_NAME, 'flex')))
                        teste = wait.until(EC.invisibility_of_element_located((By.CLASS_NAME, 'flex')))
                    except TimeoutException:
                        try:
                            browser.refresh()
                            wait = WebDriverWait(browser, 4)
                            element = wait.until(EC.visibility_of_element_located((By.CLASS_NAME, 'flex')))
                            teste = wait.until(EC.invisibility_of_element_located((By.CLASS_NAME, 'flex')))
                        except TimeoutException:
                            print "Error: TimeoutException-1."
                            # self.game.getting_basic_information = False
                            # self.game.save()
                            page_index -= 5
                            continue
                        except Exception as e:
                            print "Error: Exception-1:",str(e)
                            self.game.getting_basic_information = False
                            self.game.save()
                            return
                            # recarregar ao fazer o jump rodar linhas 
                    except Exception as e:
                        print "Error: Exception-2:",str(e)
                        self.game.getting_basic_information = False
                        self.game.save()
                        return

                    soup = BeautifulSoup(browser.page_source, 'lxml')

                elif len(pagination) == 2 | len(pagination) == 3 | len(pagination) == 4:
                    linkClick = browser.find_element_by_id('select2-page_t-container')
                    linkClick.click()
                    elemt = browser.find_elements_by_class_name('select2-search__field')
                    elemt[2].send_keys(page_index)
                    elemt[2].send_keys(Keys.ENTER)

                    # try:
                    #     wait = WebDriverWait(browser, 3)
                    #     element = wait.until(EC.visibility_of_element_located((By.CLASS_NAME, 'flex')))
                    #     teste = wait.until(EC.invisibility_of_element_located((By.CLASS_NAME, 'flex')))
                    # except TimeoutException:
                    #     print('Error getting remote ADC value > Timeout reading remote ADC')
                    # except Exception as e:
                    #     print "Generico"

                    try:
                        wait = WebDriverWait(browser, 3)
                        element = wait.until(EC.visibility_of_element_located((By.CLASS_NAME, 'flex')))
                        teste = wait.until(EC.invisibility_of_element_located((By.CLASS_NAME, 'flex')))
                    except TimeoutException:
                        try:
                            browser.refresh()
                            wait = WebDriverWait(browser, 3)
                            element = wait.until(EC.visibility_of_element_located((By.CLASS_NAME, 'flex')))
                            teste = wait.until(EC.invisibility_of_element_located((By.CLASS_NAME, 'flex')))
                        except TimeoutException:
                            print "Error: TimeoutException-2."
                            self.game.getting_basic_information = False
                            self.game.save()
                            return
                        except Exception as e:
                            print "Error: Exception-3:",str(e)
                            self.game.getting_basic_information = False
                            self.game.save()
                            return
                    except Exception as e:
                        print "Error: Exception-4:",str(e)
                        self.game.getting_basic_information = False
                        self.game.save()
                        return

                    soup = BeautifulSoup(browser.page_source, 'lxml')
                try:
                    ultag = soup.find('ul', {'class': 'tiles'})
                    if ultag:
                        litags = ultag.find_all('li', {'class': 'mod-tile'})
                    else:
                        browser.refresh()
                        soup = BeautifulSoup(browser.page_source, 'lxml')
                        ultag = soup.find('ul', {'class': 'tiles'})
                        if ultag:
                            litags = ultag.find_all('li', {'class': 'mod-tile'})
                        else:
                            browser.refresh()
                            soup = BeautifulSoup(browser.page_source, 'lxml')
                            ultag = soup.find('ul', {'class': 'tiles'})
                            litags = ultag.find_all('li', {'class': 'mod-tile'})
                except:
                    try:
                        browser.refresh()
                        soup = BeautifulSoup(browser.page_source, 'lxml')
                        ultag = soup.find('ul', {'class': 'tiles'})
                        litags = ultag.find_all('li', {'class': 'mod-tile'})
                    except Exception as e:
                        print "Error: Exception-5:",str(e)
                        self.game.getting_basic_information = False
                        self.game.save()
                        return
                try:
                    if not ultag:
                        print "deu ruim"
                        print len(litags)
                        print litags[0]
                    
                    for litag in litags:
                        modObj = Mod()
                        modObj.game = game
                        modObjtDataBase = Mod()

                        if self.toCompareObjMod(litag, modObj, modObjtDataBase) == True:
                            if modObjtDataBase:
                                if modObjtDataBase.capturing_basic_data_finalized != True:
                                    modObjtDataBase.delete()
                                    self.savebasicInfomationMod(litag, modObj)
                                    countMods += 1
                        else:
                            self.savebasicInfomationMod(litag, modObj)
                            countMods += 1
                    
                        # Status 
                        sys.stdout.flush()
                        sys.stdout.write((b'\x08' * self.statusMsg2Len).decode())
                        statusPercent = 100 * float(page_index)/float(lastPage-1)
                        statusMsg = str(round(statusPercent, 2)) + '% Mods:' + str(countMods) + ' '
                        self.statusMsg2Len = len(statusMsg)
                        sys.stdout.write(statusMsg)
                except Exception as e:
                    print "Error: Exception-6:",str(e)
                    self.game.getting_basic_information = False
                    self.game.save()
                    return

                if page_index > self.game.last_page_collected:
                    self.game.last_page_collected = page_index
                    self.game.save()
            browser.quit()

            self.game.getting_basic_information = False
            self.game.capturing_mods_finalized = True
            self.game.save()
            print "INFO: Coleta finalizada - Id:",self.game.id," Game:",self.game.domain_name," Mods:",countMods

        except Exception as e:
            print "ERROR: Falha ao coletar dados - Id:",self.game.id," Game:",self.game.domain_name,". Exception:",str(e)
            self.game.getting_basic_information = False
            self.game.save()
            return

    def get_incomplete_games(self):
        return Game.objects.filter(
            capturing_mods_finalized = False,
            getting_basic_information = False
        ).order_by('id')

    def collect_mods_complete(self):
        self.games_collecting_count = self.get_games_collecting_count()
        self.incomplete_games_count = self.get_incomplete_games_count()
        self.not_games_collecting = self.games_collecting_count == 0
        self.not_games_incomplete = self.incomplete_games_count == 0
        return self.not_games_collecting and self.not_games_incomplete

    def get_incomplete_games_count(self):
        global Game
        return Game.objects.filter(
            capturing_mods_finalized = False,
            getting_basic_information = False
        ).count()
    
    def get_games_collecting_count(self):
        global Game
        return Game.objects.filter(
            getting_basic_information = True
        ).count()
    
    def exit(self):
        if self.game is not None:
            self.game.getting_basic_information = False
            self.game.save()
        print 'INFO: Saindo...'

    def waiting_message(self, msg, delay):
        global time
        for i in range(delay, -1, -1):
            sys.stdout.flush()
            sys.stdout.write((b'\x08' * self.statusMsgLen).decode())
            statusMsg = msg + ' ' + str(i) + ' segundo(s) '
            self.statusMsgLen = len(statusMsg)
            sys.stdout.write(statusMsg)
            for i in range(4):
                sys.stdout.write(next(self.spinner))
                sys.stdout.flush()
                sys.stdout.write('\b')
                time.sleep(0.25)
        sys.stdout.flush()
        sys.stdout.write((b'\x08' * self.statusMsgLen).decode())
        sys.stdout.write((' ' * self.statusMsgLen).decode())
        sys.stdout.write((b'\x08' * self.statusMsgLen).decode())

    def spinning_cursor(self):
        while True:
            for cursor in '|/-\\':
                yield cursor

    def get_game_mods_count(self, id):
        global Mod
        return Mod.objects.filter(game_id = id).count()
    
    def get_game_by_id(self, game_id):
        return Game.objects.get(id = game_id)

    def toCompareObjMod(self, litag, modObj, modObjtDataBase):
        global formatDescribedDate
        
        divtags = litag.find('div', {'class': 'tile-content'})
        modName = divtags.h3.text
        modObj.name = modName

        atags = litag.find('a', {'class': 'mod-view'}, href=True, text=True)
        modObj.url = atags['href']

        div_meta_cleanfix = litag.find('div', {'class': 'meta clearfix'})
        times = div_meta_cleanfix.find('time', {'class': 'date'})
        originaldateMod = formatDescribedDate(
            times.text.replace("Uploaded: ", '').replace('\n', ''))
        modObj.original_upload = originaldateMod

        div_date = litag.find('div', {'class': 'date'})
        lastUpdate = formatDescribedDate(div_date.text.replace("Last Update: ", ''))
        modObj.last_upload_date = lastUpdate


        if Mod.objects.filter(name=modObj.name, game = modObj.game, url=modObj.url):
            modObjtDataBase1 = Mod.objects.get(name=modObj.name, game = modObj.game, url=modObj.url)

            modObjtDataBase.capturing_basic_data_finalized = modObjtDataBase1.capturing_basic_data_finalized
            modObjtDataBase.id = modObjtDataBase1.id
            modObjtDataBase.game_id = modObjtDataBase1.game_id

            if modObjtDataBase1:
                if modObjtDataBase1.original_upload.replace(tzinfo=None) == modObj.original_upload and modObjtDataBase1.last_upload_date.replace(tzinfo=None) == modObj.last_upload_date:
                    return True
        else:
            return False

    def savebasicInfomationMod(self, litag, modObj):
        global tranformationOfComputerMeasureUnit
        global formatDescribedDate
        global tranformationAmount

        atags = litag.find('a', {'class': 'mod-view'}, href=True, text=True)
        #print atags[0]['href']

        modObj.url = atags['href']
        #listtUrlsMod.append(atags[0]['href'])

        divcategory = litag.find('div', {'class': 'category'})
        #print divcategory
        a = divcategory.find('a', href=True)
        modObj.url_nexus_category = a['href']
        modObj.nexus_category = a.text

        div_meta_cleanfix = litag.find('div', {'class': 'meta clearfix'})
        times = div_meta_cleanfix.find('time', {'class': 'date'})
        modObj.original_upload = formatDescribedDate(times.text.replace("Uploaded: ", '').replace('\n', ''))

        div_date = litag.find('div', {'class': 'date'})
        modObj.last_upload_date = formatDescribedDate(div_date.text.replace("Last Update: ", ''))

        div_real_author = litag.find('div', {'class': 'realauthor'})
        div_author = litag.find('div', {'class': 'author'})
        a = div_author.find_all('a', href=True)
        p = litag.find('p', {'class': 'desc'})
        div_tile_data = litag.find('div', {'class': 'tile-data'})
        uls = div_tile_data.find('ul', {'class': 'clearfix'})

        li = uls.find('li', {'class': 'sizecount inline-flex'})
        span = li.find('span', {'class': 'flex-label'})
        if span.text.strip(" ") == "--":
            modObj.amount_files = 0
        else:
            modObj.amount_files = tranformationOfComputerMeasureUnit(span.text)

        li = uls.find('li', {'class': 'endorsecount inline-flex'})
        span = li.find('span', {'class': 'flex-label'})

        if span.text.strip(" ") == "--":
            modObj.amount_endorsements = 0
        else:
            modObj.amount_endorsements = tranformationAmount(span.text)

        li = uls.find('li', {'class': 'downloadcount inline-flex'})
        span = li.find('span', {'class': 'flex-label'})
        if span.text.strip(" ") == "--":
            modObj.amount_total_dls = 0
        else:
            modObj.amount_total_dls = tranformationAmount(span.text)

        modObj.capturing_basic_data_finalized = True
        modObj.captura_mod_finalizada = False
        modObj.capturing_statistic_finalized = False
        modObj.capturing_forum_finalized = False
        modObj.capturing_bug_finalized = False
        modObj.capturing_post_finalized = False
        modObj.capturing_article_finalized = False
        modObj.capturing_video_finalized = False
        modObj.capturing_image_finalized = False
        modObj.capturing_files_finalized = False
        modObj.capturing_log_finalized = False
        modObj.mod_running = False
        modObj.finished_execution = False
        modObj.save()
        # print modObj.name.encode('utf-8') + " " + "Informacoes basicas salvas "
   