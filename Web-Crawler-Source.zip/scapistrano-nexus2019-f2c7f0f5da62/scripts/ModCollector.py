#coding: utf-8

import atexit
import copy
import re
import sys
import time
import traceback
import warnings
import os
import sys

from itertools import cycle

import multiprocessing as mp
import resource

from bs4 import BeautifulSoup
from django.utils.datetime_safe import datetime

from Logger import Logger
from scripts.constants import *
from scripts.Dao import Dao
from scripts.Network import Network
from pprint import pprint

from scripts.function_util import formatDescribedDate
from scripts.function_util import setDateTimeNow
from scripts.function_util import getPagingNumber
from scripts.function_util import getPagingNumber2
from scripts.function_util import getHeadlessBrowser
from scripts.function_util import formatDescribeMonth
from scripts.function_util import tranformationOfComputerMeasureUnit
from scripts.function_util import tranformationAmount
from scripts.function_util import formateDateAM_PM
from scripts.function_util import formatDescribedDateMonth
from scripts.function_util import formateDateM_AM_PM
from scripts.function_util import formatDateTime, formatDate

from manager.models import AuthorActivity
from manager.models import Bug
from manager.models import BugComment
from manager.models import CollectMod
from manager.models import CommentForum
from manager.models import Changelogs
from manager.models import File
from manager.models import Image
from manager.models import ListChange
from manager.models import Article
from manager.models import Mod
from manager.models import ModPageActivity
from manager.models import Video
from manager.models import Tag
from manager.models import TopicForum
from manager.models import Post
from manager.models import PageViews, Game, Mod, Downloads, Endorsements
import json
import urllib

warnings.filterwarnings("ignore", category=RuntimeWarning)

logger = Logger()
dao = Dao()
network = Network()

reload(sys)
sys.setdefaultencoding('utf8')
sys.setrecursionlimit(20000)

COLLECT_BUGS_RETRY_AFTER = None
COLLECT_BUGS_DISABLED = False

collect_bugs = COLLECT_BUGS

class ModCollector:
    TESTING = False
    DEBUG = False

    proxies = None
    proxy_pool = None
    proxy = None

    mod = None
    collect_mod = None
    tab = None
    browser = None

    collecting_mods_count = 0
    all_mods_count = 0
    mods_count = 0
    all_mods_count = 0
    progress_msg_len = 0

    image_len = 0
    count_pages = 0
    count_total_pages = 0

    video_len = 0
    count_videos = 0
    total_videos = 0

    count_logs_len = 0
    count_logs = 0

    count_forum_comments = 0
    count_forum_topics = 0
    count_forum_len = 0
    count_forum_len_com = 0

    page_log_user = 0
    page_log_author = 0

    global setDateTimeNow
    global getHeadlessBrowser
    global formatDescribeMonth
    global tranformationOfComputerMeasureUnit
    global tranformationAmount
    global getPagingNumber
    global formateDateAM_PM
    global tab_name

    def __init__(self):
        global atexit
        atexit.register(self.exit)
        return

    def exit(self):
        try:
            if self.browser:
                self.browser.quit()
            self.stop_mod_collecting(self.collect_mod)
            logger.info("\nEnd of execution.")
            sys.exit(0)
        except SystemExit:
            os._exit(0)

    # Ordem da captura
    def stop_mod_collecting(self, c_mod):
        if (self.TESTING == False) and self.tab and c_mod:
            if self.tab == FILES:
                if self.browser:
                    self.browser.quit()
                c_mod.collecting_files = False
                c_mod.save(update_fields=["collecting_files"])
            elif self.tab == IMAGES:
                c_mod.collecting_images = False
                c_mod.save(update_fields=["collecting_images"])
            elif self.tab == VIDEOS:
                c_mod.collecting_videos = False
                c_mod.save(update_fields=["collecting_videos"])
            elif self.tab == ARTICLES:
                c_mod.collecting_articles = False
                c_mod.save(update_fields=["collecting_articles"])
            elif self.tab == POSTS:
                c_mod.collecting_posts = False
                c_mod.save(update_fields=["collecting_posts"])
            elif self.tab == FORUM:
                c_mod.collecting_forum = False
                c_mod.save(update_fields=["collecting_forum"])
            elif self.tab == BUGS:
                c_mod.collecting_bugs = False
                c_mod.save(update_fields=["collecting_bugs"])
            elif self.tab == LOGS:
                c_mod.collecting_logs = False
                c_mod.save(update_fields=["collecting_logs"])
            elif self.tab == STATS:
                c_mod.collecting_statistics = False
                c_mod.save(update_fields=["collecting_statistics"])
        return


    def collect_mod(self, shared_dict):
        collect_mod = None
        # print "Process:" + str(os.getpid())
        try:
            self.all_mods_count = dao.count_all_mods()

            self.mods_count = dao.count_complete_collect_mod()
            # while True:

            collect_mod = dao.get_next_incomplete_mod(collect_bugs)

            if not collect_mod:
                self.collecting_mods_count = dao.count_collecting_mods()
                if self.collecting_mods_count == 0:
                    logger.success("\nMod's collect finished.")
                    shared_dict[1] = "stop"
                    return

            # print ""
            # self.mem()

            self.collect_mod_tabs(collect_mod)
            return

        except KeyboardInterrupt:
            shared_dict[1] = "stop"
            if self.browser:
                self.browser.quit()
            return

        except Exception as e:
            if self.browser:
                self.browser.quit()
            self.stop_mod_collecting(collect_mod)
            str_id_mod = "."
            if collect_mod:
                str_id_mod += " Mod id:" + str(collect_mod.id_mod_id)
            logger.error("\ncollect_mods_loop Exception", str_id_mod)

            _, _, tb = sys.exc_info()
            filename, lineno, funname, line = traceback.extract_tb(tb)[-1]
            print '{}:{}, in {}\n    {}'.format(filename, lineno, funname, line)
            traceback.print_exc()
            shared_dict[1] = "stop"
        return

    def collect_mods_loop2(self):
        logger.info("\n -------------------------- Collecting Mod's Tab's ------------------------- ")

        shared_dict = mp.Manager().dict()
        shared_dict[1] = "run"
        while True:
            try:
                # logger.success("\n", shared_dict['state'])
                proc = mp.Process(target=self.collect_mod, args=(shared_dict,))
                proc.start()
                proc.join()
                if shared_dict[1] == 'stop':
                    break
            except Exception as e:
                if self.browser:
                    self.browser.quit()
                raise e
                break
        logger.info(" ----------------------------- Collect finished ---------------------------- ")
        return

# ----------------------------------- Coleta das Abas do Mod ---------------------------------------------------------------------
    def test_collect_mod(self, id_mod, mod_url=None):
        try:
            logger.info(" ------------- Collecting Mod Test ----------------- ")

            self.all_mods_count = dao.count_all_mods()
            self.mods_count = dao.count_complete_collect_mod()

            if id_mod:
                self.collect_mod_tabs(None, id_mod)
            elif mod_url:
                mod = Mod.objects.filter(url=mod_url)
                if mod and len(mod) > 0:
                    self.collect_mod_tabs(None, mod[0].id)

            logger.info("\n------------------ Collect finished ---------------- ")
        except KeyboardInterrupt:
            if self.browser:
                self.browser.quit()
            self.exit()
        except Exception as e:
            if self.browser:
                self.browser.quit()
            self.stop_mod_collecting(self.collect_mod)
            str_id_mod = "."
            if self.collect_mod:
                str_id_mod += " Mod id:" + str(self.collect_mod.id_mod_id)
            logger.error("\ntest_collect_mod Exception", str_id_mod)

            _, _, tb = sys.exc_info()
            filename, lineno, funname, line = traceback.extract_tb(tb)[-1]
            print '{}:{}, in {}\n    {}'.format(filename, lineno, funname, line)
            traceback.print_exc()

    def collect_mods_loop(self):
        start_time = time.time()
        logger.info("\n -------------------------- Collecting Mod's Tab's ------------------------- ")
        collect_mod = None
        try:
            self.all_mods_count = dao.count_all_mods()

            self.mods_count = dao.count_complete_collect_mod()
            while True:
                collect_mod = dao.get_next_incomplete_mod(collect_bugs)
                if not collect_mod:
                    self.collecting_mods_count = dao.count_collecting_mods()
                    if self.collecting_mods_count == 0:
                        logger.success("\nMod's collect finished.")
                        break
                    else:
                        logger.info("\nThere are no mod available to collect.")
                        logger.info("Processing mods: " + str(self.collecting_mods_count)
                            + " awaiting completion...")
                        logger.wait_message("Next check in 2 minutes.", 120)
                        continue

                # print ""
                # self.mem()

                self.collect_mod_tabs(collect_mod)
                # self.stop_mod_collecting(collect_mod)
                # self.mods_count += 1
                # print ""
        except KeyboardInterrupt:
            if self.browser:
                self.browser.quit()
            self.exit()
        except Exception as e:
            if self.browser:
                self.browser.quit()
            self.stop_mod_collecting(collect_mod)
            str_id_mod = "."
            if collect_mod:
                str_id_mod += " Mod id:" + str(collect_mod.id_mod_id)
            logger.error("\ncollect_mods_loop Exception", str_id_mod)

            _, _, tb = sys.exc_info()
            filename, lineno, funname, line = traceback.extract_tb(tb)[-1]
            print '{}:{}, in {}\n    {}'.format(filename, lineno, funname, line)
            traceback.print_exc()

        if start_time:
            logger.info("\nCollect time: %.0f second(s)." % (time.time() - start_time))
        logger.info(" ----------------------------- Collect finished ---------------------------- ")
        return

    def collect_mod_tabs(self, collect_mod=None, mod_id=None):
        global COLLECT_BUGS_RETRY_AFTER
        global COLLECT_BUGS_DISABLED
        global collect_bugs

        # Get CollectMod
        if mod_id:
            c_mod = dao.get_collect_mod_by_id(mod_id)

            if not c_mod:
                logger.info("\nMod with id:" + str(mod_id) + " not Found.")
                return
            self.collect_mod = c_mod
        elif collect_mod:
            self.collect_mod = collect_mod
        else:
            c_mod = dao.get_next_incomplete_mod()
            if not c_mod:
                logger.info("\nCollect finished!")
                return
            self.collect_mod = c_mod

        # Update Collect Mod
        self.collect_mod = CollectMod.objects.get(id_mod_id = self.collect_mod.id_mod_id)

        # Get Next Tab
        next_tab = get_next_incomplete_tab(self.collect_mod, collect_bugs)
        if not next_tab:
            # logger.info("\nMod with id:" + str(self.collect_mod.id_mod_id) + " already completed.")
            return

        #  Status
        self.mods_count = dao.count_complete_collect_mod()
        status_count = "%d" % self.mods_count + "/" + "%d" % self.all_mods_count + " M:" + str(self.collect_mod.id_mod_id) + " T:" + tab_name(next_tab) + " "
        progress = logger.get_progress_bar(self.mods_count, self.all_mods_count, 10, True, "", status_count)
        logger.print_clear(progress)
        # logger.print_inline(progress, self.progress_msg_len)
        # self.progress_msg_len = len(progress)

        # Debug
        # if self.DEBUG:
        #     logger.info("\nNext Tab:" + str(next_tab))
        #     logger.info("Mod id:" + str(self.collect_mod.id_mod_id))

        mod_tab = dao.get_mod_tab_by_id(self.collect_mod.id_mod_id)

        if (COLLECT_BUGS_DISABLED == True) and (time.time() > COLLECT_BUGS_RETRY_AFTER):
            COLLECT_BUGS_RETRY_AFTER = None
            COLLECT_BUGS_DISABLED = False
            collect_bugs = True
            # logger.success("\nBug Collect Enabled")

        if next_tab == FILES:
            self.collect_tab_files(self.collect_mod)
        elif next_tab == IMAGES:
            self.collect_tab_images(self.collect_mod)
        elif next_tab == VIDEOS:
            self.collect_tab_videos(self.collect_mod)
        elif next_tab == FORUM:
            self.collect_tab_forum(self.collect_mod)
        elif next_tab == ARTICLES:
            self.collect_tab_articles(self.collect_mod)
        elif next_tab == BUGS:
            self.collect_tab_bugs(self.collect_mod)
        elif next_tab == LOGS:
            self.collect_tab_logs(self.collect_mod)
        elif next_tab == POSTS:
            self.collect_tab_post(self.collect_mod)
        elif next_tab == STATS:
            self.collect_tab_stats(self.collect_mod)
        return

# ----------------------------------- Coleta de Files ---------------------------------------------------------------------
    def collect_tab_files(self, c_mod):
        TESTING = False
        DEBUG = False

        try:
            count_files = 0
            str_file_len = 0

            c_mod = CollectMod.objects.get(id_mod_id = c_mod.id_mod_id)
            if c_mod.collecting_files == True:
                return

            self.tab = FILES

            if TESTING == False:
                started = dao.enable_collecting_tab(self.tab, c_mod.id_mod_id)
                if not started:
                    self.tab = None
                    return

            self.browser = getHeadlessBrowser()

            c_mod.begin_date = setDateTimeNow()
            c_mod.save(update_fields=["begin_date"])

            tab_url = c_mod.id_mod.url + '?tab=files'
            # if DEBUG:
            #     logger.info('\n', tab_url)

            soup = network.get_tab_files_page_soup(c_mod, tab_url, self.browser)
            if c_mod.error:
                logger.error("\nMod com erro. id:", c_mod.id_mod_id, " Erro:", c_mod.error_msg)

                if TESTING == False:
                    c_mod.save(update_fields=["error_msg", "error"])

                self.stop_mod_collecting(c_mod)
                self.browser.quit()
                self.tab = None
                return

            if c_mod.files_finalized == True:
                if not TESTING:
                    c_mod.save(update_fields=["files_finalized"])

                self.browser.quit()
                self.stop_mod_collecting(c_mod)
                self.tab = None
                return

            # Check network Error
            if soup == None or not soup.getText():
                logger.info("\nFalha na requisição dá página do Mod. Id:" + str(c_mod.id_mod_id) + " Url:" + tab_url)
                logger.wait_message("Nova Tentativa em ", 15, post=" segundos.")
                self.stop_mod_collecting(c_mod)
                self.browser.quit()
                self.tab = None
                return

            # if DEBUG:
            #     logger.info("\nFiles Collec Starting. Mod:", c_mod.id_mod_id)
            #     logger.info("Url: ", tab_url)
            #     logger.success("Page content OK")

            modObj = c_mod.id_mod

            list_files = soup.find_all('div', attrs={'class': 'tabbed-section tabbed-block files-tabs'})

            count_all_files = 0
            for files in list_files:
                nameTypeFile = files.h2.text.encode()
                if nameTypeFile.__eq__("Miscellaneous files") or nameTypeFile.__eq__("Old files"):
                    dadosFileMain = files.findAll('dt', attrs={'class': "clearfix"})
                else:
                    dadosFileMain = files.findAll('dt', attrs={'class': "clearfix accopen"})
                count_all_files += len(dadosFileMain)


            files_list = []

            for files in list_files:
                nameTypeFile = files.h2.text.encode()

                # if DEBUG:
                #     logger.info("nameTypeFile: ", nameTypeFile)

                if nameTypeFile.__eq__("Miscellaneous files") or nameTypeFile.__eq__("Old files"):
                    dadosFileMain = files.findAll('dt', attrs={'class': "clearfix"})
                else:
                    dadosFileMain = files.findAll('dt', attrs={'class': "clearfix accopen"})

                for listMain in dadosFileMain:
                    fileObjt = File()
                    fileObjt.begin_date = setDateTimeNow()

                    fileObjt.miscellauneous_file = False
                    fileObjt.main_file = False
                    fileObjt.update_file = False
                    fileObjt.optional_file = False
                    fileObjt.old_file = False

                    if nameTypeFile.__eq__("Miscellaneous files"):
                        fileObjt.miscellauneous_file = True
                    elif (nameTypeFile.__eq__("Old files")):
                        fileObjt.old_file = True
                    elif nameTypeFile.__eq__("Main files"):
                        fileObjt.main_file = True
                    elif nameTypeFile.__eq__("Optional files"):
                        fileObjt.optional_file = True
                    elif nameTypeFile.__eq__("Update files"):
                        fileObjt.update_file = True
                    # else:
                    #     print nameTypeFile + " Arquivo desconhecido [ CORRECAO ]"

                    # if DEBUG:
                    #     logger.info("nameTypeFile: ", nameTypeFile)

                    try:

                        listSpan = listMain.findAll('span')
                        if listSpan and len(listSpan) > 2:
                            fileObjt.name = listSpan[2].text.encode('utf-8')
                            if len(listSpan) > 4:
                                listDateStat = listSpan[4].findAll('div', attrs={'class': 'statitem'})
                                for listDate in listDateStat:

                                    text = listDate.text.strip("\n").split("\n")

                                    if text and len(text) > 0:
                                        text_0 = text[0].encode()
                                        if text_0.__eq__("Version"):
                                            if len(text) > 2:
                                                if text[2] and text[2] != ' ' and text[2] != '':
                                                    fileObjt.version = text[2].encode()
                                                elif len(text) > 3:
                                                    fileObjt.version = text[3].encode()
                                            else:
                                                fileObjt.version = "NOT VERSION"
                                        elif len(text) > 1:
                                            text_1 = text[1].encode()
                                            if text_0.__eq__("Date uploaded"):
                                                fileObjt.uploaded_date = formatDescribeMonth(text_1)
                                            elif text_0.__eq__("File size"):
                                                fileObjt.file_size = tranformationOfComputerMeasureUnit(text_1)
                                            elif text_0.__eq__("Unique DLs"):
                                                if text_1.strip() == '-':
                                                    fileObjt.unique_dls = 0
                                                else:
                                                    fileObjt.unique_dls = tranformationAmount(text_1)
                                            elif text_0.__eq__("Total DLs"):
                                                if text_1.strip() == '-':
                                                    fileObjt.total_dls = 0
                                                else:
                                                    fileObjt.total_dls = tranformationAmount(text_1)
                                            # else:
                                            #     print "Nova versao" + text_0

                        fileObjt.mod = modObj
                        # if Mod.objects.filter(name=modObj.name,url=modObj.url):
                        #     modAux = Mod.objects.get(url=modObj.url)
                        #     fileObjt.mod = modAux
                        # else:
                        #     logger.error("\nErro ao associar Mod ao Arquivo. Mod ID:", c_mod.id_mod_id)

                        fileObjt.finish_date = setDateTimeNow()

                        files_list.append(fileObjt)

                        # if not TESTING:
                        #     if DEBUG:
                        # logger.info("miscellauneous_file: ", fileObjt.miscellauneous_file)
                        # logger.info("old_file: ", fileObjt.old_file)
                        # logger.info("main_file: ", fileObjt.main_file)
                        # logger.info("optional_file: ", fileObjt.optional_file)
                        # logger.info("update_file: ", fileObjt.update_file)
                        # logger.info("name: ", fileObjt.name)
                        # logger.info("version: ", fileObjt.version)
                        # logger.info("uploaded_date: ", fileObjt.uploaded_date)
                        # logger.info("file_size: ", fileObjt.file_size)
                        # logger.info("unique_dls: ", fileObjt.unique_dls)
                        # logger.info("total_dls: ", fileObjt.total_dls)
                        # logger.info("mod: ", fileObjt.mod)
                        # logger.info("mod_id: ", fileObjt.mod_id)
                        # logger.info("finish_date: ", fileObjt.finish_date)

                        # if not TESTING:
                            # fileObjt.save()

                        # saved_file = dao.get_file(fileObjt)
                        # if saved_file == None:
                        #     if not TESTING:
                        #         fileObjt.save()
                        # count_files += 1

                        # Status
                        str_file_count = " Files:" + str(count_files) + "/" + str(count_all_files) + " "
                        # progress = logger.get_progress_bar(count_files, count_all_files, 10, False, "", str_file_count)
                        logger.print_inline(str_file_count, str_file_len)
                        str_file_len = len(str_file_count)

                    except Exception as e:
                        logger.info("\nFalha na coleta de Files Mod. Id:" + str(c_mod.id_mod_id))
                        self.stop_mod_collecting(c_mod)
                        if self.browser:
                            self.browser.quit()

                        _, _, tb = sys.exc_info()
                        filename, lineno, funname, line = traceback.extract_tb(tb)[-1]
                        print '{}:{}, in {}\n    {}'.format(filename, lineno, funname, line)
                        self.tab = None
                        return

            if TESTING == False and files_list and len(files_list) > 0:
                try:
                    File.objects.bulk_create(files_list)
                except Exception:
                    self.stop_mod_collecting(c_mod)
                    self.tab = None
                    logger.error("\nException on Saving Files, Mod:", c_mod.id_mod_id)
                    _, _, tb = sys.exc_info()
                    filename, lineno, funname, line = traceback.extract_tb(tb)[-1]
                    print '{}:{}, in {}\n    {}'.format(filename, lineno, funname, line)
                    return
                del files_list[:]

            self.tab = None
            c_mod.collecting_files = False
            c_mod.files_finalized = True

            if not TESTING:
                c_mod.save(update_fields=["collecting_files", "files_finalized"])

            self.browser.quit()
            # logger.success("Coleta de Files Finalizada. Mod id:", c_mod.id_mod_id)

        except Exception as e:
            self.stop_mod_collecting(c_mod)
            logger.error("\ncollect_tab_files Exception.")
            logger.error("Falha na coleta de Files. Mod id:", c_mod.id_mod_id)
            if self.browser:
                self.browser.quit()

            _, _, tb = sys.exc_info()
            filename, lineno, funname, line = traceback.extract_tb(tb)[-1]
            print '{}:{}, in {}\n    {}'.format(filename, lineno, funname, line)
            # traceback.print_exc()
            self.tab = None
            return

# ----------------------------------- Coleta de Forum ---------------------------------------------------------------------
    def collect_tab_forum(self, c_mod, start_page=None, end_page=None):

        DEBUG = False
        TESTING = False

        c_mod = CollectMod.objects.get(id_mod_id = c_mod.id_mod_id)
        if c_mod.collecting_forum == True:
            # logger.info("\nMod id:", c_mod.id_mod_id, " already collecting forum.")
            return

        if c_mod.forum_finalized == True:
            # logger.info("\nMod id:", c_mod.id_mod_id, " forum collect already completed.")
            return

        self.tab = FORUM

        if TESTING == False:
            started = dao.enable_collecting_tab(self.tab, c_mod.id_mod_id)
            if not started:
                self.tab = None
                return

        # Get Mod Forum Tab Soup
        tab_url = c_mod.id_mod.url + '?tab=forum'
        if DEBUG:
            logger.info("\n", tab_url)

        page_content = network.get_page_content(tab_url)
        if not page_content or len(page_content) == 0:
            logger.error("\nErro ao acessar a página de forum do mod. Id:", c_mod.id_mod_id)
            self.stop_mod_collecting(c_mod)
            return

        soup = BeautifulSoup(page_content, 'lxml')
        if network.check_page_errors(soup, c_mod):
            self.stop_mod_collecting(c_mod)
            return

        #  Start Page Forum
        if c_mod.forum_last_page and c_mod.forum_last_page > 1:
            start_page_forum = c_mod.forum_last_page - 1
        else:
            start_page_forum = 1

        #  Start Page Topic
        if c_mod.last_topic_page and c_mod.last_topic_page > 1:
            start_page_topic = c_mod.last_topic_page - 1
        else:
            start_page_topic = 1

        # Last Topic
        last_topic_url = None
        if c_mod.url_last_topic:
            last_topic_url = c_mod.url_last_topic

        # End Page forum
        pages_forum = None
        pages = soup.find_all("script")
        if pages and len(pages) > 0:
            for page in pages:
                if "$( function(){Filters_Pagination.Load(" in page.text:
                    pages_forum = getPagingNumber(page.string)
                    break

        if not pages_forum:
            # logger.info("\nMod sem Forum. Id:", c_mod.id_mod_id)
            self.tab = None
            c_mod.forum_finalized = True
            c_mod.collecting_forum = False
            if not TESTING:

                c_mod.save(update_fields=["forum_finalized", "collecting_forum"])
            return

        pages_forum = int(pages_forum[-1])

        if DEBUG:
            logger.info("Pages Forum:", pages_forum)

        forum_collected = self.collect_forum(c_mod, start_page_forum, pages_forum, last_topic_url, start_page_topic)
        if forum_collected == False:
            logger.error("\nErro ao coletar forum do mod. Id:", c_mod.id_mod_id)
            self.stop_mod_collecting(c_mod)
            return

        self.tab = None
        c_mod.forum_finalized = True
        c_mod.collecting_forum = False
        if not TESTING:
            c_mod.save(update_fields=["forum_finalized", "collecting_forum"])

        if DEBUG:
            logger.info("\nForum Finalized - Mod id:", c_mod.id_mod_id)

        return

    def collect_forum(self, c_mod, start_page_forum, pages_forum, last_topic_url, start_page_topic):
        DEBUG = False
        TESTING = False

        # last_topic_url = 'https://www.nexusmods.com/skyrim/mods/52248/?tab=forum&topic_id=5778072'

        self.count_forum_topics = dao.count_mod_forum_topics(c_mod.id_mod_id)
        self.count_forum_comments = dao.count_mod_forum_comments(c_mod.id_mod_id)
        self.count_forum_len = 0
        self.count_forum_len_com = 0

        try:
            last_topic_collected = False
            has_last_topic = False
            if last_topic_url:
                has_last_topic = True

            if not (c_mod.id_mod and c_mod.id_mod.game):
                logger.error("\nc_mod without Mod or Game.")
                return False

            nexus_id_game = c_mod.id_mod.game.nexus_id
            nexus_id_mod = c_mod.id_mod.nexus_id_mod

            # Game Without Nexus_id
            if not nexus_id_game:
                c_mod.error = True
                c_mod.error_msg = "Game Without nexus_id"
                if not TESTING:

                    c_mod.save(update_fields=["error", "error_msg"])
                logger.error("\nGame sem nexus_id. Id:", c_mod.id_mod.game.id)
                return False

            # Mod Without Nexus_id
            if not nexus_id_mod:
                c_mod.error = True
                c_mod.error_msg = "Mod Without nexus_id"
                if not TESTING:
                    c_mod.save(update_fields=["error", "error_msg"])
                logger.error("\nMod sem nexus_id. Id:", c_mod.id_mod_id)
                return False

            idMod = c_mod.id_mod_id

            # forum_links = []
            for page_index in range(start_page_forum, pages_forum + 1):

                # Status
                count_msg = "PgT:" + str(page_index) + "/" + str(pages_forum) + " "
                logger.print_inline(count_msg, self.count_forum_len)
                self.count_forum_len = len(count_msg)

                url_forum_page = self.get_mod_forum_page_url(nexus_id_game, nexus_id_mod, page_index)

                if DEBUG:
                    logger.info("\n -- PAGE Forum: ", page_index)
                    # logger.info(url_forum_page)

                if DEBUG:
                    logger.info("Loading Page")

                page_content = network.get_page_content(url_forum_page)
                if not page_content or len(page_content) == 0:
                    logger.error("\nErro ao acessar a página de forum do mod. Id:", c_mod.id_mod_id)
                    logger.error("Url:", url_forum_page)
                    return False

                if DEBUG:
                    logger.info("Page Loaded    ")

                soup = BeautifulSoup(page_content, 'lxml')

                if network.check_page_errors(soup, c_mod):
                    return False

                table = soup.find('table', attrs={'id': 'mod_forum_topics'})

                if not(table and len(table) > 0):
                    # logger.error("\nPágina sem forum do mod. Id:", c_mod.id_mod_id)
                    # logger.error("Url:", url_forum_page)
                    # return False
                    continue

                # Collect Fixed Topics
                if page_index == 1:
                    table_head = table.find('thead')
                    rows = table_head.find_all('tr')
                    self.collect_forum_rows(c_mod, rows, has_last_topic, last_topic_collected, last_topic_url, start_page_topic, nexus_id_game, nexus_id_mod)

                # Collect Not Fixed Topics
                table_body = table.find('tbody')
                rows = table_body.find_all('tr')
                self.collect_forum_rows(c_mod, rows, has_last_topic, last_topic_collected, last_topic_url, start_page_topic, nexus_id_game, nexus_id_mod)

                if DEBUG:
                    logger.info("\nCollected all Forums on page ", page_index,)

                c_mod.forum_last_page = page_index
                if not TESTING:
                    c_mod.save(update_fields=["forum_last_page"])

            return True
        except Exception as e:
            self.stop_mod_collecting(c_mod)
            logger.error("\ncollect_mods_info Exception.")
            _, _, tb = sys.exc_info()
            filename, lineno, funname, line = traceback.extract_tb(tb)[-1]
            print '{}:{}, in {}\n    {}'.format(filename, lineno, funname, line)
            # traceback.print_exc()
            return False

    def collect_forum_rows(self, c_mod, rows, has_last_topic, last_topic_collected, last_topic_url, start_page_topic, nexus_id_game, nexus_id_mod):

        # logger.info("collect_forum_rows")

        DEBUG = False
        TESTING = False

        # count_topics = 0 #3RMV
        # count_topics_save = 0 #3RMV
        for row in rows:

            self.count_forum_topics += 1

            # count_topics += 1 #3RMV
            cols = row.find_all('td')
            if cols and len(cols) > 0:
                forum_url = None
                atags = row.find_all('a', {'class': 'go-to-topic'}, href=True, text=True)
                if atags and len(atags) > 0 and atags[0]:
                    if atags[0]['href'] and len(atags[0]['href']) > 0:
                        forum_url = atags[0]['href']

                if not forum_url:
                    logger.info("\nTopic without Url. Mod Id:", c_mod.id_mod_id)
                    return False

                if DEBUG:
                    logger.info("Topic URL:", forum_url)

                # if forum_url != "https://www.nexusmods.com/skyrim/mods/35470/?tab=forum&topic_id=2228529":
                #     continue

                # Continue jump until reach last collected topic
                if has_last_topic and (not last_topic_collected):
                    if last_topic_url == forum_url:
                        last_topic_collected = True
                    else:
                        if DEBUG:
                            logger.info("Jumping to last collected Topic")
                        continue

                topicForum = self.get_topic_forum_from_table_row(row, atags)
                topicForum.url = forum_url
                topicForum.mod = Mod.objects.get(id=c_mod.id_mod_id)

                if TESTING == False:
                    topicForum.save()
                    c_mod.url_last_topic = topicForum.url
                    c_mod.save(update_fields=["url_last_topic"])


                    # topic_forum_saved = dao.get_topic_forum(topicForum.url)
                    # if topic_forum_saved == None:
                    #     topicForum.save()
                    #     c_mod.url_last_topic = topicForum.url
                    #     c_mod.save()
                    # else:
                    #     topicForum = topic_forum_saved

                if DEBUG:
                    # logger.info("begin_date: ", topicForum.begin_date)
                    # logger.info("mod: ", topicForum.mod.id)

                    # logger.info("\nTopic url: ", topicForum.url)
                    logger.info("\nTopic: ", topicForum.id)
                    logger.info("title: ", topicForum.title)
                    # logger.info("description: ", topicForum.description)
                    # logger.info("replies: ", topicForum.replies)
                    # logger.info("views: ", topicForum.views)
                    # logger.info("author: ", topicForum.author)
                    # logger.info("author_url: ", topicForum.author_url)
                    # logger.info("last_post_date: ", topicForum.last_post_date)
                    # logger.info("last_post_user_login: ", topicForum.last_post_user_login)
                    # logger.info("last_post_user_link: ", topicForum.last_post_user_link)
                    # logger.info("last_post_user_name: ", topicForum.last_post_user_name)

                    # logger.info("finish_date: ", topicForum.finish_date)

                comments_collected = self.get_forum_comments(c_mod, topicForum, last_topic_url, start_page_topic, nexus_id_game, nexus_id_mod)
                if not comments_collected:
                    return False


        # logger.success("count_topics / saved:", count_topics, "/", count_topics_save) #2RMV

    def get_topic_forum_from_table_row(self, row, atags):
        cols = row.find_all('td')

        topicForum = TopicForum()
        topicForum.title = atags[0].text.encode()

        topicForum.begin_date = setDateTimeNow()

        td_replies = row.find_all('td', {'class': 'table-replies'})
        if td_replies and len(td_replies) > 0:
            topicForum.replies = int(td_replies[0].text.encode('utf-8').replace(",",""))

        td_table_views = row.find_all('td', {'class': 'table-views'})
        if td_table_views and len(td_table_views) > 0:
            topicForum.views = int(td_table_views[0].text.encode('utf-8').replace(",",""))

        # td_table_author = row.find_all('td', {'class': 'table-author'}, href=True, text=True)

        atags_table_author = row.find_all('a', {'class': 'table-link'}, href=True, text=True)
        if atags_table_author and len(atags_table_author) > 0:
            topicForum.author = atags_table_author[0].text.encode('utf-8')
            if atags_table_author[0] and atags_table_author[0]['href']:
                topicForum.author_url = atags_table_author[0]['href']

        td_table_post = row.find_all('td', {'class': 'table-post'})
        if td_table_post and len(td_table_post) > 0:
            date = str(td_table_post[0].text).split(",")[0]
            date = re.sub(r"^\s+", "", date, flags=re.UNICODE)
            topicForum.last_post_date = str(formatDescribedDate(date))

            user = td_table_post[0].text.encode('utf-8').split(",")[1].split(" ")[2]
            user = re.sub(r"\s+", "", user, flags=re.UNICODE)
            topicForum.last_post_user_login = unicode(user, errors='replace')

        atags_table_posts = row.find_all('a', {'class': 'table-link'}, href=True, text=True)
        if atags_table_posts and len(atags_table_posts) > 0:
            topicForum.last_post_user_name = atags_table_posts[0].text.encode('utf-8')
            if atags_table_posts[0] and atags_table_posts[0]['href']:
                topicForum.last_post_user_link = atags_table_posts[0]['href']

        topicForum.description = " ".encode('utf-8')
        description = row.find('span', {'class': 'table-topic-sub'}, text=True)
        if description and len(description):
            topicForum.description = description.text.encode()

        topicForum.finish_date = setDateTimeNow()

        return topicForum

    def get_forum_comments(self, c_mod, topicForum, last_topic_url, start_page_topic, nexus_id_game, nexus_id_mod):

        DEBUG = False
        TESTING = False

        if DEBUG:
            logger.info("Topic URL:", topicForum.url)

        page_content = network.get_page_content(topicForum.url)
        if not page_content or len(page_content) == 0:
            logger.error("\nErro ao acessar a página do forum.")
            logger.error("Url:", topicForum.url)
            return False

        soup = BeautifulSoup(page_content, 'lxml')

        if network.check_page_errors(soup, c_mod):
            return False

        # TOPIC BLOCKED
        if c_mod.error_msg:
            topicForum.title += ' ' + c_mod.error_msg
            c_mod.error_msg = None
            topicForum.save(update_fields=["title"])

        id_topic = topicForum.url.rsplit('=', 1)[-1]

        if DEBUG:
            logger.info("\nTopic ID:", id_topic)

        topic_forum = topicForum

        start_page = 1
        if last_topic_url and (topicForum.url == last_topic_url) and (start_page_topic > 2):
            start_page = start_page_topic - 1

        # End Page Topic
        pages_topic = None
        pages = soup.find_all("script")
        if pages and len(pages) > 0:
            for page in pages:
                if "$( function(){Filters_Pagination.Load(" in page.text:
                    pages_topic = getPagingNumber(page.string)
                    break

        if DEBUG:
            logger.info("Topic Pages:", pages_topic)


        # cnt_tst = 0

        if pages_topic and len(pages_topic) > 0:
            count_pages_topic = int(pages_topic[-1])

            if DEBUG:
                logger.info("\nPages Topic:", count_pages_topic)

            for page_index in range(start_page, count_pages_topic + 1):

                # Status
                count_msg = " T:" + str(self.count_forum_topics) + " PgC:" + str(page_index) + "/" + str(count_pages_topic) + " " + str(self.count_forum_comments) + " "
                logger.print_inline(count_msg, self.count_forum_len_com)
                self.count_forum_len_com = len(count_msg)

                if DEBUG:
                    logger.info("Page Topic:", page_index)

                topic_url = self.get_forum_topic_page_url(nexus_id_game, nexus_id_mod, id_topic, page_index)

                if DEBUG:
                    logger.info("Loading Topic")

                topic_page_content = network.get_page_content(topic_url)
                if not topic_page_content or len(topic_page_content) == 0:
                    logger.error("\nErro ao acessar o tópico do forum.")
                    logger.error("Url:", topic_url)
                    return False

                if DEBUG:
                    logger.info("Page loaded")

                soup_topic = BeautifulSoup(topic_page_content, 'lxml')

                if network.check_page_errors(soup_topic, c_mod):
                    return False

                ol = soup_topic.find('ol')
                if ol and len(ol) > 0:
                    list_comment = ol.find_all('li', {'class': 'comment'})
                    # print "Numero TOTAL DE COMENTARIOS: " + str(len(list_comment))

                    # verifica se comentario tem resposta
                    for li in list_comment:

                        # logger.info("li:", count_comment)
                        # primeiro nivel quando tem respostas
                        if li.find_all('ol', {'class': 'comment-kids'}):
                            head_comment = self.get_comment_content_head(li)
                            # logger.info("head_comment Done")
                            # cnt_tst += 1
                            # logger.info("\n --> Head Answer SAVE:",cnt_tst, " -----------------------------------------")
                            paiComment = self.save_comment(head_comment, topic_forum.id, None, None)
                            # logger.info(" --> SAVED:",cnt_tst, " -----------------------------------------")


                            self.count_forum_comments += 1

                            respostas = li.find_all('ol', {'class': 'comment-kids'})[0].find_all('li', {'class': 'comment'})

                            # segundo nivel quando tem respostas
                            for li2 in respostas:
                                comment = self.get_comment_content(li2)
                                # cnt_tst += 1
                                # logger.info("\n --> Answer SAVE:",cnt_tst, " -----------------------------------------")
                                pai = self.get_comment_content(li)['id'].split("-")[1]
                                self.save_comment(comment, topic_forum.id, pai, paiComment.id)
                                # logger.info(" --> SAVED:",cnt_tst, " -----------------------------------------")

                                self.count_forum_comments += 1

                        # quando nao tem respostas
                        else:
                            comment = self.get_comment_content(li)
                            # cnt_tst += 1
                            # logger.info("\n --> Not Answer SAVE:",cnt_tst, " -----------------------------------------")
                            self.save_comment(comment, topic_forum.id, None, None)
                            # logger.info(" --> SAVED:",cnt_tst, " -----------------------------------------")
                            self.count_forum_comments += 1

                c_mod.last_topic_page = page_index
                if not TESTING:
                    c_mod.save(update_fields=["last_topic_page"])
        return True

    def save_comment(self, dict, topic_forum_id, pai, pai_id):

        TESTING = False
        DEBUG = False

        id = dict['id'].split('-')[1]

        # comment_saved = dao.get_comment(id)
        # if comment_saved == None:

        comment = CommentForum()
        comment.begin_date = setDateTimeNow()
        comment.topic_forum_id = topic_forum_id
        comment.reply_comment_forum = pai
        comment.id_reply_comment_forum = pai_id
        comment.comment_id = id
        comment.user_url = dict['hrefuser']
        comment.user_name = dict['user']
        comment.status= dict['userstatus']
        comment.posts=int(dict['posts'].split(" ")[0].encode('utf-8').replace(",",""))
        comment.kudos=int(dict['kudos'].split(" ")[0].encode('utf-8').replace(",",""))
        comment.content=dict['content']
        comment.date=formateDateAM_PM(dict['date'])
        comment.finish_date = setDateTimeNow()

        if not TESTING:
            comment.save()
            if DEBUG:
                # logger.info("Forum ID: ", comment.topic_forum_id)
                logger.info("COMENT ID: ", comment.id)
                # logger.info("reply: ", comment.reply_comment_forum)
                if pai_id:
                    logger.success("reply_id: ", comment.id_reply_comment_forum)
            #     logger.info("comment_id: ", comment.comment_id)
            #     logger.info("user_url: ", comment.user_url)
            #     logger.info("user_name: ", comment.user_name)
            #     logger.info("status: ", comment.status)
            #     logger.info("posts: ", comment.posts)
            #     logger.info("kudos: ", comment.kudos)
            #     logger.info("content: ", comment.content)
            #     logger.info("date: ", comment.date)

        if not TESTING:
            return comment
        return None

    def get_comment_content_head(self, li):
        dict = {}
        # print "Comments IDS: " + li['id']
        dict['id'] = li['id']
        divs_comment_head = li.find_all('div', {'class': 'comment-head clearfix'})
        for div in divs_comment_head:
            # logger.info("for 1")
            atags_comment_head = div.find_all('a', {'class': 'comment-user'})
            # HERF indicando o usuario que criou um topico no forum
            # print "Href " + atags_comment_head[0]['href']
            dict['href'] = atags_comment_head[0]['href']
            spans_comment_details = div.find_all('span', {'class': 'comment-name'})
            atag_comment_details = spans_comment_details[0].find_all('a')
            # HERF indicando o usuario que criou um topico no forum
            # print "HREF USER :" + atag_comment_details[0]['href']
            dict['hrefuser'] = atag_comment_details[0]['href']
            # print "USER :" + atag_comment_details[0].text
            dict['user'] = atag_comment_details[0].text
            uls = div.find_all(lambda tag: tag.name == 'ul' and tag.get('class') == ['clearfix'])
            #uls = div.find_all('ul', {'class': 'clearfix'})
            for ul in uls:
                # logger.info("for 2")
                lis = ul.find_all('li')
                if len(lis) != 0:
                    # print "User Status: " + lis[0].text
                    dict['userstatus'] = lis[0].text
                    # print "Posts: " + lis[1].text
                    dict['posts'] = lis[1].text
                    # print "Kudos: " + lis[2].text
                    dict['kudos'] = lis[2].text
            div_comment = li.find('div', {'class': 'comment-content'})
            times = div_comment.find_all('time')
            for tim in times:
                # logger.info("for 3")
                atags = tim.find_all('a')
                for atag in atags:
                    # logger.info("for 4")
                    # print "Data Hora: " + atag.text
                    dict['date'] = atag.text
                    comment = div_comment.find_all('div', {'class': 'comment-content-text'})
                    # print "Print comment: " + comment[0].text
                    dict['content'] = comment[0].text
            break
        return dict

    def get_comment_content(self, li):
        dict = {}
        # print "Comments IDS: " + li['id']
        dict['id'] = li['id']
        divs_comment_head = li.find_all('div', {'class': 'comment-head clearfix'})
        for div in divs_comment_head:
            # logger.info("for 5")
            atags_comment_head = div.find_all('a', {'class': 'comment-user'})
            # HERF indicando o usuario que criou um topico no forum
            # print "Href " + atags_comment_head[0]['href']
            dict['href'] = atags_comment_head[0]['href']
            spans_comment_details = div.find_all('span', {'class': 'comment-name'})
            atag_comment_details = spans_comment_details[0].find_all('a')
            # HERF indicando o usuario que criou um topico no forum
            # print "HREF USER :" + atag_comment_details[0]['href']
            dict['hrefuser'] = atag_comment_details[0]['href']
            # print "USER :" + atag_comment_details[0].text
            dict['user'] = atag_comment_details[0].text
            uls = div.find_all(lambda tag: tag.name == 'ul' and tag.get('class') == ['clearfix'])
            #uls = div.find_all('ul', {'class': 'clearfix'})
            for ul in uls:
                # logger.info("for 6")
                lis = ul.find_all('li')
                if len(lis) != 0:
                    # print "User Status: " + lis[0].text
                    dict['userstatus'] = lis[0].text
                    # print "Posts: " + lis[1].text
                    dict['posts'] = lis[1].text
                    # print "Kudos: " + lis[2].text
                    dict['kudos'] = lis[2].text
            divs_comment_content = li.find_all('div', {'class': 'comment-content'})
            for div_comment in divs_comment_content:
                # logger.info("for 7")
                times = div_comment.find_all('time')
                for tim in times:
                    # logger.info("for 8")
                    atags = tim.find_all('a')
                    for atag in atags:
                        # logger.info("for 9")
                        # print "Data Hora: " + atag.text
                        dict['date'] = atag.text
                        comment = div_comment.find_all('div', {'class': 'comment-content-text'})
                        # print "Print comment: " + comment[0].text
                        dict['content'] = comment[0].text
        return dict

    def get_mod_forum_page_url(self, nexus_id, nexus_id_mod, page):
        # https://www.nexusmods.com/Core/Libs/Common/Widgets/ModTopicsTab?RH_ModTopicsTab=game_id:110,id:19281,page_size:12,page:2

        return ("https://www.nexusmods.com/Core/Libs/Common/Widgets/ModTopicsTab?"
                + "RH_ModTopicsTab=game_id:" + str(nexus_id)
                + ",id:" + str(nexus_id_mod)
                + ",page_size:12,"
                + "page:" + str(page))

    def get_forum_topic_page_url(self, nexus_id, nexus_id_mod, thread_id, page):
        return ("https://www.nexusmods.com/Core/Libs/Common/Widgets/CommentContainer?"
                + "RH_CommentContainer=game_id:" + str(nexus_id)
                + ",object_id:" + str(nexus_id_mod)
                + ",object_type:1,thread_id:" + str(thread_id)
                + ",tabbed:1,skip_opening_post:0,display_title:1,page_size:10"
                + ",page:" + str(page))


# ----------------------------------- Coleta de Images ---------------------------------------------------------------------
    def collect_tab_images(self, c_mod, start_page=None, end_page=None):

        DEBUG = False
        TESTING = False

        self.image_len = 0
        self.count_pages = 0
        self.count_total_pages = 0

        c_mod = CollectMod.objects.get(id_mod_id = c_mod.id_mod_id)
        if c_mod.collecting_images == True:
            return

        if c_mod.images_finalized == True:
            # logger.info("Mod id:", c_mod.id_mod_id, " images collect already completed.")
            return

        self.tab = IMAGES

        if TESTING == False:
            started = dao.enable_collecting_tab(self.tab, c_mod.id_mod_id)
            if not started:
                self.tab = None
                return


        # Get Mod Images Tab Soup
        tab_url = c_mod.id_mod.url + '?tab=images'
        # if DEBUG:
        #     logger.info(tab_url)

        page_content = network.get_page_content(tab_url)
        if not page_content or len(page_content) == 0:
            logger.error("\nErro ao acessar a página de imagens do mod. Id:", c_mod.id_mod_id)
            self.stop_mod_collecting(c_mod)
            return

        soup = BeautifulSoup(page_content, 'lxml')

        if network.check_page_errors(soup, c_mod):
            self.stop_mod_collecting(c_mod)
            return

        pages_author = None
        pages_user = None

        # End Page Author
        divImageAuthor = soup.find("div", attrs={'id': 'list-modimages-1'})
        if divImageAuthor and len(divImageAuthor) > 0:
            scriptAuthor = divImageAuthor.find_all("script")
            if scriptAuthor and len(scriptAuthor) > 0:
                for aux2 in scriptAuthor:
                    if '"page"' in aux2.text:
                        pages_author = getPagingNumber2(aux2.string)
                        self.count_total_pages += pages_author
                        break

        # End Page USER
        divImageUser = soup.find("div", attrs={'id': 'list-modimages-2'})
        if divImageUser and len(divImageUser) > 0:
            scriptUser = divImageUser.find_all("script")
            if scriptUser and len(scriptUser) > 0:
                for aux2 in scriptUser:
                    if '"page"' in aux2.text:
                        pages_user = getPagingNumber2(aux2.string)
                        self.count_total_pages += pages_user
                        break


        # -------------------------------- COLLECT AUTHOR IMAGES --------------------------------------
        if c_mod.images_author_finalized == False:
            #  Start Page Author
            if c_mod.images_author_last_page and c_mod.images_author_last_page > 1:
                author_start_page = c_mod.images_author_last_page - 1
            else:
                author_start_page = 1

            if pages_author and pages_author > 0:
                count_pages_author = pages_author

                # if DEBUG:
                #     logger.info("\nPages Author:", count_pages_author)

                author_collected = self.collect_images(c_mod, author_start_page, count_pages_author, "AUTHOR")
                if author_collected == False:
                    logger.error("\nErro ao coletar Author Images do mod. Id:", c_mod.id_mod_id)
                    self.stop_mod_collecting(c_mod)
                    return

            c_mod.images_author_finalized = True
            if TESTING == False:
                c_mod.save(update_fields=["images_author_finalized"])

        # -------------------------------- COLLECT USER IMAGES ----------------------------------------
        if c_mod.images_user_finalized == False:

            #  Start Page User
            if c_mod.images_user_last_page and c_mod.images_user_last_page > 1:
                user_start_page = c_mod.images_user_last_page - 1
            else:
                user_start_page = 1

            if pages_user and pages_user > 0:
                count_pages_user = pages_user

                # if DEBUG:
                #     logger.info("\nPages User:", count_pages_user)

                user_collected = self.collect_images(c_mod, user_start_page, count_pages_user, "USER")
                if user_collected == False:
                    logger.error("\nErro ao coletar User Images do mod. Id:", c_mod.id_mod_id)
                    self.stop_mod_collecting(c_mod)
                    return

            c_mod.images_user_finalized = True
            if TESTING == False:
                c_mod.save(update_fields=["images_user_finalized"])

        c_mod.collecting_images = False
        self.tab = None

        if (c_mod.images_author_finalized == True and c_mod.images_user_finalized == True):
            c_mod.images_finalized = True
            # if DEBUG:
            #     logger.info("\nImages Finalized - Mod id:", c_mod.id_mod_id)
        if TESTING == False:
            c_mod.save(update_fields=["collecting_images", "images_finalized"])

    def collect_images(self, c_mod, start_page, end_page, type):
        DEBUG = False
        TESTING = False

        # if DEBUG:
        #     logger.info("Type ", type)

        if not (c_mod.id_mod and c_mod.id_mod.game):
            logger.error("\nc_mod without Mod or Game.")
            return False

        nexus_id_game = c_mod.id_mod.game.nexus_id
        nexus_id_mod = c_mod.id_mod.nexus_id_mod

        # Game Without Nexus_id
        if not nexus_id_game:
            c_mod.error = True
            c_mod.error_msg = "Game Without nexus_id"
            if TESTING == False:
                c_mod.save(update_fields=["error", "error_msg"])
            logger.error("\nGame sem nexus_id. Id:", c_mod.id_mod.game.id)
            return False

        # Mod Without Nexus_id
        if not nexus_id_mod:
            c_mod.error = True
            c_mod.error_msg = "Mod Without nexus_id"
            if TESTING == False:
                c_mod.save(update_fields=["error", "error_msg"])
            logger.error("\nMod sem nexus_id. Id:", c_mod.id_mod_id)
            return False

        for page_index in range(start_page, end_page + 1):
            self.count_pages += 1

            images_list = []

            # logger.info(type, " Pag:", page_index)

            url_image_page = self.get_mod_image_page_url(nexus_id_game, nexus_id_mod, page_index, type)
            # if DEBUG:
            #     logger.info(url_image_page)

            page_content = network.get_page_content(url_image_page)
            if not page_content or len(page_content) == 0:
                logger.error("\nErro ao acessar a página de imagens do mod. Id:", c_mod.id_mod_id)
                logger.error("Url:", url_image_page)
                return False

            soup = BeautifulSoup(page_content, 'lxml')

            if network.check_page_errors(soup, c_mod):
                return False

            images = None
            listImages = soup.find("ul", attrs={'class': 'tiles tile-flex lg-mod-image-list'})
            if listImages and len(listImages) > 0:
                images = listImages.find_all("li", attrs={'class': 'image-tile image-mod-page user-image-tile'})

            if images and len(images) > 0:
                for image in images:

                    imageObj = Image();
                    imageObj.begin_date = setDateTimeNow()

                    dataString = image.find("span", attrs={'class': 'upload-date'}).text.encode().split("at ")
                    if dataString and len(dataString) > 1:
                        data = dataString[1].strip().split(" ")
                        if data and len(data) > 3:
                            data = datetime.strptime(str(data[3].strip()) + "/" + str(data[2].strip()) + "/"+ str(data[1].strip()) + " " + str(data[0]), '%Y/%b/%d %H:%M')
                            imageObj.uploaded_date = data

                    imageObj.name = image.h3.text.encode('utf-8')
                    imageObj.author = image.find("div", attrs={'class': 'author'}).text.encode('utf-8')

                    # url = image.find('a', {'class': 'mod-image'}, href=True, text=True)['href']
                    imageObj.url = image.find('a', {'class': 'mod-image'}, href=True)['href'].encode()
                    # pprint(imageObj.url)
                    # logger.info(imageObj.url)

                    if type == "USER":
                        imageObj.imagemUser = True
                    elif type == "AUTHOR":
                        imageObj.imagemUser = False

                    if Mod.objects.filter(name=c_mod.id_mod.name, url=c_mod.id_mod.url):
                        #buscar somente o objeto
                        #print modObj.name
                        #print modObj.url
                        modAux = Mod.objects.get(url=c_mod.id_mod.url)
                        #modAux = Mod.objects.filter(url=modObj.url)
                        #modQ = Mod.objects.filter(name=modObj.name)
                        #modAux = modQ.exclude(url=modObj.url)[:1]

                        #modAux = Mod.objects.get(name=modObj.name, url=modObj.url)[:1]
                        imageObj.mod = modAux
                    else:
                        logger.error("\nErro ao associar Mod a Imagem. Id:", c_mod.id_mod_id)
                        return False

                    imageObj.finish_date = setDateTimeNow()

                    images_list.append(imageObj)

                    # if DEBUG:
                    #     logger.info("\n")
                    #     logger.info("uploaded_date: ", imageObj.uploaded_date)
                    #     logger.info("name: ", imageObj.name)
                    #     logger.info("author: ", imageObj.author)
                    #     logger.info("imagemUser: ", imageObj.imagemUser)
                    #     logger.info("imagemUser: ", imageObj.imagemUser)
                    #     logger.info("mod: ", imageObj.mod)
                    #     logger.info("Url: ", imageObj.url)
                    #     logger.info("begin_date: ", imageObj.begin_date)
                    #     logger.info("finish_date: ", imageObj.finish_date)

                    # if TESTING == False:
                    #     imageObj.save()

                        # image_saved = dao.get_image(imageObj)
                        # if image_saved == None:
                        #     imageObj.save()

                    # Status
                    count_msg = " Pages:" + str(self.count_pages) + "/" + str(self.count_total_pages) + "    "
                    logger.print_inline(count_msg, self.image_len)
                    self.image_len = len(count_msg)

                if TESTING == False and images_list and len(images_list) > 0:
                    try:
                        Image.objects.bulk_create(images_list)
                    except Exception:
                        self.stop_mod_collecting(c_mod)
                        logger.error("\nException on Saving Images, Mod:", c_mod.id_mod_id)
                        _, _, tb = sys.exc_info()
                        filename, lineno, funname, line = traceback.extract_tb(tb)[-1]
                        print '{}:{}, in {}\n    {}'.format(filename, lineno, funname, line)
                        return False
                    del images_list[:]

            if TESTING == False:
                if type == "USER":
                    c_mod.images_user_last_page = page_index
                    c_mod.save(update_fields=["images_user_last_page", "error_msg"])
                elif type == "AUTHOR":
                    c_mod.images_author_last_page = page_index
                    c_mod.save(update_fields=["images_author_last_page", "error_msg"])


        return True

    def get_mod_image_page_url(self, nexus_id, nexus_id_mod, page, type):

        # https://www.nexusmods.com/Core/Libs/Common/Widgets/ModImagesList?RH_ModImagesList1=game_id:110,id:19733,page_size:24,1page:1,rh_group_id:1
        # https://www.nexusmods.com/Core/Libs/Common/Widgets/ModImagesList?RH_ModImagesList2=game_id:110,id:19733,page_size:24,2page:2,rh_group_id:2

        if type == "AUTHOR":
            rh_mod = "RH_ModImagesList1"
            rh_group = "1"
        elif type == "USER":
            rh_mod = "RH_ModImagesList2"
            rh_group = "2"

        return ("https://www.nexusmods.com/Core/Libs/Common/Widgets/ModImagesList?"
                + rh_mod + "=game_id:" + str(nexus_id)
                + ",id:" + str(nexus_id_mod)
                + ",page_size:24,"
                + rh_group + "page:" + str(page)
                + ",rh_group_id:" + rh_group)


# ----------------------------------- Coleta de Bugs ---------------------------------------------------------------------
    def collect_tab_bugs(self, c_mod):
        DEBUG = False
        TESTING = False

        c_mod = CollectMod.objects.get(id_mod_id = c_mod.id_mod_id)
        if c_mod.collecting_bugs == True:
            return

        if c_mod.bugs_finalized == True:
            # logger.info("\nMod id:", c_mod.id_mod_id, " bugs collect already completed.")
            return

        self.tab = BUGS

        if TESTING == False:
            started = dao.enable_collecting_tab(self.tab, c_mod.id_mod_id)
            if not started:
                self.tab = None
                return

        # Get Mod Bugs Tab Soup
        tab_url = c_mod.id_mod.url + '?tab=bugs'
        if DEBUG:
            logger.info("\n", tab_url)

        page_content = network.get_page_content(tab_url)
        if not page_content or len(page_content) == 0:
            logger.error("\nErro ao acessar a página de bugs do mod. Id:", c_mod.id_mod_id)
            self.stop_mod_collecting(c_mod)
            return

        soup = BeautifulSoup(page_content, 'lxml')

        if network.check_page_errors(soup, c_mod):
            self.stop_mod_collecting(c_mod)
            return

        #  Start Page
        start_page = 1
        if c_mod.bugs_last_page and c_mod.bugs_last_page > 2:
            start_page = c_mod.bugs_last_page - 1

        # End Page
        datas = soup.find_all("script")
        pages = None
        if datas and len(datas) > 0:
            for data in datas:
                if "$( function(){Filters_Pagination.Load(" in data.text:
                    pages = getPagingNumber(data.string)
                    break

        if pages:
            count_pages = int(pages[-1])

            if DEBUG:
                logger.info("\nPages: ", count_pages)

            bugs_collected = self.collect_bugs(c_mod, start_page, count_pages)
            if bugs_collected == False:
                logger.error("\nErro ao coletar bugs do mod. Id:", c_mod.id_mod_id)
                self.stop_mod_collecting(c_mod)
                return

        if DEBUG == True:
            logger.info("bugs Finalized")
        c_mod.bugs_finalized = True
        c_mod.collecting_bugs = False
        if not TESTING:
            c_mod.save(update_fields=["bugs_finalized", "collecting_bugs"])

        self.tab = None
        return

    def collect_bugs(self, c_mod, start_page, end_page):
        global collect_bugs
        global COLLECT_BUGS_RETRY_AFTER
        global COLLECT_BUGS_DISABLED

        DEBUG = False
        TESTING = False

        if not (c_mod.id_mod and c_mod.id_mod.game):
            logger.error("\nc_mod without Mod or Game.")
            return False

        nexus_id_game = c_mod.id_mod.game.nexus_id
        nexus_id_mod = c_mod.id_mod.nexus_id_mod

        # Game Without Nexus_id
        if not nexus_id_game:
            c_mod.error = True
            c_mod.error_msg = "Game Without nexus_id"
            if not TESTING:
                c_mod.save(update_fields=["error", "error_msg"])
            logger.error("\nGame sem nexus_id. Id:", c_mod.id_mod.game.id)
            return False

        # Mod Without Nexus_id
        if not nexus_id_mod:
            c_mod.error = True
            c_mod.error_msg = "Mod Without nexus_id"
            if not TESTING:
                c_mod.save(update_fields=["error", "error_msg"])
            logger.error("\nMod sem nexus_id. Id:", c_mod.id_mod_id)
            return False

        count = 0
        bugs_len = 0
        count_bug = 0
        count_bug_comment = 0
        for page_index in range(start_page, end_page + 1):

            url_bugs_page = self.get_mod_bug_page_url(nexus_id_game, nexus_id_mod, page_index)
            if DEBUG:
                logger.info("\n", url_bugs_page)

            page_content = network.get_page_content(url_bugs_page)
            if not page_content or len(page_content) == 0:
                logger.error("\nErro ao acessar a página de bugs do mod. Id:", c_mod.id_mod_id)
                logger.error("Url:", url_bugs_page)
                return False

            soup = BeautifulSoup(page_content, 'lxml')

            if network.check_page_errors(soup, c_mod):
                return False

            table = soup.find('table', attrs={'class': 'table forum-bugs flex-table'})
            if not table or len(table) == 0:
                logger.info("\nMod sem Bugs. Id:", c_mod.id_mod_id)
                c_mod.bugs_finalized = True
                c_mod.collecting_bugs = False
                if not TESTING:
                    c_mod.save(update_fields=["bugs_finalized", "collecting_bugs"])
                return True

            table_body = table.find('tbody')
            if table_body and len(table_body) > 0:
                rows = table_body.find_all('tr')
                anterior = 0
                flag = False
                for row in rows:
                    cols = row.find_all('td')
                    if (cols):
                        atags = row.find_all('a', {'class': 'issue-title'}, href=True, text=True)
                        # print row
                        for atag in atags:

                            bug = Bug()
                            bug.begin_date = setDateTimeNow()

                            bug_id = row['data-issue-id']
                            if bug_id:
                                bug.bug_id = int(bug_id.encode())

                                td_status = row.find_all('td', {'class': 'table-bug-status'})
                                if td_status and len(td_status) > 0:
                                    bug.status = td_status[0].text.encode()

                                td_replies = row.find_all('td', {'class': 'table-bug-replies'})
                                if td_replies and len(td_replies) > 0:
                                    bug.replies = td_replies[0].text.encode()

                                td_version = row.find_all('td', {'class': 'table-bug-version'})
                                if td_version and len(td_version) > 0:
                                    bug.version = td_version[0].text.encode()

                                td_priority = row.find_all('td', {'class': 'table-bug-priority'})
                                if td_priority and len(td_priority) > 0:
                                    bug.priority = td_priority[0].text.encode()

                                td_lastpost = row.find_all('td', {'class': 'table-bug-post'})
                                if td_lastpost and len(td_lastpost) > 0:
                                    bug.last_post = formateDateM_AM_PM(td_lastpost[0].text.encode())

                                bug.mod = c_mod.id_mod
                                bug.title = atags[0].text

                                bug.finish_date = setDateTimeNow()

                                if TESTING == False:
                                    bug.save()

                                    # saved_bug = dao.get_bug(bug_id, c_mod.id_mod_id)
                                    # if saved_bug == None:
                                    #     bug.save()
                                    # else:
                                    #     bug = saved_bug

                                count_bug += 1

                                # if DEBUG:
                                #     logger.info("\nid: ", bug.bug_id)
                                #     logger.info("title: ", bug.title)
                                #     logger.info("status: ", bug.status)
                                #     logger.info("replies: ", bug.replies)
                                #     logger.info("version: ", bug.version)
                                #     logger.info("priority: ", bug.priority)
                                #     logger.info("last_post: ", bug.last_post)
                                #     logger.info("mod: ", bug.mod)

                                page_bug_comments = None
                                response = self.get_page_bug_comments(bug_id)
                                if response["success"] == True:
                                    page_bug_comments = response["content"]
                                elif response["status"]:
                                    if response["status"] == 429:
                                        COLLECT_BUGS_RETRY_AFTER = time.time() + int(response["retry-after"])
                                        COLLECT_BUGS_DISABLED = True
                                        collect_bugs = False
                                        # logger.info("\nBug Collect Disabled")
                                    logger.error("\n", response["error"])
                                else:
                                    logger.error("\n", response["error"])

                                if not page_bug_comments:
                                    logger.error("Erro ao acessar a página de comentario do bug do mod. Id:", c_mod.id_mod_id)
                                    return False

                                soup2 = BeautifulSoup(page_bug_comments, 'lxml')

                                bugs_comments_list = []

                                div = soup2.find('div', {'class': 'comments'})
                                if div and len(div) > 0:
                                    lis = div.find_all('li', {'class': 'comment'})
                                    for li in lis:
                                        count_bug_comment += 1

                                        # status
                                        count_msg = " Pages:" + str(page_index) + "/" + str(end_page) + " Bugs:" + str(count_bug) + " Cmt:" + str(count_bug_comment)
                                        logger.print_inline(count_msg, bugs_len)
                                        bugs_len = len(count_msg)


                                        bug_comment_id = li["id"]
                                        if bug_comment_id:
                                            bugComment = BugComment()
                                            bugComment.begin_date = setDateTimeNow()
                                            bugComment.bug_comment_id = bug_comment_id.encode()

                                            span1s = li.find_all('span', {'class': 'comment-name'})
                                            for span1 in span1s:
                                                bugComment.name = span1.text.encode().strip()

                                            span2s = li.find('ul', {'class': 'clearfix'})
                                            # print span2s.span.text
                                            bugComment.status = span2s.span.text.encode()

                                            divs = li.find_all('div', {'class': 'comment-content'})

                                            for div in divs:
                                                bugComment.date = formateDateAM_PM(div.time.text)
                                                bugComment.content=div.text.encode()

                                            bugComment.bug = bug
                                            bugComment.finish_date = setDateTimeNow()

                                            bugs_comments_list.append(bugComment)

                                            # if TESTING == False:
                                            #     bugComment.save()

                                                # saved_bug_comment = dao.get_bug_comment(bug_comment_id, bug.id)
                                                # if saved_bug_comment == None:
                                                #     bugComment.save()

                                            # if DEBUG:
                                            #     logger.info("\nbug_comment_id: ", bugComment.bug_comment_id)
                                            #     logger.info("name: ", bugComment.name)
                                            #     logger.info("status: ", bugComment.status)
                                            #     logger.info("content: ", bugComment.content)
                                            #     logger.info("bug_id: ", bugComment.bug_id)

                                    if TESTING == False and bugs_comments_list and len(bugs_comments_list) > 0:
                                        try:
                                            BugComment.objects.bulk_create(bugs_comments_list)
                                        except Exception:
                                            logger.error("\nException on Saving Bug Comments, Mod:", c_mod.id_mod_id)
                                            _, _, tb = sys.exc_info()
                                            filename, lineno, funname, line = traceback.extract_tb(tb)[-1]
                                            print '{}:{}, in {}\n    {}'.format(filename, lineno, funname, line)
                                            return False
                                        del bugs_comments_list[:]

                            time.sleep(COLLECT_DELAY)
            c_mod.bugs_last_page = page_index
            if DEBUG == True:
                logger.info("Bugs Last Page:", c_mod.bugs_last_page)
            if TESTING == False:
                c_mod.save(update_fields=["bugs_last_page"])
        return True

    def get_mod_bug_page_url(self, nexus_id_game, nexus_id_mod, page):
        return ("https://www.nexusmods.com/Core/Libs/Common/Widgets/ModBugsTab?"
                + "RH_ModBugsTab=issue_id:,game_id:" + str(nexus_id_game)
                + ",id:" + str(nexus_id_mod)
                + ",priority:-1,status:-1,sort_by:date,order:ASC,page_size:10"
                + ",page:" + str(page))

    def get_page_bug_comments(self, bug_id):
        link_bug_comments = "https://www.nexusmods.com/Core/Libs/Common/Widgets/ModBugReplyList"
        form_data = {'issue_id': bug_id}
        return network.get_page_content_post(link_bug_comments, form_data, True)


# --------------------------------- Coleta de Videos ---------------------------------------------------------------------
    def collect_tab_videos(self, c_mod, start_page=None, end_page=None):

        DEBUG = False
        TESTING = False

        self.video_len = 0
        self.count_pages = 0
        self.count_total_pages = 0

        c_mod = CollectMod.objects.get(id_mod_id = c_mod.id_mod_id)
        if c_mod.collecting_videos == True:
            return

        if c_mod.videos_finalized == True:
            # logger.info("\nMod id:", c_mod.id_mod_id, " videos collect already completed.")
            return

        self.tab = VIDEOS

        if TESTING == False:
            started = dao.enable_collecting_tab(self.tab, c_mod.id_mod_id)
            if not started:
                self.tab = None
                return

        # Get Mod Images Tab Soup
        tab_url = c_mod.id_mod.url + '?tab=videos'

        # if DEBUG:
        #     logger.info(tab_url)

        page_content = network.get_page_content(tab_url)
        if not page_content or len(page_content) == 0:
            logger.error("\nErro ao acessar a página de video do mod. Id:", c_mod.id_mod_id)
            self.stop_mod_collecting(c_mod)
            return

        soup = BeautifulSoup(page_content, 'lxml')

        if network.check_page_errors(soup, c_mod):
            self.stop_mod_collecting(c_mod)
            return

        # End Page Author
        divVideoAuthor = soup.find("div", attrs={'id': 'list-modvideos-1'})
        pages_author = None
        if divVideoAuthor and len(divVideoAuthor) > 0:
            scriptAuthor = divVideoAuthor.find_all("script")
            if scriptAuthor and len(scriptAuthor) > 0:
                for aux2 in scriptAuthor:
                    if '"page"' in aux2.text:
                        pages_author = getPagingNumber2(aux2.string)
                        self.count_total_pages += pages_author
                        # self.total_videos += int(pages_author[-1]) * 24
                        break

        # End Page USER
        divVideoUser = soup.find("div", attrs={'id': 'list-modvideos-2'})
        pages_user = None
        if divVideoUser and len(divVideoUser) > 0:
            scriptUser = divVideoUser.find_all("script")
            if scriptUser and len(scriptUser) > 0:
                for aux2 in scriptUser:
                    if '"page"' in aux2.text:
                        pages_user = getPagingNumber2(aux2.string)
                        self.count_total_pages += pages_user
                        # self.total_videos += int(pages_user[-1]) * 24
                        break

        # -------------------------------- COLLECT AUTHOR IMAGES --------------------------------------
        if c_mod.videos_author_finalized == False:

            #  Start Page Author
            if c_mod.videos_author_last_page and c_mod.videos_author_last_page > 1:
                author_start_page = c_mod.videos_author_last_page - 1
            else:
                author_start_page = 1

            if pages_author and pages_author > 0:
                count_pages_author = pages_author

                # if DEBUG:
                #     logger.info("\nPages Author:", count_pages_author)

                author_collected = self.collect_video(c_mod, author_start_page, count_pages_author, "AUTHOR")
                if author_collected == False:
                    logger.error("\nErro ao coletar Videos do mod. Id:", c_mod.id_mod_id)
                    self.stop_mod_collecting(c_mod)
                    return

            c_mod.videos_author_finalized = True
            if not TESTING:
                c_mod.save(update_fields=["videos_author_finalized"])

        # -------------------------------- COLLECT USER IMAGES ----------------------------------------
        if c_mod.videos_user_finalized == False:

            #  Start Page User
            if c_mod.videos_user_last_page and c_mod.videos_user_last_page > 1:
                user_start_page = c_mod.videos_user_last_page - 1
            else:
                user_start_page = 1

            if pages_user and pages_user > 0:
                count_pages_user = pages_user

                # if DEBUG:
                #     logger.info("\nPages User:", count_pages_user)

                user_collected = self.collect_video(c_mod, user_start_page, count_pages_user, "USER")
                if user_collected == False:
                    logger.error("\nErro ao coletar User Images do mod. Id:", c_mod.id_mod_id)
                    self.stop_mod_collecting(c_mod)
                    return

            c_mod.videos_user_finalized = True
            if not TESTING:
                c_mod.save(update_fields=["videos_user_finalized"])

        c_mod.collecting_videos = False
        self.tab = None

        if not TESTING:
            if (c_mod.videos_author_finalized == True and c_mod.videos_user_finalized == True):
                c_mod.videos_finalized = True
                c_mod.save(update_fields=["collecting_videos", "videos_finalized"])
            else:
                c_mod.save(update_fields=["collecting_videos"])

            # if DEBUG:
            #     logger.info("\nImages Finalized - Mod id:", c_mod.id_mod_id)

    def collect_video(self, c_mod, start_page, end_page, type):
        DEBUG = False
        TESTING = False

        # if DEBUG:
        #     logger.info("Type ", type)

        if not (c_mod.id_mod and c_mod.id_mod.game):
            logger.error("\nc_mod without Mod or Game.")
            return False

        nexus_id_game = c_mod.id_mod.game.nexus_id
        nexus_id_mod = c_mod.id_mod.nexus_id_mod

        # Game Without Nexus_id
        if not nexus_id_game:
            c_mod.error = True
            c_mod.error_msg = "Game Without nexus_id"

            if not TESTING:
                c_mod.save(update_fields=["error", "error_msg"])
            logger.error("\nGame sem nexus_id. Id:", c_mod.id_mod.game.id)
            return False

        # Mod Without Nexus_id
        if not nexus_id_mod:
            c_mod.error = True
            c_mod.error_msg = "Mod Without nexus_id"

            if not TESTING:
                c_mod.save(update_fields=["error", "error_msg"])
            logger.error("\nMod sem nexus_id. Id:", c_mod.id_mod_id)
            return False

        for page_index in range(start_page, end_page + 1):
            self.count_pages += 1

            videos_list = []

            url_video_page = self.get_mod_video_page_url(nexus_id_game, nexus_id_mod, page_index, type)

            # if DEBUG:
            #     logger.info(url_video_page)

            page_content = network.get_page_content(url_video_page)
            if not page_content or len(page_content) == 0:
                logger.error("\nErro ao acessar a página de video do mod. Id:", c_mod.id_mod_id)
                logger.error("Url:", url_video_page)
                return False

            soup = BeautifulSoup(page_content, 'lxml')

            if network.check_page_errors(soup, c_mod):
                return False

            videos = None
            listVideos = soup.find("ul", attrs={'class': 'tiles lg-mod-video-list'})
            if listVideos and len(listVideos) > 0:
                videos = listVideos.find_all("li", attrs={'class': 'image-tile video-tile video-mod-page'})

            if videos and len(videos) > 0:
                for video in videos:
                    videoObj = Video()
                    videoObj.begin_date = setDateTimeNow()

                    videoObj.uploaded_date = formatDescribedDateMonth(video.find("div", attrs={'class': 'author'}).text)

                    videoObj.name = video.h3.text.encode('utf-8')

                    # print video.find("div", attrs={'class': 'lb_caption'}).text.encode('utf-8')

                    videoObj.author = video.find("div", attrs={'class': 'lb_caption'}).text.encode('utf-8')

                    videoObj.url = video.find('a', {'class': 'mod-image'}, href=True)['href'].encode()


                    if type == "USER":
                        videoObj.videosUser = True
                    elif type == "AUTHOR":
                        videoObj.videosUser = False

                    videoObj.mod = c_mod.id_mod

                    # if Mod.objects.filter(name=c_mod.id_mod.name, url=c_mod.id_mod.url):
                        #buscar somente o objeto
                        #print modObj.name
                        #print modObj.url
                        # modAux = Mod.objects.get(url=c_mod.id_mod.url)
                        #modAux = Mod.objects.filter(url=modObj.url)
                        #modQ = Mod.objects.filter(name=modObj.name)
                        #modAux = modQ.exclude(url=modObj.url)[:1]

                        #modAux = Mod.objects.get(name=modObj.name, url=modObj.url)[:1]
                    #     videoObj.mod = modAux
                    # else:
                    #     logger.error("\nErro ao associar Mod a Imagem. Id:", c_mod.id_mod_id)
                    #     return False

                    videoObj.finish_date = setDateTimeNow()
                    videos_list.append(videoObj)

                    # if DEBUG:
                    #     logger.info("\n")
                    #     logger.info("uploaded_date: ", videoObj.uploaded_date)
                    #     logger.info("name: ", videoObj.name)
                    #     logger.info("author: ", videoObj.author)
                    #     logger.info("imagemUser: ", videoObj.videosUser)
                    #     logger.info("mod: ", videoObj.mod)
                    #     logger.info("Url: ", videoObj.url)
                    #     logger.info("begin_date: ", videoObj.begin_date)
                    #     logger.info("finish_date: ", videoObj.finish_date)

                    # if not TESTING:
                    #     videoObj.save()

                        # video_saved = dao.get_video(videoObj)
                        # if video_saved == None:
                        #     videoObj.save()

                    # Status
                    count_msg = " Pages:" + str(self.count_pages) + "/" + str(self.count_total_pages) + "    "
                    logger.print_inline(count_msg, self.video_len)
                    self.video_len = len(count_msg)

                if TESTING == False and videos_list and len(videos_list) > 0:
                    try:
                        Video.objects.bulk_create(videos_list)
                    except Exception:
                        self.stop_mod_collecting(c_mod)
                        logger.error("\nException on Saving Videos, Mod:", c_mod.id_mod_id)
                        _, _, tb = sys.exc_info()
                        filename, lineno, funname, line = traceback.extract_tb(tb)[-1]
                        print '{}:{}, in {}\n    {}'.format(filename, lineno, funname, line)
                        return False
                    del videos_list[:]

            if not TESTING:
                if type == "USER":
                    c_mod.videos_user_last_page = page_index
                    c_mod.save(update_fields=["videos_user_last_page"])
                elif type == "AUTHOR":
                    c_mod.videos_author_last_page = page_index
                    c_mod.save(update_fields=["videos_author_last_page"])


        return True

    def get_mod_video_page_url(self, nexus_id, nexus_id_mod, page, type):

        if type == "AUTHOR":
            rh_mod = "RH_ModVideosList1"
            rh_group = "1"
        elif type == "USER":
            rh_mod = "RH_ModVideosList2"
            rh_group = "2"

        return ("https://www.nexusmods.com/Core/Libs/Common/Widgets/ModVideosList?"
                + rh_mod + "=game_id:" + str(nexus_id)
                + ",id:" + str(nexus_id_mod)
                + ",page_size:24,"
                + rh_group + "page:" + str(page)
                + ",rh_group_id:" + rh_group)


# --------------------------------- Coleta de Articles ------------------------------------------------------------------
    #samia

    def collect_tab_articles(self, c_mod, start_page=None, end_page=None):

        DEBUG = False
        TESTING = False

        c_mod = CollectMod.objects.get(id_mod_id = c_mod.id_mod_id)
        if c_mod.collecting_articles == True:
            return

        if c_mod.articles_finalized == True:
            # logger.info("\nMod id:", c_mod.id_mod_id, " articles collect already completed.")
            return

        self.tab = ARTICLES

        if TESTING == False:
            started = dao.enable_collecting_tab(self.tab, c_mod.id_mod_id)
            if not started:
                self.tab = None
                return

        tab_url = c_mod.id_mod.url + '?tab=articles'

        # if DEBUG:
        #     logger.info(tab_url)

        page_content = network.get_page_content(tab_url)
        if not page_content or len(page_content) == 0:
            logger.error("\nErro ao acessar a página de video do mod. Id:", c_mod.id_mod_id)
            self.stop_mod_collecting(c_mod)
            return

        soup = BeautifulSoup(page_content, 'lxml')

        if network.check_page_errors(soup, c_mod):
            self.stop_mod_collecting(c_mod)
            return

        if c_mod.articles_finalized == False:

            #  Start Page Author
            if c_mod.articles_last_page and c_mod.articles_last_page > 1:
                author_start_page = c_mod.articles_author_last_page - 1
            else:
                author_start_page = 1

            # End Page Author
            # print soup
            divArticlesAuthor = soup.find("div", attrs={'class': 'container tab-articles'})
            pages_author = None
            #print divArticlesAuthor
            if divArticlesAuthor and len(divArticlesAuthor) > 0:
                scriptAuthor = divArticlesAuthor.find_all("script")
                if scriptAuthor and len(scriptAuthor) > 0:
                    for aux2 in scriptAuthor:
                        if "$( function(){Filters_Pagination.Load(" in aux2.text:
                            pages_author = getPagingNumber(aux2.string)
                            break

            if pages_author:
                count_pages_author = int(pages_author[-1])

                # if DEBUG:
                #     logger.info("\nPages Author:", count_pages_author)

                author_collected = self.collect_article(c_mod, author_start_page, count_pages_author, "AUTHOR")
                if author_collected == False:
                    logger.error("\nErro ao coletar Articles do mod. Id:", c_mod.id_mod_id)
                    self.stop_mod_collecting(c_mod)
                    return

        self.tab = None

        c_mod.collecting_articles = False
        c_mod.articles_finalized = True

        # if DEBUG:
        #     logger.info("\nImages Finalized - Mod id:", c_mod.id_mod_id)

        if not TESTING:
            c_mod.save(update_fields=["collecting_articles", "articles_finalized"])

    def collect_article(self, c_mod, start_page, end_page, type):
        DEBUG = False
        TESTING = False

        # if DEBUG:
        #     logger.info("Type ", type)

        if not (c_mod.id_mod and c_mod.id_mod.game):
            logger.error("\nc_mod without Mod or Game.")
            return False

        nexus_id_game = c_mod.id_mod.game.nexus_id
        nexus_id_mod = c_mod.id_mod.nexus_id_mod

        # Game Without Nexus_id                -- OR (articles_finalized = FALSE AND collecting_articles = FALSE)
        if not nexus_id_game:
            c_mod.error = True
            c_mod.error_msg = "Game Without nexus_id"

            if not TESTING:
                c_mod.save(update_fields=["error", "error_msg"])
            logger.error("\nGame sem nexus_id. Id:", c_mod.id_mod.game.id)
            return False

        # Mod Without Nexus_id
        if not nexus_id_mod:
            c_mod.error = True
            c_mod.error_msg = "Mod Without nexus_id"

            if not TESTING:
                c_mod.save(update_fields=["error", "error_msg"])
            logger.error("\nMod sem nexus_id. Id:", c_mod.id_mod_id)
            return False

        count_article_len = 0

        for page_index in range(start_page, end_page + 1):
            # logger.info(type, " Pag:", page_index)

            url_articles_page = self.get_mod_article_page_url(nexus_id_game, nexus_id_mod, page_index, type)

            # if DEBUG:
            #     logger.info("\nURL:", url_articles_page)

            page_content = network.get_page_content(url_articles_page)
            if not page_content or len(page_content) == 0:
                logger.error("\nErro ao acessar a página de article do mod. Id:", c_mod.id_mod_id)
                logger.error("Url:", url_articles_page)
                return False

            soup = BeautifulSoup(page_content, 'lxml')

            if network.check_page_errors(soup, c_mod):
                return False

            articles = None
            listArticles = soup.find("ul", attrs={'class': 'tiles'})
            if listArticles and len(listArticles) > 0:
                articles = listArticles.find_all("li", attrs={'class': 'article-tile'})

            if articles and len(articles) > 0:

                articles_list = []

                for article in articles:
                    articleObj = Article()
                    articleObj.begin_date = setDateTimeNow()

                    title = article.find('div', {"class", "tile-content"})

                    name = ""
                    if title and title.h3:
                        name = title.h3.text.encode().strip()
                    articleObj.name = name

                    articleObj.link_article = title.a['href'].encode()

                    date = article.find('time', {'class', 'date'})
                    # Tratando Mods com article com erro de codificação
                    if date == None:
                        c_mod.error = True
                        c_mod.error_msg = "ERRO_CODIFICACAO_ARTICLE"

                        if not TESTING:
                            c_mod.save(update_fields=["error", "error_msg"])
                        logger.error("\nMod Article com erro de Codificação. Id:", c_mod.id_mod_id)
                        return False

                    articleObj.uploaded_date = formatDateTime(date['datetime'])

                    author = article.find('div', {'class', 'author'})
                    if author:
                        articleObj.author = author.text.encode()
                        articleObj.link_author = author.a['href']

                    # articleObj.description = article.find('p', {'class', 'desc'}).text
                    description = ""
                    span_description = article.find('p', {'class', 'desc'})
                    if span_description:
                        description = span_description.text.encode().strip()
                    articleObj.description = description

                    # articleObj.amoutComentarios = article.find('span', {'class', 'flex-label'}).text
                    amount_comentarios = 0
                    comentarios = article.find('span', {'class', 'flex-label'})
                    if comentarios:
                        amount_comentarios = comentarios.text.encode().strip()
                    articleObj.amoutComentarios = amount_comentarios

                    articleObj.begin_date = setDateTimeNow()

                    articleObj.mod = c_mod.id_mod

                    # if Mod.objects.filter(name=c_mod.id_mod.name, url=c_mod.id_mod.url):
                        #buscar somente o objeto
                        #print modObj.name
                        #print modObj.url
                        # modAux = Mod.objects.get(url=c_mod.id_mod.url)
                        #modAux = Mod.objects.filter(url=modObj.url)
                        #modQ = Mod.objects.filter(name=modObj.name)
                        #modAux = modQ.exclude(url=modObj.url)[:1]

                        #modAux = Mod.objects.get(name=modObj.name, url=modObj.url)[:1]
                        # articleObj.mod = modAux
                    # else:
                    #     logger.error("\nErro ao associar Mod a article. Id:", c_mod.id_mod_id)
                    #     return False

                    articleObj.finish_date = setDateTimeNow()

                    articles_list.append(articleObj)

                    # if DEBUG:
                    #     logger.info("\n")
                    #     logger.info("uploaded_date: ", articleObj.uploaded_date)
                    #     logger.info("name: ", articleObj.name)
                    #     logger.info("author: ", articleObj.author)
                    #     logger.info("articleUser: ", articleObj.videosUser)
                    #     #logger.info("articleUser: ", articleObj.imagemUser)
                    #     logger.info("mod: ", articleObj.mod)
                    #     logger.info("Url: ", articleObj.url)
                    #     logger.info("begin_date: ", articleObj.begin_date)
                    #     logger.info("finish_date: ", articleObj.finish_date)

                    # if not TESTING:
                    #     articleObj.save()

                        # article_saved = dao.get_article(articleObj)
                        # if article_saved == None:
                        #     articleObj.save()

                    # Status
                    count_msg = " Pages:" + str(page_index) + "/" + str(end_page) + " "
                    logger.print_inline(count_msg, count_article_len)
                    count_article_len = len(count_msg)

                if TESTING == False and articles_list and len(articles_list) > 0:
                    try:
                        Article.objects.bulk_create(articles_list)
                    except Exception:
                        logger.error("\nException on Saving Articles, Mod:", c_mod.id_mod_id)
                        _, _, tb = sys.exc_info()
                        filename, lineno, funname, line = traceback.extract_tb(tb)[-1]
                        print '{}:{}, in {}\n    {}'.format(filename, lineno, funname, line)
                        return False
                    del articles_list[:]

            c_mod.articles_last_page = page_index
            if not TESTING:
                c_mod.save(update_fields=["articles_last_page"])

        return True

    def get_mod_article_page_url(self, nexus_id, nexus_id_mod, page, type):

        if type == "AUTHOR":
            rh_mod = "RH_ModArticlesTab"
            rh_group = "1"


        return ("https://www.nexusmods.com/Core/Libs/Common/Widgets/ModArticlesTab?"
                + rh_mod + "=game_id:" + str(nexus_id)
                + ",id:" + str(nexus_id_mod)
                + ",page_size:24,"
                + rh_group + "page:" + str(page)
                + ",rh_group_id:" + rh_group)


# --------------------------------- Coleta de Post ---------------------------------------------------------------------
    def collect_tab_post(self, c_mod, start_page=None, end_page=None):
        DEBUG = False
        TESTING = False

        c_mod = CollectMod.objects.get(id_mod_id = c_mod.id_mod_id)
        if c_mod.collecting_posts == True:
            return

        if c_mod.posts_finalized == True:
            # logger.info("\nMod id:", c_mod.id_mod_id, " post collect already completed.")
            return

        self.tab = POSTS

        if TESTING == False:
            started = dao.enable_collecting_tab(self.tab, c_mod.id_mod_id)
            if not started:
                self.tab = None
                return

        # Get Mod Post Tab Soup
        tab_url = c_mod.id_mod.url + '?tab=posts'
        if DEBUG:
            logger.info(tab_url)

        page_content = network.get_page_content(tab_url)
        if not page_content or len(page_content) == 0:
            logger.error("\nErro ao acessar a página de video do mod. Id:", c_mod.id_mod_id)
            self.stop_mod_collecting(c_mod)
            return

        soup = BeautifulSoup(page_content, 'lxml')

        if network.check_page_errors(soup, c_mod):
            self.stop_mod_collecting(c_mod)
            return

        # -------------------------------- COLLECT AUTHOR POSTS --------------------------------------
        if c_mod.posts_finalized == False:

            thread_id = None
            content = soup.find("li", attrs={'id': 'mod-page-tab-posts'})
            if content:
                thread_id = content.a['data-target'].rsplit('=')[5].rsplit('&')[0]
                if c_mod.posts_last_page and c_mod.posts_last_page > 1:
                    post_start_page = c_mod.posts_last_page - 1
                else:
                    post_start_page = 1

                # End Page
                #            print soup
                divPost = soup.find("div", attrs={'class': 'container comments condensed'})
                pages_post = None

                # print divPost
                if divPost and len(divPost) > 0:
                    scriptPost = divPost.find_all("script")
                    if scriptPost and len(scriptPost) > 0:
                        for aux2 in scriptPost:
                            if "$( function(){Filters_Pagination.Load(" in aux2.text:
                                pages_post = getPagingNumber(aux2.string)
                                break
                if pages_post:
                    count_pages_author = int(pages_post[-1])

                    if DEBUG:
                        logger.info("\nPages :", count_pages_author)


                    post_collected = self.collect_post(c_mod, post_start_page, count_pages_author, thread_id)
                    if post_collected == False:
                        logger.error("\nErro ao coletar Post do mod. Id:", c_mod.id_mod_id)
                        self.stop_mod_collecting(c_mod)
                        return

                c_mod.posts_finalized = True
                if not TESTING:
                    c_mod.save(update_fields=["posts_finalized"])
            else:
                c_mod.posts_finalized == True
                c_mod.save(update_fields=["posts_finalized"])

        c_mod.collecting_posts = False
        self.tab = None

        c_mod.posts_finalized = True
        if DEBUG:
            logger.info("\nPost Finalized - Mod id:", c_mod.id_mod_id)
        if TESTING == False:
            c_mod.save(update_fields=["collecting_posts", "posts_finalized"])
        return

    def collect_post(self, c_mod, start_page, end_page, thread_id):
        DEBUG = False
        TESTING = False

        posts = dao.count_mod_posts(c_mod.id_mod_id)

        if not (c_mod.id_mod and c_mod.id_mod.game):
            logger.error("\nc_mod without Mod or Game.")
            return False

        nexus_id_game = c_mod.id_mod.game.nexus_id
        nexus_id_mod = c_mod.id_mod.nexus_id_mod

        # Game Without Nexus_id
        if not nexus_id_game:
            c_mod.error = True
            c_mod.error_msg = "Game Without nexus_id"
            if not TESTING:
                c_mod.save(update_fields=["error", "error_msg"])
            logger.error("\nGame sem nexus_id. Id:", c_mod.id_mod.game.id)
            return False

        # Mod Without Nexus_id
        if not nexus_id_mod:
            c_mod.error = True
            c_mod.error_msg = "Mod Without nexus_id"
            if not TESTING:
                c_mod.save(update_fields=["error", "error_msg"])
            logger.error("\nMod sem nexus_id. Id:", c_mod.id_mod_id)
            return False

        count_post = 0
        count_post_len = 0
        for page_index in range(start_page, end_page + 1):
            # logger.info(type, " Pag:", page_index)

            # Status
            count_msg = " Pg:" + str(page_index) + "/" + str(end_page) + " " + str(posts) + " "
            logger.print_inline(count_msg, count_post_len)
            count_post_len = len(count_msg)

            url_post_page = self.get_mod_post_page_url(nexus_id_game, nexus_id_mod, page_index, thread_id)
            if DEBUG:
                logger.info(url_post_page)

            page_content = network.get_page_content(url_post_page)
            if not page_content or len(page_content) == 0:
                logger.error("\nErro ao acessar a página de Post do mod. Id:", c_mod.id_mod_id)
                logger.error("Url:", url_post_page)
                return False

            soup = BeautifulSoup(page_content, 'lxml')

            if network.check_page_errors(soup, c_mod):
                return False

            ol = soup.find('ol')
            if ol and len(ol) > 0:
                list_comment = ol.find_all('li', {'class': 'comment'})
                # print "Numero TOTAL DE COMENTARIOS: " + str(len(list_comment))

                # verifica se comentario tem resposta
                #print list_comment
                #print  "--------------------------------------"
                for li in list_comment:
                    #print li
                    # count_comment += 1
                    # primeiro nivel quando tem respostas
                    if li.find_all('ol', {'class': 'comment-kids'}):
                        head_comment = self.get_comment_content_head(li)

                        paiComment = self.save_comment_post(head_comment,None,None,c_mod.id_mod_id)
                        # count_comment_save += 1 #3RMV

                        respostas = li.find_all('ol', {'class': 'comment-kids'})[0].find_all('li', {'class': 'comment'})

                        # segundo nivel quando tem respostas
                        for li2 in respostas:
                            # count_comment += 1
                            comment = self.get_comment_content(li2)
                            pai = self.get_comment_content(li)['id'].split("-")[1]
                            self.save_comment_post(comment, pai, paiComment.id , c_mod.id_mod_id)
                            posts += 1

                            # Status
                            count_msg = " Pg:" + str(page_index) + "/" + str(end_page) + " " + str(posts) + " "
                            logger.print_inline(count_msg, count_post_len)
                            count_post_len = len(count_msg)
                            # count_comment_save += 1 #3RMV

                    # quando nao tem respostas
                    else:
                        comment = self.get_comment_content(li)
                        self.save_comment_post(comment, None,None, c_mod.id_mod_id)
                        posts += 1
                        # count_comment_save += 1 #3RMV

                        # Status
                        count_msg = " Pg:" + str(page_index) + "/" + str(end_page) + " " + str(posts) + " "
                        logger.print_inline(count_msg, count_post_len)
                        count_post_len = len(count_msg)

            c_mod.posts_last_page = page_index
            if not TESTING:
                c_mod.save(update_fields=["posts_last_page"])
        return True

    def getContentHead(li):
        dict = {}
        dict['id'] = li['id']
        divs_comment_head = li.find_all('div', {'class': 'comment-head clearfix'})
        for div in divs_comment_head:
            atags_comment_head = div.find_all('a', {'class': 'comment-user'})
            dict['href'] = atags_comment_head[0]['href']
            spans_comment_details = div.find_all('span', {'class': 'comment-name'})
            atag_comment_details = spans_comment_details[0].find_all('a')
            dict['hrefuser'] = atag_comment_details[0]['href']
            dict['user'] = atag_comment_details[0].text
            uls = div.find_all(lambda tag: tag.name == 'ul' and tag.get('class') == ['clearfix'])
            # uls = div.find_all('ul', {'class': 'clearfix'})
            for ul in uls:
                lis = ul.find_all('li')
                if len(lis) != 0:
                    dict['userstatus'] = lis[0].text
                    dict['posts'] = lis[1].text
                    dict['kudos'] = lis[2].text
            div_comment = li.find('div', {'class': 'comment-content'})
            times = div_comment.find_all('time')
            for tim in times:
                atags = tim.find_all('a')
                for atag in atags:
                    dict['date'] = atag.text
                    comment = div_comment.find_all('div', {'class': 'comment-content-text'})
                    dict['content'] = comment[0].text

            break
        return dict

    def save_comment_post(self, dict, pai, pai_id, mod_id):
        TESTING = False
        DEBUG = False

        id = dict['id'].split('-')[1]

        # post_result = dao.get_comment_post(id)
        # if post_result == None:

        comment = Post()
        comment.begin_date = setDateTimeNow()
        comment.reply_comment = pai
        comment.id_reply_comment = pai_id
        comment.comment_id = id
        comment.user_url = dict['hrefuser']
        comment.user_name = dict['user'].encode('utf-8')
        comment.status = dict['userstatus']
        comment.mod_id = mod_id
        comment.posts = int(dict['posts'].split(" ")[0].encode('utf-8').replace(",", ""))
        comment.kudos = int(dict['kudos'].split(" ")[0].encode('utf-8').replace(",", ""))
        comment.content = dict['content'].encode('utf-8')
        comment.date = formateDateAM_PM(dict['date'])
        comment.finish_date = setDateTimeNow()

        # if DEBUG:
        #     logger.info("reply: ", comment.reply_comment)
        #     logger.info("comment_id: ", comment.comment_id)
        #     logger.info("user_url: ", comment.user_url)
        #     logger.info("user_name: ", comment.user_name.encode('utf-8'))
        #     logger.info("status: ", comment.status)
        #     logger.info("posts: ", comment.posts)
        #     logger.info("kudos: ", comment.kudos)
        #     logger.info("content: ", comment.content.encode('utf-8'))
        #     logger.info("date: ", comment.date)
        #     logger.info("mod: ", comment.mod_id)

        if not TESTING:
            comment.save()
            return comment
        return None
        # return post_result

    def get_mod_post_page_url(self, nexus_id, nexus_id_mod, page,thread_id):
        return ("https://www.nexusmods.com/Core/Libs/Common/Widgets/CommentContainer?"
                + "RH_CommentContainer=game_id:" + str(nexus_id)
                + ",object_id:" + str(nexus_id_mod)
                + ",object_type:1,thread_id:" + str(thread_id)
                + ",tabbed:1,skip_opening_post:0,display_title:1,page_size:10"
                + ",page:" + str(page))


# --------------------------------- Coleta de Logs ---------------------------------------------------------------------
    def collect_tab_logs(self, c_mod):
        DEBUG = False
        TESTING = False

        self.page_log_author = 0
        self.page_log_user = 0

        c_mod = CollectMod.objects.get(id_mod_id = c_mod.id_mod_id)
        if c_mod.collecting_logs == True:
            return

        if c_mod.logs_finalized == True:
            return

        self.tab = LOGS

        if TESTING == False:
            started = dao.enable_collecting_tab(self.tab, c_mod.id_mod_id)
            if not started:
                self.tab = None
                return

        self.count_logs = dao.count_mod_logs(c_mod.id_mod_id)
        self.count_logs_len = 0

        nexus_id_game = c_mod.id_mod.game.nexus_id
        nexus_id_mod = c_mod.id_mod.nexus_id_mod

        # Game Without Nexus_id
        if not nexus_id_game:
            c_mod.error = True
            c_mod.error_msg = "Game Without nexus_id"
            if not TESTING:
                c_mod.save(update_fields=["error", "error_msg"])
            logger.error("\nGame sem nexus_id. Id:", c_mod.id_mod.game.id)
            self.tab = None
            return

        # Mod Without Nexus_id
        if not nexus_id_mod:
            c_mod.error = True
            c_mod.error_msg = "Mod Without nexus_id"
            if not TESTING:
                c_mod.save(update_fields=["error", "error_msg"])
            logger.error("\nMod sem nexus_id. Id:", c_mod.id_mod_id)
            self.tab = None
            return

        # Get Mod Bugs Tab Soup
        tab_url = c_mod.id_mod.url + '?tab=logs'
        if DEBUG == True:
            logger.info("\n", tab_url)

        page_content = network.get_page_content(tab_url)
        if not page_content or len(page_content) == 0:
            logger.error("\nErro ao acessar a página de logs do mod. Id:", c_mod.id_mod_id)
            self.stop_mod_collecting(c_mod)
            self.tab = None
            return

        soup = BeautifulSoup(page_content, 'lxml')

        if network.check_page_errors(soup, c_mod):
            self.stop_mod_collecting(c_mod)
            self.tab = None
            return

        accordion = soup.find('dl', {'class': 'accordion'})
        dts = accordion.find_all('dt')

        mod_pages = 0
        for k in range(1, len(dts) + 1):
            if dts[k-1].text.strip().__eq__("Changelogs"):

                if DEBUG:
                    logger.info("\n----------------------------- Changelogs --------------------------")

                changelogs_div = soup.find_all('div', {'class': 'log-block'})
                if changelogs_div and len(changelogs_div) > 0:
                    if self.collect_changelogs(changelogs_div, c_mod, k) == False:
                        self.stop_mod_collecting(c_mod)
                        self.tab = None
                        return

            elif dts[k-1].text.strip().__eq__("Author's activity"):

                if DEBUG:
                    logger.info("\n----------------------------- Author's activity --------------------------")

                soup_author = copy.deepcopy(soup)

                author_page = 1
                str_offset_author = None
                uls = None

                collecting_author_activity = True
                while(collecting_author_activity):
                    load_more_author = False

                    if DEBUG == True:
                        logger.info("\nAUTHOR ACTIVITY PAGE:", author_page, " offset:", str_offset_author)

                    # Load More
                    if author_page == 1:
                        author_div = soup_author.find("div", attrs={"class": "log-block"})
                        if author_div and author_div.h3:
                            div = soup_author.find_all('div', {'class': 'log-block'})
                            if div and len(div) > 0:
                                uls = div[k-1].find_all('ul', {'class': 'action-log'})

                            if c_mod.logs_last_offset_author == None:
                                if uls and len(uls) > 0:
                                    if self.collect_author_activity(uls, c_mod) == False:
                                        self.stop_mod_collecting(c_mod)
                                        self.tab = None
                                        return

                                    button_load_more_author = soup_author.find_all('a', {'id': "ModActionLogExpanderLoadButtonauthor"})
                                    if button_load_more_author and len(button_load_more_author) > 0:

                                        str_offset_author = self.get_log_offset(soup_author, 'author')

                                        if str_offset_author != None:
                                            load_more_author = True
                                            c_mod.logs_last_offset_author = str_offset_author
                                            if TESTING == False:
                                                c_mod.save(update_fields=["logs_last_offset_author"])

                            elif uls and len(uls) > 0:
                                if DEBUG == True:
                                    logger.info("Last offset:", c_mod.logs_last_offset_author)
                                load_more_author = True
                                str_offset_author = c_mod.logs_last_offset_author
                        else:
                            break
                    elif str_offset_author:
                        response = self.get_page_log(nexus_id_game, nexus_id_mod, str_offset_author, 'author')
                        if response["success"] == True:
                            soup_author = BeautifulSoup(response["content"], 'lxml')
                            uls = soup_author.find_all('ul', {'class': 'action-log'})
                            if uls and len(uls) > 0:
                                if self.collect_author_activity(uls, c_mod) == False:
                                    self.stop_mod_collecting(c_mod)
                                    self.tab = None
                                    return

                                c_mod.logs_last_offset_author = str_offset_author
                                if TESTING == False:
                                    c_mod.save(update_fields=["logs_last_offset_author"])

                                str_offset_author = self.get_log_offset(soup_author, 'author')
                                if str_offset_author:
                                    load_more_author = True
                        else:
                            soup_author = None
                            logger.error("\n", response["error"])
                            if response["status"] and response["status"] == 429:
                                logger.error("429")
                                # COLLECT_BUGS_RETRY_AFTER = time.time() + int(response["retry-after"])
                                # COLLECT_BUGS_DISABLED = True
                                # collect_bugs = False
                                # logger.info("\nBug Collect Disabled")

                        if not soup_author:
                            logger.error("Erro ao acessar a aba log author activity do mod. Id:", c_mod.id_mod_id)
                            return False

                    if load_more_author == False:
                        collecting_author_activity = False

                    author_page += 1
                    self.page_log_author = author_page

                    # time.sleep(3)

            elif dts[k-1].text.strip().__eq__("Mod page activity"):
                if DEBUG:
                    logger.info("\n----------------------------- Mod page activity --------------------------")

                soup_mod = copy.deepcopy(soup)

                mod_page = 1
                str_offset_mod = None
                uls = None

                collecting_mod_activity = True
                while(collecting_mod_activity):
                    load_more_mod = False

                    if DEBUG == True:
                        logger.info("\nMOD ACTIVITY PAGE:", mod_page, " offset:", str_offset_mod)

                    # Load More
                    if mod_page == 1:
                        mod_div = soup_mod.find("div", attrs={"class": "log-block"})
                        if mod_div and mod_div.h3:
                            div = soup_mod.find_all('div', {'class': 'log-block'})
                            if div and len(div) > 0:
                                uls = div[k-1].find_all('ul', {'class': 'action-log'})

                            if c_mod.logs_last_offset_users == None:
                                if uls and len(uls) > 0:
                                    if self.collect_mod_activity(uls, c_mod) == False:
                                        self.stop_mod_collecting(c_mod)
                                        self.tab = None
                                        return

                                    button_load_more_mod = soup_mod.find_all('a', {'id': "ModActionLogExpanderLoadButtonusers"})
                                    if button_load_more_mod and len(button_load_more_mod) > 0:

                                        str_offset_mod = self.get_log_offset(soup_mod, 'users')

                                        if str_offset_mod != None:
                                            load_more_mod = True
                                            c_mod.logs_last_offset_users = str_offset_mod
                                            if TESTING == False:
                                                c_mod.save(update_fields=["logs_last_offset_users"])

                            elif uls and len(uls) > 0:
                                if DEBUG == True:
                                    logger.info("Last offset:", c_mod.logs_last_offset_users)
                                load_more_mod = True
                                str_offset_mod = c_mod.logs_last_offset_users
                        else:
                            break
                    elif str_offset_mod:
                        response = self.get_page_log(nexus_id_game, nexus_id_mod, str_offset_mod, 'users')
                        if response["success"] == True:
                            soup_mod = BeautifulSoup(response["content"], 'lxml')
                            uls = soup_mod.find_all('ul', {'class': 'action-log'})
                            if uls and len(uls) > 0:
                                if self.collect_mod_activity(uls, c_mod) == False:
                                    self.stop_mod_collecting(c_mod)
                                    self.tab = None
                                    return

                                c_mod.logs_last_offset_users = str_offset_mod
                                if TESTING == False:
                                    c_mod.save(update_fields=["logs_last_offset_users"])

                                str_offset_mod = self.get_log_offset(soup_mod, 'users')
                                if str_offset_mod:
                                    load_more_mod = True

                        else:
                            soup_mod = None
                            logger.error("\n", response["error"])
                            if response["status"] and response["status"] == 429:
                                logger.error("429")
                                # COLLECT_BUGS_RETRY_AFTER = time.time() + int(response["retry-after"])
                                # COLLECT_BUGS_DISABLED = True
                                # collect_bugs = False
                                # logger.info("\nBug Collect Disabled")

                        if not soup_mod:
                            logger.error("Erro ao acessar a aba log mod activity do mod. Id:", c_mod.id_mod_id)
                            return False

                    if load_more_mod == False:
                        collecting_mod_activity = False

                    mod_page += 1
                    self.page_log_user = mod_page

                    # time.sleep(3)

        c_mod.logs_finalized = True
        c_mod.collecting_logs = False
        if not TESTING:
            c_mod.save(update_fields=["logs_finalized", "collecting_logs"])

        self.tab = None
        return

    def collect_changelogs(self, div, c_mod, k):
        TESTING = False
        DEBUG = False

        # change_logs_count = 0
        # change_list_count = 0

        ul = div[k - 1].find('ul', {'class': 'change-logs'})
        lis = ul.find_all('li', recursive=False)
        for li in lis:
            changelogsObj = Changelogs()
            changelogsObj.begin_date = setDateTimeNow()
            changelogsObj.mod = c_mod.id_mod

            h3 = li.find('h3')
            changelogsObj.version = h3.text.strip().encode()

            # if DEBUG:
                # logger.info("\nversion: " , changelogsObj.version)

            ul2 = li.find('ul', {'class': 'arrowlist'})

            lis2 = ul2.find_all('li')

            changelogsObj.finish_date = setDateTimeNow()
            if TESTING == False:
                changelogsObj.save()

            listchange_list = []
            for li2 in lis2:
                listChange = ListChange()
                listChange.begin_date = setDateTimeNow()
                listChange.change = li2.text.strip().encode()

                # if DEBUG:
                    # logger.info("listChange: ", listChange.change)

                # change_logs_count += 1
                # if TESTING == False:
                #     changelogsObj.save()

                self.count_logs += 1

                    # saved_changelog = dao.get_changelog(changelogsObj)
                    # if saved_changelog == None:
                    #     changelogsObj.save()
                    # else:
                    #     changelogsObj = saved_changelog

                listChange.changelog = changelogsObj
                listChange.finish_date = setDateTimeNow()

                # change_list_count += 1

                listchange_list.append(listChange)
                # if TESTING == False:
                #     listChange.save()
                self.count_logs += 1

                    # saved_listchange = dao.get_listchange(listChange)
                    # if saved_listchange == None:
                    #     listChange.save()

                # Status
                count_msg = "PgAth:" + str(self.page_log_author) + " PgUsr:" + str(self.page_log_user) + " Logs:" + str(self.count_logs) + " "
                logger.print_inline(count_msg, self.count_logs_len)
                self.count_logs_len = len(count_msg)

            if TESTING == False and listchange_list and len(listchange_list) > 0:
                try:
                    ListChange.objects.bulk_create(listchange_list)
                except Exception:
                    logger.error("\nException on Saving ListChange, Mod:", c_mod.id_mod_id)
                    _, _, tb = sys.exc_info()
                    filename, lineno, funname, line = traceback.extract_tb(tb)[-1]
                    print '{}:{}, in {}\n    {}'.format(filename, lineno, funname, line)
                    return False
                del listchange_list[:]

        # if DEBUG == True:
        #     logger.info("change_logs_count:", change_logs_count)
        #     logger.info("change_list_count:", change_list_count)

        return True

    def collect_author_activity(self, uls, c_mod):
        TESTING = False
        DEBUG = False

        # author_activity_count = 0

        list_author_activity = []

        for ul in uls:
            lis = ul.find_all('li', recursive=False)
            for li in lis:
                authorActivityObj = AuthorActivity()
                authorActivityObj.begin_date = setDateTimeNow()
                authorActivityObj.mod = c_mod.id_mod

                date = li.find('div',{'class':'log-modified'})
                if date:
                    datetext = date.text.split("|")
                    authorActivityObj.date = formateDateM_AM_PM(datetext[0])

                    # if DEBUG:
                        # logger.info("\ndate: ", authorActivityObj.date)

                author = li.find('a')

                authorLink = author.get('href')
                authorActivityObj.user_url = authorLink

                # if DEBUG:
                    # logger.info("user_url: ", authorActivityObj.user_url)

                authorName = author.text.strip().encode()
                authorActivityObj.user = authorName

                # if DEBUG:
                #     logger.info("user: ", authorActivityObj.user)

                divLogChange = li.find('div',{'class':'log-change'})
                title = divLogChange.find('h4')
                if title:
                    authorActivityObj.title = title.text.encode()

                    # if DEBUG:
                    #     logger.info("title: ", authorActivityObj.title)

                content = divLogChange.find('p')
                if content:
                    authorActivityObj.content = content.text.encode()
                    # if DEBUG:
                    #     logger.info("content: ", authorActivityObj.content)

                authorActivityObj.finish_date = setDateTimeNow()

                # author_activity_count += 1

                list_author_activity.append(authorActivityObj)

                # if TESTING == False:
                #     authorActivityObj.save()
                self.count_logs += 1

                    # saved_activity = dao.get_author_activity(authorActivityObj)
                    # if saved_activity == None:
                    #     authorActivityObj.save()

                # Status
                count_msg = "PgAth:" + str(self.page_log_author) + " PgUsr:" + str(self.page_log_user) + " Logs:" + str(self.count_logs) + " "
                logger.print_inline(count_msg, self.count_logs_len)
                self.count_logs_len = len(count_msg)

        if TESTING == False and list_author_activity and len(list_author_activity) > 0:
            try:
                AuthorActivity.objects.bulk_create(list_author_activity)
            except Exception:
                logger.error("\nException on Saving AuthorActivity, Mod:", c_mod.id_mod_id)
                _, _, tb = sys.exc_info()
                filename, lineno, funname, line = traceback.extract_tb(tb)[-1]
                print '{}:{}, in {}\n    {}'.format(filename, lineno, funname, line)
                return False
            del list_author_activity[:]

        # if DEBUG == True:
        #     logger.info("author_activity_count:", author_activity_count)
        return True

    def collect_mod_activity(self, uls, c_mod):
        TESTING = False
        DEBUG = False

        list_mod_activity = []

        # mod_activity_count = 0
        for ul in uls:
            lis = ul.find_all('li', recursive=False)

            for li in lis:
                modPageActivityObj = ModPageActivity()
                modPageActivityObj.begin_date = setDateTimeNow()
                modPageActivityObj.mod = c_mod.id_mod

                date = li.find('div', {'class': 'log-modified'})
                if date:
                    datetext = date.text.split("|")
                    modPageActivityObj.date = formateDateM_AM_PM(datetext[0])

                    # if DEBUG:
                    #     logger.info("\ndate: ", modPageActivityObj.date)

                author = li.find('a')

                authorLink = author.get('href')
                modPageActivityObj.user_url = authorLink
                # if DEBUG:
                #     logger.info("user_url: ", modPageActivityObj.user_url)

                authorName = author.text.strip()
                modPageActivityObj.user = authorName.encode()
                # if DEBUG:
                #     logger.info("user: ", modPageActivityObj.user)

                divLogChange = li.find('div', {'class': 'log-change'})
                title = divLogChange.find('h4')
                if title:
                    modPageActivityObj.title = title.text.encode()

                    # if DEBUG:
                    #     logger.info("title: ", modPageActivityObj.title)

                content = divLogChange.find('p')
                if content:
                    modPageActivityObj.content = content.text.encode()
                    # if DEBUG:
                    #     logger.info("content: ", modPageActivityObj.content)

                modPageActivityObj.finish_date = setDateTimeNow()
                # mod_activity_count += 1

                self.count_logs += 1

                list_mod_activity.append(modPageActivityObj)

                # if TESTING == False:
                #     modPageActivityObj.save()

                    # saved_activity = dao.get_mod_activity(modPageActivityObj)
                    # if saved_activity == None:
                    #     modPageActivityObj.save()

                # Status
                count_msg = "PgAth:" + str(self.page_log_author) + " PgUsr:" + str(self.page_log_user) + " Logs:" + str(self.count_logs) + " "
                logger.print_inline(count_msg, self.count_logs_len)
                self.count_logs_len = len(count_msg)

        if TESTING == False and list_mod_activity and len(list_mod_activity) > 0:
            try:
                ModPageActivity.objects.bulk_create(list_mod_activity)
            except Exception:
                logger.error("\nException on Saving ModPageActivity, Mod:", c_mod.id_mod_id)
                _, _, tb = sys.exc_info()
                filename, lineno, funname, line = traceback.extract_tb(tb)[-1]
                print '{}:{}, in {}\n    {}'.format(filename, lineno, funname, line)
                return False
            del list_mod_activity[:]

        # if DEBUG == True:
        #     logger.info("mod_activity_count:", mod_activity_count)
        return True

    def get_page_log(self, game_id, mod_id, offset, type):

        url_log = "https://www.nexusmods.com/Core/Libs/Common/Widgets/ModActionLogMonthlyViewer"
        form_data = {
            'game_id': game_id,
            'id': mod_id,
            'offset': offset,
            'filter': type
        }
        return network.get_page_content_post(url_log, form_data, True)

    def get_log_offset2(self, div, type):
        log_offset = None
        for offset in div:
            scripts = offset.find_all('script')
            for script in scripts:
                str_offset = script.text.strip().encode()
                if type == 'author' and "['author']" in str_offset:
                    if str_offset != "actionLogOffset['author'] = 0;":
                        log_offset = str_offset[28:-1]
                        break
                elif type == 'users' and "['users']" in str_offset:
                    if str_offset != "actionLogOffset['users'] = 0;":
                        log_offset = str_offset[27:-1]
                        break
        return log_offset

    def get_log_offset(self, soup, type):
        pattern = re.compile("actionLogOffset\[\'" + type + "\'\] = (.*?);")
        scripts = soup.find_all("script", text=pattern)

        str_offset = None
        for script in scripts:
            m = re.search("actionLogOffset\[\'" + type + "\'\] = (.+)[,;]{1}", str(script))
            if m and m.groups(0) and len(m.groups(0)) > 0:
                offset = m.groups(0)[0]
                if offset != '0':
                    str_offset = offset
        return str_offset

# --------------------------------- Coleta de stats ---------------------------------------------------------------------
    def collect_tab_stats(self, c_mod):
        DEBUG = False
        TESTING = False

        count_page_views = 0
        count_downloads = 0
        count_endorsements = 0
        count_stats_len = 0

        total_page_views = 0
        total_downloads = 0
        total_endorsements = 0

        list_page_views = []
        list_downloads = []
        list_endorsements = []

        mod_id = c_mod.id_mod_id
        game_id = c_mod.id_mod.game.id

        c_mod = CollectMod.objects.get(id_mod_id = c_mod.id_mod_id)
        if c_mod.collecting_statistics == True:
            return

        if c_mod.statistics_finalized == True:
            # logger.info("\nMod id:", c_mod.id_mod_id, " articles collect already completed.")
            return

        self.tab = STATS

        if TESTING == False:
            started = dao.enable_collecting_tab(self.tab, c_mod.id_mod_id)
            if not started:
            	self.tab = None
                return

        tab_url = c_mod.id_mod.url + '?tab=stats'

        # if DEBUG:
        #     logger.info("\n",tab_url)

        page_content = network.get_page_content(tab_url)
        if not page_content or len(page_content) == 0:
            logger.error("\nErro ao acessar a página de Stats do mod. Id:", c_mod.id_mod_id)
            self.stop_mod_collecting(c_mod)
            self.tab = None
            return

        soup = BeautifulSoup(page_content, 'lxml')

        if network.check_page_errors(soup, c_mod):
            self.stop_mod_collecting(c_mod)
            self.tab = None
            return

        if c_mod.statistics_finalized == False:

            pattern = re.compile('var endorsements = (.*?);')
            script = soup.find("script", text=pattern)
            m = re.search('var endorsements = (.+)[,;]{1}', str(script))
            if m:
                found = m.group(1)
            jdata = json.loads(found)

            newDictionary = None
            # newDictionary = json.loads(str(soup))

            url = "https://staticstats.nexusmods.com/mod_monthly_stats/" + str(c_mod.id_mod.game.nexus_id) + "/" + str(c_mod.id_mod.nexus_id_mod) + ".json"
            json_content = network.get_page_content(url)

            if json_content:
                json1 = json.loads(json_content)
                if json1:
                    newDictionary = json1
            #     else:
            #         logger.info("JSON is null")
            # else:
            #     logger.info("JSON Load Failed")

            if newDictionary == None:
                # logger.error("\nErro ao obter estatisticas. Json Nulo. Mod Id:", c_mod.id_mod_id)
                self.stop_mod_collecting(c_mod)

                c_mod.error_msg = "JSON_STATS_NOT_FOUND"
                c_mod.statistics_finalized = True
                c_mod.collecting_statistics = False
                if not TESTING:
                    c_mod.save(update_fields=["statistics_finalized", "collecting_statistics", "error_msg"])
                self.tab = None
                return

            if newDictionary['mod_page_views']:
                total_page_views = len(newDictionary['mod_page_views'])
            if newDictionary['mod_daily_counts']:
                total_downloads = len(newDictionary['mod_daily_counts'])
            if jdata:
                total_endorsements = len(jdata)

            for key, value in newDictionary['mod_page_views'].iteritems():
                # print key
                # print newDictionary['last_updated']

                pageview = PageViews()
                pageview.begin_date = setDateTimeNow()

                # pageview.game = Game.objects.get(nexus_id=c_mod.id_mod.game.nexus_id)
                pageview.game_id = game_id

                # pageview.mod = Mod.objects.get(nexus_id_mod=c_mod.id_mod.nexus_id_mod, url=c_mod.id_mod.url)
                pageview.mod_id = mod_id

                pageview.date = key
                pageview.number_of_views = value
                pageview.last_update = newDictionary['last_updated']
                pageview.finish_date = setDateTimeNow()

                count_page_views += 1

                # Status
                count_msg = ("PgV:" + str(count_page_views) + "/" + str(total_page_views)
                        + " Dow:" + str(count_downloads) + "/" + str(total_downloads)
                        + " End:" + str(count_endorsements) + "/" + str(total_endorsements))
                logger.print_inline(count_msg, count_stats_len)
                count_stats_len = len(count_msg)

                # if not TESTING:
                #     pageview.save()
                list_page_views.append(pageview)

                last_page_pv = count_page_views == total_page_views

                if TESTING == False and list_page_views and len(list_page_views) > 0:
                    if count_page_views % 500 == 0 or last_page_pv:
                        try:
                            PageViews.objects.bulk_create(list_page_views)
                        except Exception:
                            self.stop_mod_collecting(c_mod)
                            logger.error("\nException on Saving PageViews, Mod:", c_mod.id_mod_id)
                            _, _, tb = sys.exc_info()
                            filename, lineno, funname, line = traceback.extract_tb(tb)[-1]
                            print '{}:{}, in {}\n    {}'.format(filename, lineno, funname, line)
                            return
                        del list_page_views[:]

            for key, value in newDictionary['mod_daily_counts'].iteritems():
                downloads = Downloads()
                downloads.begin_date = setDateTimeNow()


                # downloads.game = Game.objects.get(nexus_id=c_mod.id_mod.game.nexus_id)
                downloads.game_id = game_id

                # downloads.mod = Mod.objects.get(nexus_id_mod=c_mod.id_mod.nexus_id_mod, url=c_mod.id_mod.url)
                downloads.mod_id = mod_id

                downloads.date = key
                downloads.number_of_downloads = value
                downloads.last_update = newDictionary['last_updated']
                downloads.finish_date = setDateTimeNow()

                # if not TESTING:
                #     downloads.save()

                count_downloads += 1

                # Status
                count_msg = ("PgV:" + str(count_page_views) + "/" + str(total_page_views)
                        + " Dow:" + str(count_downloads) + "/" + str(total_downloads)
                        + " End:" + str(count_endorsements) + "/" + str(total_endorsements))
                logger.print_inline(count_msg, count_stats_len)
                count_stats_len = len(count_msg)

                list_downloads.append(downloads)

                last_page_dw = count_downloads == total_downloads

                if TESTING == False and list_downloads and len(list_downloads) > 0:
                    if count_downloads % 500 == 0 or last_page_dw:
                        try:
                            Downloads.objects.bulk_create(list_downloads)
                        except Exception:
                            self.stop_mod_collecting(c_mod)
                            logger.error("\nException on Saving Downloads, Mod:", c_mod.id_mod_id)
                            _, _, tb = sys.exc_info()
                            filename, lineno, funname, line = traceback.extract_tb(tb)[-1]
                            print '{}:{}, in {}\n    {}'.format(filename, lineno, funname, line)
                            return
                        del list_downloads[:]

            for value in jdata:
                endorsements = Endorsements()
                endorsements.begin_date = setDateTimeNow()

                # endorsements.game = Game.objects.get(nexus_id=c_mod.id_mod.game.nexus_id)
                endorsements.game_id = game_id

                # endorsements.mod = Mod.objects.get(nexus_id_mod=c_mod.id_mod.nexus_id_mod, url=c_mod.id_mod.url)
                endorsements.mod_id = mod_id

                endorsements.date = formatDate(value['year'])
                endorsements.number_of_endorsements = value['endorsements']
                endorsements.last_update = formatDate(str(newDictionary['last_updated']).split('T')[0])
                endorsements.finish_date = setDateTimeNow()

                # if not TESTING:
                #     endorsements.save()

                count_endorsements += 1

                # Status
                count_msg = ("PgV:" + str(count_page_views) + "/" + str(total_page_views)
                        + " Dow:" + str(count_downloads) + "/" + str(total_downloads)
                        + " End:" + str(count_endorsements) + "/" + str(total_endorsements))
                logger.print_inline(count_msg, count_stats_len)
                count_stats_len = len(count_msg)

                list_endorsements.append(endorsements)

                last_page_en = count_endorsements == total_endorsements

                if TESTING == False and list_endorsements and len(list_endorsements) > 0:
                    if count_endorsements % 500 == 0 or last_page_en:
                        try:
                            Endorsements.objects.bulk_create(list_endorsements)
                        except Exception:
                            self.stop_mod_collecting(c_mod)
                            logger.error("\nException on Saving Endoserments, Mod:", c_mod.id_mod_id)
                            _, _, tb = sys.exc_info()
                            filename, lineno, funname, line = traceback.extract_tb(tb)[-1]
                            print '{}:{}, in {}\n    {}'.format(filename, lineno, funname, line)
                            return
                        del list_endorsements[:]

            # if DEBUG:
            #     logger.info("\nStats Finalized - Mod id:", c_mod.id_mod_id)

            c_mod.statistics_finalized = True
            c_mod.collecting_statistics = False
            if not TESTING:
                c_mod.save(update_fields=["statistics_finalized", "collecting_statistics"])

            self.tab = None
        return

    def mem(self):
        print('Memory usage         : % 2.2f MB' % round(
        resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024.0,1)
    )

