#coding: utf-8
import time
import warnings

from Logger import Logger
from scripts.Dao import Dao

from manager.models import CollectMod
from manager.models import ModTabs

logger = Logger()
dao = Dao()

warnings.filterwarnings("ignore", category=RuntimeWarning)

class ModManager:

    def populate_collect_mod(self):
        start_time = time.time()
        logger.info("---------------------------- Populando Tabela CollectMod ----------------------------")

        all_mods_count = dao.count_all_mods_populate()
        insert_mods_count = dao.count_insert_mods()
        progress_msg_len = 0

        while True:
            try:

                max_100 = dao.get_max_order(1000)
                if not max_100:
                    break
                for id in max_100:
                    collect_order_max = dao.get_max_collec_order()
                    if not collect_order_max:
                        collect_order = 1
                    else:
                        collect_order = collect_order_max + 1

                    mod_id = id[0]
                    if not mod_id:
                        break

                    collec_mod = CollectMod()
                    collec_mod.collect_order = collect_order
                    collec_mod.id_mod_id = mod_id
                    collec_mod.save()
                    insert_mods_count += 1

                    if insert_mods_count % 1000 == 0:
                        # Status
                        status_count = "%3d" % insert_mods_count + "/" + "%3d" % all_mods_count
                        progress = logger.get_progress_bar(insert_mods_count, all_mods_count, 50, True, " Mod's", " " + status_count)
                        logger.print_inline(progress, progress_msg_len)
                        progress_msg_len = len(progress)
            except Exception as e:
                # break
                logger.error("\nFalha na inserção dos mods. Id:" + str(mod_id))
                logger.error("Exception " + str(type(e)) + " {}".format(e))
        logger.info("\nTime:%.0f sec(s)." % (time.time() - start_time))
        logger.info("---------------------------- Tabela CollectMod Populada ----------------------------")
        return

    def populate_mod_tabs(self):
        start_time = time.time()
        logger.info("---------------------------- Populando Tabela ModTabs ----------------------------")

        all_mods_info_count = dao.count_all_mods_info()
        mod_tabs_count = dao.count_mod_tabs()
        progress_msg_len = 0

        while True:
            try:
                list_mods_info = dao.get_mods_info(1000)

                if not list_mods_info:
                    break

                for mod_info in list_mods_info:
                    mod_tabs = ModTabs()
                    mod_tabs.id_mod = mod_info.id_mod
                    mod_tabs.has_files = mod_info.amount_file > 0
                    mod_tabs.has_images = mod_info.amount_imagem > 0
                    mod_tabs.has_videos = mod_info.amount_video > 0
                    mod_tabs.has_articles = mod_info.amount_articles > 0
                    mod_tabs.has_posts = mod_info.amount_post > 0
                    mod_tabs.has_bugs = mod_info.amount_bug > 0
                    mod_tabs.has_forum = mod_info.amount_forum > 0
                    mod_tabs.save()

                    mod_tabs_count += 1

                    # Status
                    if mod_tabs_count % 100 == 0:
                        status_count = "%3d" % mod_tabs_count + "/" + "%3d" % all_mods_info_count
                        progress = logger.get_progress_bar(mod_tabs_count, all_mods_info_count, 50, True, " Mod's", " " + status_count)
                        logger.print_inline(progress, progress_msg_len)
                        progress_msg_len = len(progress)

            except Exception as e:
                logger.error("\nFalha na inserção dos mods.")
                logger.error("Exception " + str(type(e)) + " {}".format(e))

        logger.info("\nTime:%.0f sec(s)." % (time.time() - start_time))
        logger.info("---------------------------- Tabela ModTabs Populada ----------------------------")
        return