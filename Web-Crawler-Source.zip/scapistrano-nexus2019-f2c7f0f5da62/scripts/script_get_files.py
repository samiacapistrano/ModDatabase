# -*- coding: utf-8 -*-
from manager.models import File
from manager.models import Mod

from scripts.function_util import tranformationOfComputerMeasureUnit
from scripts.function_util import tranformationAmount
from scripts.function_util import formatDescribeMonth
from scripts.function_util import addingSelenium
from scripts.function_util import setDateTimeNow
from bs4 import BeautifulSoup
import time


def getFilesMods(link, modObj,tempo):

    try:
        browser = addingSelenium(link)
        time.sleep(int(tempo))

        soupContent = BeautifulSoup(browser.page_source, 'html.parser')
        browser.close()
        # Name, Version, File size, Date uploaded, Unique DLs, Total DLs of Files
        listFiles = soupContent.find_all('div', attrs={'class': 'tabbed-section tabbed-block files-tabs'})
        # list type files
        for files in listFiles:

            i = 1;
            nameTypeFile = str(files.h2.text)
            #print nameTypeFile

            # file.name = files.h2.text

            if nameTypeFile.__eq__("Miscellaneous files") or files.h2.text.__eq__("Old files"):
                dadosFileMain = files.findAll('dt', attrs={'class': "clearfix"})
            else:
                dadosFileMain = files.findAll('dt', attrs={'class': "clearfix accopen"})

            for listMain in dadosFileMain:
                fileObjt = File()
                fileObjt.begin_date = setDateTimeNow()

                if nameTypeFile.__eq__("Miscellaneous files"):
                    fileObjt.miscellauneous_file = True
                    fileObjt.main_file = False
                    fileObjt.update_file = False
                    fileObjt.optional_file = False
                    fileObjt.old_file = False
                elif (files.h2.text.__eq__("Old files")):
                    fileObjt.old_file = True
                    fileObjt.miscellauneous_file = False
                    fileObjt.main_file = False
                    fileObjt.update_file = False
                    fileObjt.optional_file = False
                elif files.h2.text.__eq__("Main files"):
                    fileObjt.main_file = True
                    fileObjt.miscellauneous_file = False
                    fileObjt.update_file = False
                    fileObjt.optional_file = False
                    fileObjt.old_file = False
                elif files.h2.text.__eq__("Optional files"):
                    fileObjt.optional_file = True
                    fileObjt.miscellauneous_file = False
                    fileObjt.main_file = False
                    fileObjt.update_file = False
                    fileObjt.old_file = False
                elif files.h2.text.__eq__("Update files"):
                    fileObjt.update_file = True
                    fileObjt.miscellauneous_file = False
                    fileObjt.main_file = False
                    fileObjt.optional_file = False
                    fileObjt.old_file = False
                else:
                    print str(files.h2.text) + " Arquivo desconhecido [ CORRECAO ]"

                listSpan = listMain.findAll('span')
                fileObjt.name = listSpan[2].text.encode('utf-8')
                listDateStat = listSpan[4].findAll('div', attrs={'class': 'statitem'})
                for listDate in listDateStat:
                    text = listDate.text.strip("\n").split("\n")
                    if str(text[0]).__eq__("Version"):
                        if len(text) > 2:
                            if text[2] and text[2] != ' ' and text[2] != '':
                                fileObjt.version = str(text[2])
                            else:
                                fileObjt.version = str(text[3])
                        else:
                            fileObjt.version = "NOT VERSION"
                    elif str(text[0]).__eq__("Date uploaded"):
                        fileObjt.uploaded_date = formatDescribeMonth(text[1])
                            #datetime.strptime(str(text[1]), '%d %b %Y, %I:%M%p').strftime('%Y-%m-%d')
                    elif str(text[0]).__eq__("File size"):
                        fileObjt.file_size = tranformationOfComputerMeasureUnit(text[1])
                    elif str(text[0]).__eq__("Unique DLs"):
                        fileObjt.unique_dls = tranformationAmount(text[1])
                        # fileObjt.unique_dls = str(text[1])
                    elif str(text[0]).__eq__("Total DLs"):
                        fileObjt.total_dls = tranformationAmount(text[1])
                        # fileObjt.total_dls = str(text[1])

                    else:
                        print "Nova versao" + str(text[0])
                        # dadosMod.update({unicode(nameTypeFile + " " + str(i) + " ") + text[0]: text[1]})
                        print modObj

                if Mod.objects.filter(name=modObj.name,url=modObj.url):
                    #modAux = Mod.objects.get(name=modObj.name,url=modObj.url)[:1]
                    #print modObj.name
                    #print modObj.url
                    modAux = Mod.objects.get(url=modObj.url)
                    #modAux = Mod.objects.filter(url=modObj.url)
                    #modQ = Mod.objects.filter(name=modObj.url)
                    #modAux = modQ.exclude(url=modObj.name)[:1]
                    fileObjt.mod = modAux
                    #print str(fileObjt.name) + " Arquivo Salvo do Mod: " + str(modAux.name)

                else:
                    print "Erro ao associar Mod ao Arquivo"

                # fileObjt.mod = modObj
                fileObjt.finish_date = setDateTimeNow()
                fileObjt.save()

                i = i + 1
        #print dadosMod
    except:
        #Erro
        print "Erro de arquivos"
        #getFilesMods(link, modObj, tempo + 1)
