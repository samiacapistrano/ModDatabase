# -*- coding: utf-8 -*-
import django
import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mysite.settings_samia")
django.setup()
# ------------ -----------------RUN SCRIPT -------------------------------------------
# ./manage.py shell < scripts/main.py --settings=mysite.settings_samia

# -- 1: GAME INFO --------------------------------------------------------------------
# -- Coleta os Games.
# from scripts.GameCollector import GameCollector
# game_collector = GameCollector()
# game_collector.collect_basic_info(False)

# -- 2: COUNT GAMES PAGES ------------------------------------------------------------
# -- Coleta a quantidade de páginas e Mods dos GAMES.
# from scripts.GameCollector import GameCollector
# game_collector = GameCollector()
# game_collector.count_pages_and_mods()

# -- 3: RESET GAMES STATUS -----------------------------------------------------------
# -- Altera a flag de conclusão dos Games para incompleto.
# from scripts.GameCollector import GameCollector
# game_collector = GameCollector()
# game_collector.set_games_status_to_incomplete()

# --- 4: MOD BASIC INFO --------------------------------------------------------------
# --- Coleta as informações básicas dos Mods.
# from scripts.GameCollector import GameCollector
# game_collector = GameCollector()
# game_collector.collect_mods_info()

# --- 5: MOD INFO, TAGS & AMOUNT -----------------------------------------------------
# --- Coleta informações básicas dos Mods, Tags e quantidade de dados por Aba.
#from scripts.script_amount_info_mod import collect_amount_info
#collect_amount_info()

# --- 6: MODER ------------------------------------------------------------------------
# --- Coleta os Modders.
# --- Rodar scrip_user.py antes de iniciar a coleta de modders para logar no nexusmods.
# ./manage.py shell < scripts/script_user.py --settings=mysite.settings_samia
# from scripts.ModderCollector import ModderCollector
# modder_collector = ModderCollector()
# modder_collector.collect_basic_info()

# --- 7° POPULATE CollectMods ---------------------------------------------------------
# --- Popula a tabela CollectMods com as informações para coletar as abas dos Mods.
# from scripts.ModManager import ModManager
# mod_manager = ModManager()
# mod_manager.populate_collect_mod()

# --- 8° POPULATE ModTabs
# --- Popula a tabela ModTabs com as informações das abas dos Mods.
# from scripts.ModManager import ModManager
# mod_manager = ModManager()
# mod_manager.populate_mod_tabs()

# --- 9: MOD --------------------------------------------------------------------------
# --- Coleta as abas dos Mods.

# import os
from scripts.ModCollector import ModCollector
from manager.models import CollectMod

# print "Process:" + str(os.getpid())

mod_collector = ModCollector()
mod_collector.collect_mods_loop2()


# --------------------------------- TESTE COLETA MOD ----------------------------------
# from scripts.ModCollector import ModCollector
# mod_collector = ModCollector()
# mod_collector.test_collect_mod(132046)
# https://www.nexusmods.com/skyrim/mods/3863
# https://www.nexusmods.com/skyrim/mods/19281
# mod_collector.test_collect_mod(None, "https://www.nexusmods.com/skyrim/mods/3863")

