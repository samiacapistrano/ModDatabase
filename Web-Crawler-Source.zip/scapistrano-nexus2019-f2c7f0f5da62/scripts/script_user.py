#coding: utf-8
import django
import os
import sys
import time

from scripts.ModderCollector import ModderCollector

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mysite.settings_samia")
django.setup()

# ------  RUN  --------
# ./manage.py shell < scripts/script_user.py --settings=mysite.settings_samia

modder_collector = ModderCollector()
modder_collector.login_loop()