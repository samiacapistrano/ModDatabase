# -*- coding: utf-8 -*-
import django
import os
import sys
import time

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mysite.settings_samia")
django.setup()

from scripts.script_get_mods_info import allDataMod
from scripts.function_util import criarBrowser
from scripts.script_get_logs import getLogs
# from scripts.selenium_pagination_mods_info import getBasicInformationModIniti

from scripts.GameCollector import GameCollector
from scripts.ModderCollector import ModderCollector
from scripts.ModCollector import ModCollector

# from scripts.teste_amount_info_mod import amountInfoMod
from scripts.script_amount_info_mod import amountInfoMod
from scripts.script_amount_info_mod import get_next_incomplete_mod

# from scripts.ModInfoCollector2 import ModInfoCollector

from manager.models import Game


# ------  RUN  --------
# ./manage.py shell < scripts/script_main.py --settings=mysite.settings_samia

#from script_get_logs import getLogs
#getLogs(None,None,None)


# --------------------------------- GAME ---------------------------------
# game_collector = GameCollector()
# game_collector.collect_game_mods_info(None, 33)

#   1° - COLETA GAME's INFO
#coleta as informações do Game
# game_collector.collect_basic_info(False)

#   2° - Contagem das Páginas e Mods dos GAMES
#verificação da quantidade de mod por Game
# game_collector.count_pages_and_mods()

#   3° - Alterar todos os Games para incompletos
#resetar a flag de conclusão do game
# game_collector.set_games_status_to_incomplete()

# ------------------------ MOD BASIC INFO ---------------------------------
#   4° - COLETA MOD's INFO
# coleta as informações básicas do Mod por Game
# game_collector.collect_mods_info()
# game_collector.collect_game_mods_info(None, 1, 303)

#   5° - Coleta da quantidade de dados do mod
#coleta a quantidade de dados das abas do Mod, suas informações básicas e Tags.

# amountInfoMod()

# mod = get_next_incomplete_mod()
# if mod:
#     print mod.id

# teste()
# mod_collector = ModCollector()

# ./manage.py shell < scripts/test_abas.py --settings=mysite.settings_samia

# Mods collect_order Top 20
# 132046, 194346, 88755, 158215, 146877, 103273, 186012, 108241, 101941, 91034, 208083, 97713, 55311, 133843, 172970, 84252, 100325, 90234, 203114, 54900, 83315, 179113, 116506, 172443, 171100, 95905, 192984, 17595, 31399, 119466, 1398, 110299, 166896, 58385, 175438, 160405, 103389, 88269, 197193, 43571, 114130, 8546, 180581, 89814, 1754, 43117, 81833, 153649, 195384, 45603, 168608, 43523, 85648, 93345, 105270, 178115, 97, 127716, 39221, 55088, 138350, 180749, 20461, 172396, 153643, 169735, 23183,
# list = [62990, 63345, 63704, 63824, 65057, 65099, 65450, 65867, 66230, 66248, 66534, 66598, 67204, 67808, 69019, 69807, 69960, 70067, 70137, 70533, 70537, 70652, 70786, 71030, 71047, 72465, 72689, 72759, 72785, 73104, 73529, 73935, 74033, 74182, 74723, 74819, 74894, 75454, 75941, 76055, 76205, 76327, 77503, 78632, 78665, 78670, 79117, 79286, 79920, 79935, 80011, 80057, 80063, 80935, 81205, 81311, 81904, 81986, 82087, 82369, 82710, 83329, 83336, 84238, 84496, 84499, 84831, 84842, 84959, 85281, 85320, 86608, 86939, 87293, 87548, 87716, 87786, 87979, 88222, 88252, 88568, 89369, 89648, 90180, 90517, 90592, 90765, 90957, 91061, 91229, 91247, 91627, 91963, 92009, 92719, 93129, 93133, 93356, 93616, 93941]
# list = [94004, 94011, 94071, 94236, 94761, 94772, 94865, 94881, 95196, 95342, 95466, 95552, 95837, 95873, 96277, 96407, 96527, 96717, 97025, 97606, 97689, 98062, 98351, 98818, 99020, 99452, 99617, 99639, 100052, 100318, 100319, 100372, 100400, 100471, 100841, 101423, 101483, 102384, 103217, 103252, 103297, 103412, 103557, 103996, 104015, 104278, 104759, 104768, 104828, 105040, 105128, 105416, 105433, 105679, 105789, 105809, 105823, 105844, 106243, 106325, 106333, 106402, 106506, 106621, 106891, 106939, 107069, 107402, 107474, 107776, 107944, 108347, 108381, 108404, 109013, 109075, 109245, 109447, 109581, 109604, 109613, 109808, 110550, 110797, 111276, 111411, 111440, 111476, 111919, 111964, 112169, 112211, 112231, 112779, 112863, 113067, 113092, 113685, 113712]
# list = [113926, 114601, 114761, 114967, 114983, 115946, 116139, 116323, 116495, 116544, 116603, 116608, 116901, 117071, 117076, 117373, 117675, 117677, 117862, 118418, 118653, 118779, 118884, 119664, 120081, 120145, 120147, 120283, 120313, 120382, 120409, 120449, 120911, 121397, 122127, 122307, 122321, 122329, 123013, 123048, 123393, 123394, 123405, 123416, 123880, 123898, 124088, 124153, 124446, 124620, 124681, 124752, 124961, 124965, 125169, 125343, 125358, 125429, 125565, 126318, 126423, 126751, 126762, 126873, 126921, 127888, 128602, 128693, 128999, 129233, 129340, 129640, 129862, 129877, 130261, 130536, 130655, 130656, 130785, 130964, 131181, 131611, 132079, 132782, 132952, 133495, 135027, 135238, 135325, 135333, 135470, 136145, 136613, 136616, 136974, 137948, 138430, 138583, 138885]
# list = [139706, 139757, 140030, 140301, 140326, 140627, 140878, 141628, 141699, 142548, 143047, 143246, 143739, 143854, 144619, 144828, 145143, 145216, 145637, 146002, 146375, 146442, 146477, 148434, 148435, 148535, 148711, 148986, 149207, 149648, 149653, 149658, 149661, 149796, 149890, 150199, 150491, 151118, 151199, 151282, 151389, 151396, 151397, 151539, 151913, 152030, 152087, 152149, 152759, 153340, 153488, 153999, 154510, 154557, 154828, 154893, 154962, 154967, 155231, 155403, 155945, 156305, 156551, 156555, 156559, 156644, 156758, 157801, 158482, 159049, 159105, 159164, 159923, 160460, 160508, 161088, 161394, 161997, 162865, 163623, 164275, 164805, 165155, 165251, 165370, 165373, 165947, 166330, 168154, 168615, 168855, 169676, 169785, 169886, 170373, 170465, 170546, 170819, 171026]
# list = [171203, 171376, 171664, 171710, 171743, 171837, 171936, 172021, 172137, 172260, 172557, 173225, 173238, 173687, 173733, 173787, 173891, 173972, 174052, 174538, 174715, 174814, 174989, 175077, 175380, 175609, 175924, 176310, 176838, 176938, 177061, 177380, 177592, 177843, 177995, 178073, 178267, 178576, 178750, 178814, 178868, 179178, 179579, 179719, 179811, 179952, 180700, 181149, 181254, 181468, 181759, 181806, 181840, 181860, 181936, 182436, 182807, 183086, 183429, 183549, 183831, 184757, 184848, 185018, 185056, 185160, 185236, 185451, 185656, 185766, 185919, 185967, 186067, 186094, 186120, 186280, 186325, 186351, 186435, 186517, 187421, 187552, 187670, 188247, 188342, 188345, 188591, 188848, 189001, 189036, 189247, 189306, 189445, 189462, 189534, 189635, 189669, 189825, 190029, 190558, 190623, 190670, 190755, 190976, 191164, 191755, 191805, 192018, 192154, 193051, 193218, 193249, 193304, 193348, 193363, 193474, 193848, 194007, 194409, 194526, 194562, 194594, 194681, 194820, 195123, 195370, 195372, 195421, 196154, 196176, 196200, 196463, 197191, 198398, 198514, 198549, 198937, 199120, 199224, 199268, 200210, 200661, 200734, 200737, 201367, 201995, 202344, 202384, 202385, 202660, 202756, 202794, 202832, 202963, 202968, 203139, 203306, 203617, 203787, 203876, 204097, 204206, 204275, 204405, 204663, 204806, 204869, 205195, 205338, 205356, 205398, 205554, 205633, 205694, 205902, 205907, 205989, 206055, 
# list = [206247, 206312, 206536, 206761, 207157, 207513, 207743, 207758, 208077, 208201, 208227, 208464, 208867, 208870, 208891, 209033, 209083, 209102, 209381, 209578, 210168, 210221, 210243, 210709, 210710, 210763, 211140, 211340, 211589, 211681, 211864, 211927, 212099, 212327, 212805, 212871, 213406, 213473, 213558, 213627, 213682, 215578, 215583, 216459, 216487, 216637, 218379, 220873, 224102]
# print "List 5"
# count = 0
# for id in list:
#     count += 1
#     print "Starting collect id:" + str(id) + " " + str(count) + "/49"
#     amountInfoMod(id)


# ---------------------------- MODDER -------------------------------------
#   6° - COLETA MODDER

    # Rodar scrip_user.py antes de iniciar a coleta de modders
    #  ./manage.py shell < scripts/script_user.py --settings=mysite.settings_samia

# modder_collector = ModderCollector()
# modder_collector.collect_basic_info()

# ------------------------------ MOD ---------------------------------------
mod_collector = ModCollector()
#   7° POPULAR TABLE CollectMods COM OS MODS
# mod_collector.populate_collect_mod()

#   8° POPULAR TABELA ModTabs COM OS MODS
# mod_collector.populate_mod_tabs()

#   9° COLETA DOS MOD
# mod_collector.collect_mods_loop()

# ./manage.py shell < scripts/test_abas.py --settings=mysite.settings_samia
# mod_collector.collect_mod_tabs(None, 132046)
# mod_collector.collect_mod_tabs()

# https://www.nexusmods.com/skyrim/mods/12974?tab=logs

# mod_collector.test_collect_mod(132046, None)
# mod_collector.test_collect_mod(133843, None)


# mod_collector.test_forum()
# mod_collector.count_complete_collect_mod()

# hidden
# mod_collector.collect_mod_tabs(None, 220079)


# execfile('script_get_games_info.py')
# execfile('/home/nexus/Documentos/nexus2019/scripts/script_get_games_info.py')
# getBasicInformationModIniti("https://www.nexusmods.com/oblivion/mods/?BH=230", 230, "oblivion")


#link_abas = "https://www.nexusmods.com/morrowind/mods/41102?tab=logs"
#link_abas = "https://www.nexusmods.com/morrowind/mods/27588?tab=logs"
#3idMod = 41102
#idMod = 27588
#modURL = "https://www.nexusmods.com/morrowind/mods/41102"
#modURL = "https://www.nexusmods.com/morrowind/mods/27588"

#link = 'https://www.nexusmods.com/morrowind/mods/'+str(idMod)+'?tab=logs'
#link = 'https://www.nexusmods.com/'+str(modObj.game.domain_name)+'/mods/'+str(modObj.nexus_id_mod)+'?tab=logs'

#getLogs(link,idMod, modURL)


# try:
#     browserPerfilUser = criarBrowser()
#     executionComplete = False
#
#     allDataMod(browserPerfilUser, executionComplete)
# except:
#     browserPerfilUser = criarBrowser()
#     executionComplete = False
#
#     allDataMod(browserPerfilUser, executionComplete)

