

# https://www.nexusmods.com/skyrim/mods/607?tab=bugs
import os

import django
from bs4 import BeautifulSoup
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

#os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mysite.settings_pamsn")
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mysite.settings_samia")
django.setup()

from manager.models import Mod, Bug, BugComment
from scripts.function_util import addingSelenium
from scripts.function_util import getPagingNumber
from scripts.function_util import formateDateM_AM_PM
from scripts.function_util import movePag
from scripts.function_util import setDateTimeNow
import time



def getBugs(link_abas, idMod ,modURL):

    #browser = addingSelenium("https://www.nexusmods.com/skyrim/mods/607?tab=bugs")
    browser = addingSelenium(link_abas)

    soup = BeautifulSoup(browser.page_source, 'html.parser')
    datas = soup.find_all("script")
    listPag = []
    for data in datas:
        #time.sleep(10)
        if "$( function(){Filters_Pagination.Load(" in data.text:
            listPag = getPagingNumber(data.string)
            break
    if not len(listPag):
        listPag.append(1)

    forum_links = []
    for page_index in range(1,len(listPag) + 1):
        if len(listPag) > 1 and not int(page_index) == 1:
            elemt =     movePag(browser)
            try:
                elemt[0].send_keys(page_index)
                elemt[0].send_keys(Keys.ENTER)
            except:
                elemt[0].send_keys(page_index)
                elemt[0].send_keys(Keys.ENTER)

            time.sleep(3)


        # print table_body
        soup = BeautifulSoup(browser.page_source, 'html.parser')
        table = soup.find('table', attrs={'class': 'table forum-bugs flex-table'})
        table_body = table.find('tbody')
        rows = table_body.find_all('tr')
        anterior = 0
        flag = False
        for row in rows:
            cols = row.find_all('td')
            if (cols):
                atags = row.find_all('a', {'class': 'issue-title'}, href=True, text=True)
                # print row
                for atag in atags:
                    td_status = row.find_all('td', {'class': 'table-bug-status'})
                    td_replies = row.find_all('td', {'class': 'table-bug-replies'})
                    td_version = row.find_all('td', {'class': 'table-bug-version'})
                    td_priority = row.find_all('td', {'class': 'table-bug-priority'})
                    td_lastpost = row.find_all('td', {'class': 'table-bug-post'})
                    print "Issue title :" + atags[0].text
                    #print "Status : " + td_status[0].text
                    #print "Replies : " + td_replies[0].text
                    #print "Version : " + td_version[0].text
                    #print "Priority : " + td_priority[0].text
                    #print "Post : " + td_lastpost[0].text

                    bug = Bug()
                    bug.begin_date = setDateTimeNow()
                    bug.mod = Mod.objects.get(nexus_id_mod=idMod, url=modURL)
                    bug.title = atags[0].text
                    bug.status = td_status[0].text
                    bug.replies = td_replies[0].text
                    bug.version = td_version[0].text
                    bug.priority = td_priority[0].text
                    bug.last_post = formateDateM_AM_PM(td_lastpost[0].text)


                    # bug = Bug(Mod.objects.get(nexus_id_mod=607), title=atags[0].text, status=td_status[0].text, replies=td_replies[0].text,
                    #           version=td_version[0].text, priority=td_priority[0].text, last_post=td_lastpost[0].text)
                    bug.finish_date = setDateTimeNow()
                    bug.save()

                    issue = WebDriverWait(browser, 3).until(EC.element_to_be_clickable((By.CLASS_NAME, "issue-title")))

                    if flag==True:
                        browser.execute_script("loadIssueReplies(" + anterior + ");", issue)
                        time.sleep(2)
                    browser.execute_script("loadIssueReplies(" + atag['id'].split("_")[1] + ");", issue)

                    anterior = atag['id'].split("_")[1]

                    time.sleep(6)

                    flag = True

                    soup2 = BeautifulSoup(browser.page_source, 'html.parser')
                    tr = soup2.find('tr',{'id': 'issue_' + str(atag['id'].split("_")[1])})
                    div = tr.find('div', {'class': 'comments'})
                    lis = div.find_all('li', {'class': 'comment'})

                    if not lis:
                        soup2 = BeautifulSoup(browser.page_source, 'html.parser')
                        tr = soup2.find('tr', {'id': 'issue_' + str(atag['id'].split("_")[1])})
                        div = tr.find('div', {'class': 'comments'})
                        lis = div.find_all('li', {'class': 'comment'})

                    if lis:
                        for li in lis:
                            span1s = li.find_all('span', {'class': 'comment-name'})
                            span2s = li.find_all('span', {'class': 'status-user'})
                            bugComment = BugComment()
                            bugComment.begin_date = setDateTimeNow()
                            print '---*'
                            for span1 in span1s:
                                print span1.text
                                bugComment.name = span1.text
                            for span2 in span2s:
                                print span2.text
                                bugComment.status=span2.text
                            divs = li.find_all('div', {'class': 'comment-content'})
                            for div in divs:
                                print div.text
                                bugComment.content=div.text
                            bugComment.bug = bug
                            bugComment.finish_date = setDateTimeNow()
                            bugComment.save()


        browser.refresh()
        time.sleep(3)

    browser.close()

