#coding: utf-8

import sys
import time

from datetime import datetime
from pytz import timezone

class Logger:
    global timezone
    global datetime

    TIME_FORMATTER = '%d/%m/%Y %H:%M:%S'

    SUCCESS = '\033[92m'
    WARNING = '\033[93m'
    ERROR = '\033[91m'
    ENDC = '\033[0m'

    wait_message_len = 0

    def __init__(self):
        self.spinner = self.spinning_cursor()

    def log(self, color, items):
        timestamp = self.get_time_str(self.TIME_FORMATTER)
        msg = timestamp + ' '
        if items and len(items) > 0 and items[0] and isinstance(items[0], basestring) and items[0][:1] == '\n':
            msg = '\n' + timestamp + ' '
            items[0] = items[0][1:]
        for item in items:
            msg += str(item)
        print(color + msg + Logger.ENDC)

    def info(self, *args):
        if args and len(args) > 0:
            self.log(Logger.WARNING, list(args))
        else:
            self.log(Logger.WARNING, "None")

    def error(self, *args):
        if args and len(args) > 0:
            self.log(Logger.ERROR, list(args))
        else:
            self.log(Logger.WARNING, "None")

    def success(self, *args):
        if args and len(args) > 0:
            self.log(Logger.SUCCESS, list(args))
        else:
            self.log(Logger.WARNING, "None")

    def get_time_str(self, formmater = '%d-%m-%Y %H:%M:%S'):
        global datetime
        global timezone

        zone = 'America/Bahia'
        date_time = datetime.now(timezone(zone)).strftime(formmater)
        return str(date_time)

    def get_progress_bar(self, i, max, size=10, with_time=False, pre="", post=""
            , color='\033[92m', bg_color='\033[0m'):
        if max == 0:
            j = 0
        else:
            j = round(100 * float(i)/float(max))
        char = '█'
        char2 = '▒'

        time = ""
        if with_time:
            time = self.get_time_str()

        bar = color + (char * int(size * (j/100)))
        bg_bar = bg_color + (char2*(size - int(size*(j/100))))
        return  time + " " + pre + " " + bar + bg_bar + " " + "%.0f" % j + "% " + post

    def print_inline(self, msg, msg_len):
        global sys
        sys.stdout.write((b'\x08' * msg_len).decode())
        sys.stdout.write(msg)
        sys.stdout.flush()
        return

    def print_clear(self, msg):
        global sys
        self.clear_line()
        sys.stdout.write(msg)
        sys.stdout.flush()
        return

    def wait_message(self, msg, delay, post=""):
        global time

        for i in range(delay, -1, -1):
            sys.stdout.flush()
            sys.stdout.write((b'\x08' * self.wait_message_len).decode())
            sys.stdout.write((' ' * self.wait_message_len).decode())
            sys.stdout.write((b'\x08' * self.wait_message_len).decode())
            status_msg = msg + ' ' + str(i) + post + ' '
            sys.stdout.write(status_msg)

            for i in range(0,3):
                sys.stdout.write(next(self.spinner) + ' ')
                sys.stdout.flush()
                sys.stdout.write('\b'*2)
                time.sleep(0.25)

            self.wait_message_len = len(status_msg) + 1
        return

    def spinning_cursor(self):
        while True:
            for cursor in '|/-\\':
                yield cursor

    def clear_line(self):
        sys.stdout.write("\r\x1b[K")