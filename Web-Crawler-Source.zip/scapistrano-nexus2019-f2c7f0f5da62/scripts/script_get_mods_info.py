#!/usr/bin/env python
# -*- coding: utf-8 -*-
from django.utils import timezone
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.expected_conditions import visibility_of
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
from datetime import datetime
from decimal import Decimal
import requests
import bs4
from django.conf import settings
import django
import ast
from selenium import webdriver
import re
import time
import os

#from mysite import *

#__init__.py

#
# usernameStr = 'SCapistrano'
# passwordStr = 'As10222421'

# browser = webdriver.Chrome('/Users/pamsn/projetos/games/codigo/mysite/chromedriver')
#
# browser.get('https://www.nexusmods.com/fallout3/mods/23137')
# html_source = browser.page_source
# print html_source

#importando HTML
import urllib2,cookielib


#settings.configure()

#./manage.py shell < scripts/script_get_mods_info.py --settings=mysite.settings_samia
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mysite.settings_samia")
django.setup()
from manager.models import Mod
from manager.models import Game


from scripts.script_modder import getModder
from scripts.script_tags_mod import getTags
from scripts.script_get_files import getFilesMods
from scripts.script_get_images import getImages
from scripts.script_get_videos import getVideo
from scripts.script_forum import getForum
from scripts.script_get_posts import getCommentPost
from scripts.script_get_articles import getArticles
from scripts.script_get_bugs import getBugs
from scripts.script_get_logs import getLogs
from scripts.script_stats import getStats
from scripts.function_util import criarBrowser
from scripts.function_util import addingSelenium
from scripts.function_util import setDateTimeNow

def allDataMod(browserPerfilUser, executionComplete):

    #try:
    while not executionComplete:

        modQ = Mod.objects.filter(amount_endorsements__gte=1000)
        mod = modQ.exclude(captura_mod_finalizada=True)[:1]


        # try:
        if len(mod) < 1:
            executionComplete = True
            break

        print mod[0].name + ' url: ' + mod[0].url

        mod[0].mod_running = True
        mod[0].begin_date = setDateTimeNow()
        mod[0].save()

        site = mod[0].url
        hdr = { 'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'}
        r = urllib2.Request(site, headers=hdr)
        try:
            page = urllib2.urlopen(r) #web
        except urllib2.HTTPError, e:
            print e.fp.read()

        content = page.read()
        soup = BeautifulSoup(content, 'lxml')

        try:
            idMod = getModId(soup)
        except:
            print "Mod não encontrado"
            print mod[0].name
            #adicionar um campo para mod q não foram encontrados
            mod[0].executionComplete = True
            mod[0].captura_mod_finalizada = True
            mod[0].finished_execution = True
            mod[0].finish_date = setDateTimeNow()

            mod[0].save()
            #mod não encontrado
            #break

        time = 2
        if mod[0].captura_mod_finalizada:
            if mod[0].captura_mod_finalizada != True:
                getModInfo(mod[0], idMod, hdr, browserPerfilUser, content, time)
        else:
            getModInfo(mod[0], idMod, hdr, browserPerfilUser, content, time)
        mod[0].finished_execution=True
        mod[0].finish_date = setDateTimeNow()
        mod[0].save()


def getModInfo(modObj, idMod, hdr, browserPerfilUser, content, tempo):

    try:
        browser = addingSelenium(modObj.url)
        wait = WebDriverWait(browser, 3)
        element = wait.until(EC.text_to_be_present_in_element((By.ID, "description_tab_h2"), "About this mod"))
        soup = BeautifulSoup(browser.page_source, 'html.parser')
        browser.close()

        modObj.nexus_id_mod = idMod

        listStat = soup.find_all('ul', {'class': 'stats clearfix'})
        for stat in listStat[0]:
            if isinstance(stat, bs4.element.Tag):
                text = stat.text.strip("\n").split("\n")
                if (text[1].__eq__("Unique DLs")):
                    modObj.amount_unique_dls = int(str(text[2]).replace(",", ""))
                elif (text[1].__eq__("Total views")):
                    if not  (text[2].__eq__(" -- ")):
                        modObj.amount_views = int(str(text[2]).replace(",", ""))
                elif (text[1].__eq__("Version")):
                    if len(text) > 2:
                        modObj.number_versions = str(text[2])
                    else:
                        modObj.number_versions = None
                elif (text[1].__eq__("Endorsements")):
                    if not modObj.amount_endorsements:
                        modObj.amount_endorsements = int(str(text[2]).replace(",", ""))
                elif (text[1].__eq__("Total DLs")):
                    if not modObj.amount_total_dls:
                        modObj.amount_total_dls = int(str(text[2]).replace(",", ""))
                else:
                    print "Dado desconhecido" + str(text[1])
    except:
        getModInfo(modObj, idMod, hdr, browserPerfilUser, content, tempo + 1)

    listInfoFile = soup.find_all("div", attrs={"id": "fileinfo"})
    divs = listInfoFile[0].findAll("div", attrs={'class': 'sideitem'})
    auxTex = divs[2].text.strip("\n").split("\n")
    if len(auxTex)==2:
        modObj.created_by = auxTex[1]


    auxTex = divs[3].text.strip("\n").split("\n")
    if len(auxTex) == 2:
        modObj.uploads_by = getModder(auxTex[1], divs, hdr, browserPerfilUser)

    modObj.save()

    getTags(soup, modObj)

    idgame = getGameId(soup)
    modObj.game = Game.objects.get(nexus_id=idgame)

    modObj.save()

    # abas
    link2 = "https://www.nexusmods.com/Core/Libs/Common/Widgets/Mod"
    aba2 = soup.find_all('ul', {'class': 'modtabs'})[0].contents  # type: object
    for aba in aba2:
 #   for aba in aba2:

        if isinstance(aba, bs4.element.Tag):

            list = aba.text.strip("\n").split("\n")
            if len(list) > 1:
                quant = int(str(list[1]).replace(",", ""))
            else:
                quant = 0

            link_abas = link2 + list[0] + "Tab?id=" + str(idMod) + "&game_id=" + str(idgame)

            response = requests.get(link_abas, headers=hdr)
            #requests.exceptions.ConnectionError: HTTPSConnectionPool(host='www.nexusmods.com', port=443):
            # Max retries exceeded with url: /Core/Libs/Common/Widgets/ModDescriptionTab?id=28311&game_id=100
            # (Caused by NewConnectionError('<urllib3.connection.VerifiedHTTPSConnection object at 0x7f3ede098b10>:
            # Failed to establish a new connection: [Errno -2] Name or service not known',))

            content2 = response.text
            soupContent = BeautifulSoup(content2, 'lxml')

            if (list[0].__eq__("Files") and quant > 0):
                if  modObj.capturing_files_finalized == False:
                    #https://www.nexusmods.com/skyrim/mods/98626?tab=files

                    link = 'https://www.nexusmods.com/' + str(modObj.game.domain_name) + '/mods/' + str(
                        modObj.nexus_id_mod) + '?tab=files'
                    tempo = 2
                    getFilesMods(link, modObj, tempo)
                    modObj.capturing_files_finalized = True

                    #modObj.save()
                    print "Files Salvos"
                # print link_abas
            elif (list[0].__eq__("Images") and quant > 0):
                if modObj.capturing_image_finalized == False:
                    getImages(soupContent, modObj, link_abas)
                    modObj.capturing_image_finalized = True
                    #modObj.save()
                    print "Imagens Salvas"
                # print link_abas
            elif (list[0].__eq__("Videos") and quant > 0):
                if(modObj.capturing_video_finalized == False):
                    getVideo(link_abas, soupContent, modObj)
                    modObj.capturing_video_finalized = True
                    #modObj.save()
                    print "Videos Salvas"
                # print link_abas
            elif (list[0].__eq__("Articles")and quant > 0):
                if  modObj.capturing_article_finalized == False:
                    getArticles(link_abas, modObj)
                    modObj.capturing_article_finalized = True
                    #modObj.save()
                    print "Videos Articles"
                # print link_abas
            elif (list[0].__eq__("Docs") and quant > 0):
                pass
            elif (list[0].__eq__("Posts") and quant > 0):
                if modObj.capturing_post_finalized == False:
                    li = soup.find('li', {'id': 'mod-page-tab-posts'})
                    link = li.find('a')['data-target']
                    getCommentPost('https://www.nexusmods.com' + link, idMod, modObj.url)
                    modObj.capturing_post_finalized = True
                    #modObj.save()
                    print "Post Salvos"
            elif (list[0].__eq__("Bugs") and quant > 0):
                if modObj.capturing_bug_finalized == False:
                    getBugs(link_abas, idMod,modObj.url)
                    modObj.capturing_bug_finalized = True
                    #modObj.save()
                    # print list[0]
                    print link_abas
            elif (list[0].__eq__("Logs")):
                if modObj.capturing_log_finalized == False:
                    link = 'https://www.nexusmods.com/'+str(modObj.game.domain_name)+'/mods/'+str(modObj.nexus_id_mod)+'?tab=logs'
                    getLogs(link,idMod, modObj.url)
                    modObj.capturing_log_finalized = True
                    #modObj.save()
                    print "Logs Salvos"
            elif (list[0].__eq__("Forum") and quant > 0):
                if modObj.capturing_forum_finalized == False:
                    link_abas = link2 + "Topics" + "Tab?id=" + str(idMod) + "&game_id=" + str(idgame)
                    getForum(link_abas, idMod, modObj.url)
                    modObj.capturing_forum_finalized = True
                    #modObj.save()
                    print "Forum Salvos"
                # print link_abas
            elif (list[0].__eq__("Stats")):
                if  modObj.capturing_statistic_finalized == False:
                    getStats(idgame, idMod, modObj.url)
                    modObj.capturing_statistic_finalized = True
                    #modObj.save()
                    print "Stats Salvos"
                    # print link_abas
            else:
                print "Nova Aba encontrada"
                print list[0]

        modObj.save()

    modObj.captura_mod_finalizada = True




#funções
def getGameId(soupContent):
    aux = soupContent.find_all("script")
    i = 0

    for aux2 in aux:
        if 'notifications_game_id' in aux2.text:
            m = re.findall(r'-?\d+\.?\d*', str(aux2))
            break
    return m[0]

def getModId(soupContent):
    id = soupContent.find("input", attrs={"id": "page-link"})
    m = re.findall(r'-?\d+\.?\d*', str(id))
    if m:
        valor = m[-1]
    return valor




