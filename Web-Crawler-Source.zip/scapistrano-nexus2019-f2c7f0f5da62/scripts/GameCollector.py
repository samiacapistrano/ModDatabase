#coding: utf-8

import atexit
import json
import re
import sys
import time
import traceback
import urllib2
import warnings

from bs4 import BeautifulSoup
from datetime import datetime
from django.db.models import Sum
from Logger import Logger
from ssl import SSLError

from scripts.function_util import formatDescribedDate
from scripts.function_util import getPagingNumber
from scripts.function_util import setDateTimeNow
from scripts.function_util import tranformationAmount
from scripts.function_util import tranformationOfComputerMeasureUnit

from manager.models import Game
from manager.models import Mod
from manager.models import ModBaseInformationCollectToGame
from manager.models import Modder

warnings.filterwarnings("ignore", category=RuntimeWarning)
logger = Logger()

class GameCollector:
    global datetime
    global logger
    global setDateTimeNow
    global time

    browser = None
    game = None
    mod_base_collect = None
    nexus_url = "https://www.nexusmods.com/"
    hdr = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 '
                + '(KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
    }

    all_games_count = 0
    collecting_games_count = 0
    finished_games_count = 0
    incomplete_games_count = 0
    progress_msg_len = 0

    collected_mods_count = None
    mods_to_collect = 0
    mods_to_collect_count = None
    number_of_pages = 0
    game_collected_mods_count = 0

    def __init__(self):
        global atexit
        atexit.register(self.exit)

    def exit(self):
        self.stop_game_collecting()
        logger.info("End of execution.")

    def stop_game_collecting(self):
        if self.mod_base_collect:
            self.mod_base_collect.getting_basic_information = False
            self.mod_base_collect.save()
        return

    def soup_collect(self, url):
        r = urllib2.Request(url, headers=self.hdr)
        web = urllib2.urlopen(r)
        return BeautifulSoup(web.read(), 'lxml')

    def collect_basic_info(self, log = False):
        try:
            start_time = time.time()
            print ""
            logger.info(" ---------------- Collecting Games Info ---------------- ")
            logger.info(" Requesting data from " + str(self.nexus_url) + " ...")

            soup = self.soup_collect(self.nexus_url)
            pattern = re.compile('var json = (.*?);')
            script = soup.find("script", text = pattern)

            logger.info(" Reading data ...")
            m = re.search('var json = (.+)[,;]{1}', str(script))

            if not m:
                logger.error("Json not found.")
                return

            found = m.group(1)
            jdata = json.loads(found)

            games_count = len(jdata)
            saved_count = 0
            count = 0

            for d in jdata:
                count += 1
                game = Game()
                game.begin_date = setDateTimeNow()

                for key, value in d.iteritems():
                    if (key=='approved_date'):
                        game.approved_date = datetime.fromtimestamp(value)
                    elif (key=='forum_url'):
                        game.forum_url = value
                    elif(key=='mods'):
                        game.amount_mods = value
                    elif(key=='name'):
                        game.name = value
                    elif(key=='downloads'):
                        game.amount_downloads = value
                    elif(key=='domain_name'):
                        game.domain_name = value
                    elif(key=='id'):
                        game.nexus_id = value
                    elif(key=='name_lower'):
                        game.name_lower = value
                    elif(key=='file_count'):
                        game.file_count = value
                    elif(key=='genre'):
                        game.genre = value
                    elif(key=='nexusmods_url'):
                        game.nexusmods_url = value
                    # print key, value

                game.finish_date = setDateTimeNow()

                db_game = Game.objects.filter(domain_name = game.domain_name)

                status = "saved"
                if not db_game:
                    saved_count += 1

                    mod_collect = ModBaseInformationCollectToGame()
                    mod_collect.capturing_mods_finalized = False
                    mod_collect.getting_basic_information = False
                    mod_collect.last_page_collected = 0
                    mod_collect.amount_mods_real = 0
                    mod_collect.number_of_pages = 0

                    game.save()
                    mod_collect.game = game
                    mod_collect.save()
                else:
                    status = "skipped"

                if log:
                    progress = round((100 * float(count) / float(games_count)), 0)
                    print "%.0f" % progress + "%  " + str(count) + "/" + str(games_count) + " - " + status + "Game: " + game.domain_name
                else:
                    status_count = "%3d" % count + "/" + "%3d" % games_count
                    progress = logger.get_progress_bar(count, games_count, 50, True, "Game's", status_count)
                    logger.print_inline(progress, self.progress_msg_len)
                    self.progress_msg_len = len(progress)

            print ""
            logger.info(" Collect time:%.0f sec(s)." % (time.time() - start_time))
            logger.info(" ----------- Collect finished. " + str(saved_count) + " Game's saved  ----------")

        except Exception as e:
            logger.error(str(e))
            traceback.print_exc()
        self.progress_msg_len = 0
        return

    def count_pages_and_mods(self): 

        logger.info(" ----------- Counting Game Pages and Mods ----------- ")
        try:
            self.all_games_count = self.count_all_games()
            start_time = time.time()

            while True:
                self.finished_games_count = self.count_complete_games()
                self.incomplete_games_count = self.all_games_count - self.finished_games_count

                collect_complete = self.finished_games_count == self.all_games_count
                if collect_complete:
                    print ""
                    logger.success("All Game's finished.")
                    break

                mod_base_collect = self.get_next_incomplete_game()
                if not mod_base_collect:
                    print ""
                    self.collecting_games_count = self.count_collecting_games()
                    logger.info("There are no game available to collect.")
                    logger.info("processing games: " + str(self.collecting_games_count)
                            + " waiting for completion...")
                    logger.wait_message("Next check in 15 seconds.", 15)
                    continue

                self.mod_base_collect = mod_base_collect[0]
                self.game = self.mod_base_collect.game
                if not self.game:
                    print ""
                    logger.error("The mod_base_collect with id:" + str(self.mod_base_collect.id)
                            + " doesn't have Game.")
                    break

                self.count_game_pages_and_mods(self.game)
            print ""
        except Exception as e:
            print ""
            self.stop_game_collecting()
            logger.error("count_pages_and_mods Exception: " + str(e))
            traceback.print_exc()

        logger.info("Collect time: %.0f second(s)." % (time.time() - start_time))
        logger.info(" ------------------ Collect finished ---------------- ")
        return

    def count_game_pages_and_mods(self, game):
        global getPagingNumber

        try:
            if self.mod_base_collect.getting_basic_information:
                logger.info("Game " + str(game.domain_name) + " already in processing.")
                return False

            if self.mod_base_collect.capturing_mods_finalized:
                logger.info("Game " + str(game.domain_name) + " already completed.")
                return False

            self.mod_base_collect.begin_date = game.begin_date = setDateTimeNow()
            self.mod_base_collect.getting_basic_information = True
            self.mod_base_collect.save()

            if not game.nexusmods_url:
                self.stop_game_collecting()
                logger.info("Game " + str(game.domain_name) + " without Url.")
                return False

            site = game.nexusmods_url + "/mods"
            soup = self.soup_collect(site)

            # Counting Mods
            mods_count = 0
            list_span = soup.find_all('span', {'class' :'refine-info'})
            for span in list_span:
                if span.text.startswith("Found"):
                    res = [int(i) for i in span.text.split() if i.isdigit()]
                    if res and len(res) > 0:
                        mods_count = res[0]
                break

            # Counting Pages
            pagination = None
            script = soup.find_all("script")
            if script:
                for aux2 in script:
                    if '"page"' in aux2.text:
                        pagination = getPagingNumber(aux2.string)
                        break
            pages_count = 0
            if pagination:
                pages_count = int(pagination[-1])

            self.mod_base_collect.amount_mods_real = mods_count
            self.mod_base_collect.number_of_pages = pages_count

            self.mod_base_collect.capturing_mods_finalized = True
            self.mod_base_collect.getting_basic_information = False
            self.mod_base_collect.finish_date = setDateTimeNow()
            self.mod_base_collect.save()
            self.finished_games_count += 1

            self.print_count_progress(game)
            return True

        except Exception as e:
            print ""
            self.stop_game_collecting()
            logger.error("count_game_pages_and_mods Exception: " + str(e))
            traceback.print_exc()

        return False

    def set_games_status_to_incomplete(self):
        try:
            all_games_complete = self.count_all_games() == self.count_complete_games()
            if not all_games_complete:
                logger.error("There are incomplete Games. Operation Canceled.")
                return

            ModBaseInformationCollectToGame.objects.update(
                capturing_mods_finalized = False
            )
            logger.success("Status changed to incomplete for all Games.")

        except Exception as e:
            print ""
            self.stop_game_collecting()
            logger.error("set_games_not_finalized Exception: " + str(e))
            traceback.print_exc()

    def collect_mods_info(self):
        logger.info(" ------------- Collecting Mods Info ------------- ")
        try:
            # Status
            self.mods_to_collect_count = self.sum_amount_mods_real()
            self.all_games_count = self.count_all_games()
            start_time = time.time()

            while True:
                self.finished_games_count = self.count_complete_games()
                self.incomplete_games_count = self.all_games_count - self.finished_games_count

                collect_complete = self.finished_games_count == self.all_games_count
                if collect_complete:
                    print ""
                    logger.success("All Game's finished.")
                    break

                mod_base_collect = self.get_next_incomplete_game()
                if not mod_base_collect:
                    print ""
                    self.collecting_games_count = self.count_collecting_games()
                    logger.info("There are no game available to collect.")
                    logger.info("processing games: " + str(self.collecting_games_count)
                            + " waiting for completion...")
                    logger.wait_message("Next check in 60 seconds.", 60)
                    continue

                self.mod_base_collect = mod_base_collect[0]
                self.game = self.mod_base_collect.game
                if not self.game:
                    print ""
                    logger.error("The mod_base_collect with id:" + str(self.mod_base_collect.id)
                            + " doesn't have Game.")
                    break
                self.collect_game_mods_info(self.game)
            print ""
        except Exception as e:
            print ""
            self.stop_game_collecting()
            logger.error("collect_mods_info Exception: " + str(e))
            traceback.print_exc()

        logger.info("Collect time: %.0f second(s)." % (time.time() - start_time))
        logger.info(" ------------------ Collect finished ---------------- ")
        return

    def collect_game_mods_info(self, game, game_id=None, start_page=None, end_page=None):
        global getPagingNumber
        global sys
        str_page = ""

        try:
            if game_id:
                self.game = self.get_game_by_id(game_id)
                self.mod_base_collect = ModBaseInformationCollectToGame.objects.get(id = game_id)

            elif game:
                self.game = game
            else:
                logger.error("Required Game or game_id parameter.")
                return
        except Exception as e:
            logger.error("Failed to process the game. " + str(e))
            traceback.print_exc()
            return False

        self.collected_mods_count = self.count_all_games_collected_mods()

        self.mods_to_collect_count = self.sum_amount_mods_real()

        if not self.all_games_count:
            self.all_games_count = self.count_all_games()

        try:
            if self.mod_base_collect.getting_basic_information:
                logger.info("Game " + str(self.game.domain_name) + " already in processing.")
                return False

            if self.mod_base_collect.capturing_mods_finalized:
                logger.info("Game " + str(self.game.domain_name) + " already completed.")
                return False

            if (self.mod_base_collect.number_of_pages == 0
                    or self.mod_base_collect.amount_mods_real == 0):
                logger.info("Game:" + str(self.game.domain_name) + " doesn't have Mods.")
                self.mod_base_collect.capturing_mods_finalized = True
                self.mod_base_collect.save()
                return True

            self.mod_base_collect.getting_basic_information = True
            self.mod_base_collect.save()

            self.game_collected_mods_count = self.count_game_collected_mods(self.game.id)
            self.number_of_pages = self.mod_base_collect.number_of_pages

            last_page_collected = self.mod_base_collect.last_page_collected
            # Start Page
            if start_page:
                if start_page >= 1 and start_page <= self.number_of_pages:
                    self.start_page = start_page
                else:
                    logger.error("Start_page out of range.")
                    return False
            else:
                if last_page_collected and last_page_collected > 1:
                    self.start_page = last_page_collected - 1
                else:
                    self.start_page = 1

            # End Page
            if end_page:
                if end_page >= self.start_page and end_page <= self.number_of_pages:
                    self.end_page = end_page
                else:
                    logger.error("End_page out of range.")
                    return False
            else:
                self.end_page = self.number_of_pages

            count_mods_saved = 0
            for page_index in range(self.start_page, self.end_page + 1):
                str_page = "Page: " + str(page_index)
                page_url = self.get_game_mods_page_url(self.game.nexus_id, page_index)

                # soup = self.soup_collect(page_url)

                page_content = self.get_page_content(page_url)
                if not page_content or len(page_content) == 0:
                    logger.error("\nErro ao acessar a página. ", page_url)
                    self.stop_game_collecting()
                    return

                soup = BeautifulSoup(page_content, 'lxml')

                ultag = soup.find('ul', {'class': 'tiles'})
                if not ultag:
                    print("")
                    logger.error("Failed to get ultags - " + str_page + ".")
                    self.stop_game_collecting()
                    return

                litags = ultag.find_all('li', {'class': 'mod-tile'})
                if not litags:
                    print("")
                    logger.error("Failed to get litags - " + str_page + ".")
                    self.stop_game_collecting()
                    return

                mod_position = 0
                for litag in litags:
                    mod_start_time = setDateTimeNow()
                    mod_position += 1
                    mod = self.get_mod_from_litag(litag)

                    if not mod:
                        print("")
                        logger.error("Failed to collect Mod information. Page:" 
                                + str(page_index) + " position:"  + str(mod_position)  + ".")
                        self.stop_game_collecting()
                        return

                    modder = self.get_modder_from_litag(litag)

                    active_modder = None
                    if modder:
                        modder_id = modder.id
                        active_modder = True
                    else:
                        modder_id = None
                        active_modder = False

                    mods = Mod.objects.filter(url=mod.url)
                    # Update Mod
                    if mods and len(mods) > 0:
                        mods[0].uploads_by_id = modder_id
                        mods[0].active_modder = active_modder
                        mods[0].save()

                    # Create Mod
                    else:
                        mod.game = self.game
                        mod.begin_date = mod_start_time
                        mod.uploads_by_id = modder_id
                        mod.active_modder = active_modder
                        self.save_mod(mod)

                        self.collected_mods_count += 1
                        self.game_collected_mods_count += 1
                        count_mods_saved += 1

                    # Status
                    if self.game_collected_mods_count % 250 == 0:
                        self.collected_mods_count = self.count_all_games_collected_mods()
                    self.print_mods_info_progress(page_index, count_mods_saved)

                last_page_collected = self.mod_base_collect.last_page_collected
                if (not last_page_collected) or (page_index > last_page_collected):
                    self.mod_base_collect.last_page_collected = page_index
                    self.mod_base_collect.save()

            # check if all pages were collected
            if page_index == self.number_of_pages:
                self.mod_base_collect.capturing_mods_finalized = True

            self.mod_base_collect.getting_basic_information = False
            self.mod_base_collect.save()

        except Exception as e:
            print("")
            logger.error("Failed to collect Mods of Game:" + str(self.game.domain_name) + " at Page" + str_page + ".")
            traceback.print_exc()
            self.stop_game_collecting()
            return
        print("")
        return

    def count_all_games(self):
        return Game.objects.count()

    def count_complete_games(self):
        return ModBaseInformationCollectToGame.objects.filter(
            capturing_mods_finalized = True,
            getting_basic_information = False,
        ).count()

    def get_next_incomplete_game(self):
        return ModBaseInformationCollectToGame.objects.filter(
            getting_basic_information = False,
            capturing_mods_finalized = False
        ).order_by('game_id')[:1]

    def count_collecting_games(self):
        return ModBaseInformationCollectToGame.objects.filter(
            getting_basic_information = True,
        ).count()

    def print_count_progress(self, game):

        status_count = "%3d" % self.finished_games_count + "/" + "%3d" % self.all_games_count
        progress = logger.get_progress_bar(
            self.finished_games_count, self.all_games_count, 30, True, "Count")
        status_msg = progress + status_count + " Game id: " + str(game.id) + "    "
        logger.print_inline(status_msg, self.progress_msg_len)
        self.progress_msg_len = len(status_msg)

    # TODO add parametro end_page
    def print_mods_info_progress(self, page_index, mods_saved):
        mods_count = "%3d" % self.collected_mods_count + "/" + "%3d" % self.mods_to_collect_count
        mods_progress = logger.get_progress_bar(
            self.collected_mods_count, self.mods_to_collect_count, 10, True, "Mods")

        games_count = "%3d" % self.game_collected_mods_count + "/" + "%3d" % self.mod_base_collect.amount_mods_real
        # game_progress = logger.get_progress_bar(
        #     self.game_collected_mods_count, self.mod_base_collect.amount_mods_real , 10, False, "Game")

        game_progress = logger.get_progress_bar(
            page_index, self.number_of_pages , 10, False, "Game")

        str_pages = "Page:" + str(page_index) + "/" + str(self.number_of_pages)

        status_msg = mods_progress + mods_count + "  Game id:" + str(self.game.id) + "  " + str_pages + "  Saved:" + str(mods_saved) + " " + game_progress + " " + games_count
        logger.print_inline(status_msg, self.progress_msg_len)
        self.progress_msg_len = len(status_msg)

    def get_game_by_id(self, game_id):
        return Game.objects.get(id = game_id)

    def get_game_mods_page_url(self, nexus_id, page):
        return (
            "https://www.nexusmods.com/Core/Libs/Common/Widgets/ModList?"
                    + "RH_ModList=nav:true,home:false,type:0,user_id:0,game_id:" + str(nexus_id)
                    + ",advfilt:true,include_adult:false,show_game_filter:false"
                    + ",page_size:20,page:" + str(page) + ",sort_by:date,order:ASC")

    def get_mod_from_litag(self, litag):
        global formatDescribedDate
        global tranformationAmount
        global tranformationOfComputerMeasureUnit

        mod = Mod()

        mod.name = litag.find('div', {'class': 'tile-content'}).h3.text
        mod.url = litag.find('a', {'class': 'mod-view'}, href=True, text=True)['href']

        mod.original_upload = formatDescribedDate(
            litag.find('div', {'class': 'meta clearfix'})
                    .find('time', {'class': 'date'}).text.replace("Uploaded: ", '').replace('\n', '')
        )

        mod.last_upload_date = formatDescribedDate(
            litag.find('div', {'class': 'date'}).text.replace("Last Update: ", '')
        )

        divcategory = litag.find('div', {'class': 'category'}).find('a', href=True)
        mod.url_nexus_category = divcategory['href']
        mod.nexus_category = divcategory.text

        # div_real_author = litag.find('div', {'class': 'realauthor'})
        # div_author = litag.find('div', {'class': 'author'})
        # a = div_author.find_all('a', href=True)
        # p = litag.find('p', {'class': 'desc'})

        uls = litag.find('div', {'class': 'tile-data'}).find('ul', {'class': 'clearfix'})
        span = uls.find('li', {'class': 'sizecount inline-flex'}).find('span', {'class': 'flex-label'})
        if span.text.strip(" ") == "--":
            mod.amount_files = 0
        else:
            mod.amount_files = tranformationOfComputerMeasureUnit(span.text)

        span = uls.find('li', {'class': 'endorsecount inline-flex'}).find('span', {'class': 'flex-label'})
        if span.text.strip(" ") == "--":
            mod.amount_endorsements = 0
        else:
            mod.amount_endorsements = tranformationAmount(span.text)

        span = uls.find('li', {'class': 'downloadcount inline-flex'}).find('span', {'class': 'flex-label'})
        if span.text.strip(" ") == "--":
            mod.amount_total_dls = 0
        else:
            mod.amount_total_dls = tranformationAmount(span.text)
        return mod

    def save_mod(self, mod):
        mod.capturing_basic_data_finalized = True
        mod.captura_mod_finalizada = False
        mod.capturing_statistic_finalized = False
        mod.capturing_forum_finalized = False
        mod.capturing_bug_finalized = False
        mod.capturing_post_finalized = False
        mod.capturing_article_finalized = False
        mod.capturing_video_finalized = False
        mod.capturing_image_finalized = False
        mod.capturing_files_finalized = False
        mod.capturing_log_finalized = False
        mod.mod_running = False
        mod.finished_execution = False
        mod.finish_date = setDateTimeNow()
        mod.capturing_amount_mod = False
        mod.save()
        return

    def count_all_games_collected_mods(self):
        global Mod
        # return Mod.objects.count()
        return Mod.objects.exclude(active_modder = None).count()

    def sum_amount_mods_real(self):
        global ModBaseInformationCollectToGame
        return int(ModBaseInformationCollectToGame.objects.aggregate(Sum('amount_mods_real')).get('amount_mods_real__sum'))

    def count_game_collected_mods(self, id):
        global Mod
        return Mod.objects.filter(game_id = id).count()

    def create_new_modder(self, author_name, author_url):
        modder = Modder()
        modder.name = author_name
        modder.url_perfil_modder = author_url

        # initialize values
        modder.real_name = ""
        modder.amount_endorsements = 0
        modder.amount_views = 0
        modder.country = ""
        modder.amount_topic = 0
        modder.amount_posts = 0
        modder.amount_kudos = 0
        modder.status = ""
        modder.modder_capture_finished = False

        modder.save()
        return modder

    def get_modder_from_litag(self, litag):
        # Author Url
        author_url = ""
        div_author = litag.find('div', {'class': 'author'})
        if div_author:
            a = div_author.find('a', href=True)
            if len(a) > 0 and a['href']:
                # Author Name
                author_name = ""
                div_real_author = litag.find('div', {'class': 'realauthor'})
                if div_real_author:
                    author_name = div_real_author.text

                author_url = a['href']
                stored_modder = Modder.objects.filter(url_perfil_modder = author_url)
                if not len(stored_modder) > 0:
                    modder = self.create_new_modder(author_name, author_url)
                else:
                    modder = stored_modder[0]

                return modder
        # print "None"
        return None

    def get_page_content(self, url):
        hdr = {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 '
                    + '(KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
        }

        attempts = 0
        content = None
        while True:
            attempts += 1
            try:
                r = urllib2.Request(url, headers=hdr)
                page = urllib2.urlopen(r, timeout=30)
                status = page.getcode()
                if status == 200:
                    content = page.read()
                    break
                else:
                    if attempts > 2:
                        logger.error("\nUrl Request Failed. Code:", status, ". Url:" + url)
                        break
                    continue
            except urllib2.HTTPError as e:
                if attempts > 2:
                    logger.error("\nHTTPError - Url:", url)
                    logger.error("{}".format(e.reason))
                    break
            except urllib2.URLError as e:
                if attempts > 2:
                    logger.error("\nURLError - Url:", url)
                    logger.error("{}".format(e.reason))
                    break
            except SSLError as e:
                if attempts > 2:
                    logger.error("\nSSLError - Url:", url)
                    logger.error("{}".format(e))
                    break
            except Exception as e:
                logger.error("\nget_page_content Exception ", type(e), " {}".format(e))
                traceback.print_exc()
                break
        return content