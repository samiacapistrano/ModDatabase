# -*- coding: utf-8 -*-
import bs4
from manager.models import Tag
from scripts.function_util import setDateTimeNow
listTags = []

def getTags(soup, modObj):
    # Informações de Tags do Mod
    tags = soup.find('ul', attrs={'class': 'tags'})

    listTags = []

    for tag in tags:
        if isinstance(tag, bs4.element.Tag):
            text4 = tag.text.strip("\n").split("\n")
            for tag1 in text4:
                if tag1 and tag1 != ' ':
                    if not Tag.objects.filter(name=tag1):
                        tagObj = Tag()
                        tagObj.begin_date = setDateTimeNow()
                        tagObj.name = tag1
                        tagObj.finish_date = setDateTimeNow()
                        tagObj.save()
                        #listTags.append(tagObj)
                        modObj.tag.add(tagObj)
                        #modObj.tag.add(tagObj)

                    else:
                        oldTag = Tag.objects.get(name=tag1)
                        listTags.append(oldTag)
                        modObj.tag.add(oldTag)
