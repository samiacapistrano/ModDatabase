#coding: utf-8

from scripts.constants import *

import time
from random import randint

from manager.models import AmountInfoMod
from manager.models import AuthorActivity
from manager.models import Bug
from manager.models import BugComment
from manager.models import CollectMod
from manager.models import CommentForum
from manager.models import Changelogs
from manager.models import File
from manager.models import Image
from manager.models import ListChange
from manager.models import Article
from manager.models import Mod
from manager.models import ModTabs
from manager.models import ModPageActivity
from manager.models import Video
from manager.models import Tag
from manager.models import TopicForum
from manager.models import Post

from django.db import connection, transaction
from django.db.models import Max
from django.db.models.query import RawQuerySet

class Dao:

    def get_next_incomplete_mod(self, collect_bugs):

        delay = float(randint(0, 500))/1000 + float(randint(0, 500))/1000
        time.sleep(delay)

        # sql = '''
        #     SELECT c.*
        #     FROM manager_collectmod as c
        #     WHERE finished = FALSE
        #         AND (error IS NULL or error is FALSE)
        #         AND (
        #             files_finalized = FALSE AND collecting_files = FALSE
        #             OR (images_finalized = FALSE AND collecting_images = FALSE)
        #             OR (videos_finalized = FALSE AND collecting_videos = FALSE)
        #             OR (articles_finalized = FALSE AND collecting_articles = FALSE)
        #             OR (forum_finalized = FALSE AND collecting_forum = FALSE)
        #             OR (posts_finalized = FALSE AND collecting_posts = FALSE)
        #             OR (bugs_finalized = FALSE AND collecting_bugs = FALSE)
        #             OR (logs_finalized = FALSE AND collecting_logs = FALSE)
        #             OR (statistics_finalized = FALSE AND collecting_statistics = FALSE)
        #         )
        #     ORDER BY collect_order
        #     LIMIT 1; '''

        condition = get_collect_condition(collect_bugs)
        if condition == "":
            return None

        sql = '''
                SELECT *
                FROM manager_collectmod
                WHERE
                    --finished = FALSE AND
                    error IS NOT TRUE
                    AND (
                        {cond}
                    )
                ORDER BY collect_order
                LIMIT {limit};'''.format(cond=condition, limit=str(COLLECTING_MODS_LIMIT))
        # print sql

        collect_mod = CollectMod.objects.raw(sql)[:]

        if collect_mod and len(collect_mod) > 0:

            if len(collect_mod) >= (COLLECTING_MODS_LIMIT-1):
                pos = randint(0, (COLLECTING_MODS_LIMIT-1))
            else:
                pos = randint(0, (len(collect_mod)-1))

            return collect_mod[pos]
        return None

    def count_complete_collect_mod(self):

        # sql = '''
        #     SELECT count(c.id_mod_id) as count
        #     FROM manager_collectmod as c
        #     WHERE (error IS NULL or error is FALSE)
        #         AND finished = FALSE
        #         AND (
        #             files_finalized
        #             AND images_finalized
        #             AND videos_finalized
        #             AND articles_finalized
        #             AND forum_finalized
        #             AND posts_finalized
        #             AND bugs_finalized
        #             AND logs_finalized
        #             AND statistics_finalized
        #         ); '''

        condition = get_collect_condition_count()
        if condition == "":
            return None

        sql = '''
        SELECT count(c.id_mod_id) as count
        FROM manager_collectmod as c
        WHERE
            (error IS NULL or error is FALSE)
            -- AND finished = FALSE
            AND (
                {cond}
            ); '''.format(cond=condition)

        cursor = connection.cursor()
        cursor.execute(sql)
        result = cursor.fetchone()
        return int(result[0])

    def get_image(self, imageObj):
        images = Image.objects.filter(
            # name = imageObj.name,
            # uploaded_date = imageObj.uploaded_date,
            # author = imageObj.author,
            # imagemUser = imageObj.imagemUser,
            mod_id = imageObj.mod_id,
            url = imageObj.url
        )
        if images or len(images) > 0:
            return images[0]
        return None

    def get_topic_forum(self, topic_url):
        topics = TopicForum.objects.filter(url = topic_url)
        if topics and len(topics) > 0:
            return topics[0]
        return None

    def get_comment(self, id):
        comments = CommentForum.objects.filter(comment_id = id)
        if comments and len(comments) > 0:
            return comments[0]
        return None

    def get_comment_post(self, id):
        db_comments = Post.objects.filter(comment_id = id)
        if db_comments and len(db_comments) > 0:
            return db_comments[0]
        return None

    def get_bug(self, id, id_mod):
        bugs = Bug.objects.filter(mod_id = id_mod, bug_id = id)
        if bugs and len(bugs) > 0:
            return bugs[0]
        return None

    def get_bug_comment(self, id, id_bug):
        comments = BugComment.objects.filter(bug_id = id_bug, bug_comment_id = id)
        if comments and len(comments) > 0:
            return comments[0]
        return None

    def count_all_mods_info(self):
        return AmountInfoMod.objects.count()

    def count_insert_mods(self):
        return CollectMod.objects.count()

    def count_mod_tabs(self):
        return ModTabs.objects.count()

    def get_max_collec_order(self):
        return CollectMod.objects.aggregate(Max('collect_order'))['collect_order__max']

    def get_max_order(self, number):
        sql = '''
        SELECT a.id_mod_id
        FROM manager_amountinfomod AS a
        JOIN manager_mod AS m ON m.id = a.id_mod_id
        LEFT JOIN manager_collectmod AS c ON c.id_mod_id = a.id_mod_id
        WHERE c.id_mod_id IS NULL
            AND m.error IS NOT TRUE
        ORDER BY
            a.amount_post DESC,
            a.amount_forum DESC,
            a.amount_bug DESC,
            m.original_upload ASC
        LIMIT ''' + str(number) + ';'

        cursor = connection.cursor()
        cursor.execute(sql)
        result = cursor.fetchall()

        if result and len(result) > 0:
            return result
        return None

    def get_mods_info(self, number):
        sql = '''
        SELECT a.*
        FROM manager_amountinfomod as a
        LEFT JOIN manager_modtabs as t on t.id_mod_id = a.id_mod_id
        WHERE t.id_mod_id is NULL
        ORDER BY a.id_mod_id
        LIMIT ''' + str(number) + ';'

        mods_info = AmountInfoMod.objects.raw(sql)[:]

        if mods_info and len(mods_info) > 0:
            return mods_info
        return None

    def count_all_mods(self):
        sql = '''
        SELECT count(*)
        FROM manager_mod AS m
        WHERE m.error IS NOT TRUE; '''

        cursor = connection.cursor()
        cursor.execute(sql)
        result = cursor.fetchone()
        return int(result[0])

    def count_all_mods_populate(self):
        sql = '''
        SELECT count(*)
        FROM manager_amountinfomod AS a
        JOIN manager_mod AS m ON m.id = a.id_mod_id
        WHERE m.error IS NOT TRUE; '''

        cursor = connection.cursor()
        cursor.execute(sql)
        result = cursor.fetchone()
        return int(result[0])

    def count_complete_mods(self):
        return CollectMod.objects.filter(finished = True).count()

    def count_collecting_mods(self):
        return CollectMod.objects.filter(collecting = True).count()

    def get_collect_mod_by_id(self, id):
        c_mods = CollectMod.objects.filter(id_mod_id = id)
        if c_mods and len(c_mods) > 0:
            return c_mods[0]
        return None

    def get_mod_by_id(self, mod_id):
        return Mod.objects.get(id = mod_id)

    def get_mod_url_by_id(self, id_mod):
        urls = Mod.objects.filter(id=id_mod).values('url')
        if urls and len(urls) > 0:
            return str(urls[0]['url'])
        return None

    def get_mod_tab_by_id(self, mod_id):
        return ModTabs.objects.get(id_mod_id = mod_id)

    def get_video(self, videoObj):
        videos = Video.objects.filter(
            # name = videoObj.name,
            # uploaded_date = videoObj.uploaded_date,
            # videosUser = videoObj.videosUser,
            mod_id = videoObj.mod_id,
            url = videoObj.url
        )
        if videos or len(videos) > 0:
            return videos[0]
        return None

    def get_article(self, articleObj):
        articles = Article.objects.filter(
            # name = articleObj.name,
            # uploaded_date = articleObj.uploaded_date,
            link_article = articleObj.link_article,
            mod_id = articleObj.mod_id,
            # link_author = articleObj.link_author,
            # author = articleObj.author
        )
        if articles or len(articles) > 0:
            return articles[0]
        return None

    def get_file(self, fileObjt):
        files = File.objects.filter(
            mod_id = fileObjt.mod_id,
            uploaded_date = fileObjt.uploaded_date,
            file_size = fileObjt.file_size,
            version = fileObjt.version,
            name = fileObjt.name,
            main_file = fileObjt.main_file,
            miscellauneous_file = fileObjt.miscellauneous_file,
            update_file = fileObjt.update_file,
            optional_file = fileObjt.optional_file,
            old_file = fileObjt.old_file
        )
        if files or len(files) > 0:
            return files[0]
        return None

    def get_changelog(self, changelogsObj):
        changelogs = Changelogs.objects.filter(
            mod_id = changelogsObj.mod_id,
            version = changelogsObj.version,
        )
        if changelogs or len(changelogs) > 0:
            return changelogs[0]
        return None

    def get_listchange(self, listchangeObj):
        listchange = ListChange.objects.filter(
            changelog_id = listchangeObj.changelog_id,
            change = listchangeObj.change,
        )
        if listchange or len(listchange) > 0:
            return listchange[0]
        return None

    def get_author_activity(self, authorActivityObj):
        activity = AuthorActivity.objects.filter(
            mod_id = authorActivityObj.mod_id,
            date = authorActivityObj.date,
            user = authorActivityObj.user,
            user_url = authorActivityObj.user_url,
            title = authorActivityObj.title,
            content = authorActivityObj.content,
        )
        if activity or len(activity) > 0:
            return activity[0]
        return None

    def get_mod_activity(self, modActivityObj):
        activity = ModPageActivity.objects.filter(
            mod_id = modActivityObj.mod_id,
            date = modActivityObj.date,
            user = modActivityObj.user,
            user_url = modActivityObj.user_url,
            title = modActivityObj.title,
            content = modActivityObj.content,
        )
        if activity or len(activity) > 0:
            return activity[0]
        return None

    def count_mod_posts(self, id):

        sql = '''
            SELECT count(id)
            FROM manager_post
            WHERE mod_id = ''' + str(id) + ";"

        cursor = connection.cursor()
        cursor.execute(sql)
        result = cursor.fetchone()
        return int(result[0])

    def count_mod_logs(self, id_mod):

        sql = '''
            SELECT sum(sub.count) FROM (
                SELECT count(*) FROM manager_changelogs WHERE mod_id = {id}
                UNION
                SELECT count(*) FROM manager_listchange WHERE changelog_id IN (
	                SELECT id FROM manager_changelogs WHERE mod_id = {id}
                )
                UNION
                SELECT count(*) FROM manager_authoractivity WHERE mod_id = {id}
                UNION
                SELECT count(*) FROM manager_modpageactivity WHERE mod_id = {id}
            ) as sub; '''.format(id=id_mod)

        cursor = connection.cursor()
        cursor.execute(sql)
        result = cursor.fetchone()
        return int(result[0])

    def count_mod_forum_topics(self, id_mod):

        sql = '''
                SELECT count(*) FROM manager_topicforum WHERE mod_id = {mod_id};
            '''.format(mod_id=id_mod)

        cursor = connection.cursor()
        cursor.execute(sql)
        result = cursor.fetchone()
        return int(result[0])

    def count_mod_forum_comments(self, id_mod):

        sql = '''
                SELECT count(*) FROM manager_commentforum WHERE topic_forum_id IN (
                    SELECT id FROM manager_topicforum WHERE mod_id = {mod_id}
                );
        '''.format(mod_id=id_mod)

        cursor = connection.cursor()
        cursor.execute(sql)
        result = cursor.fetchone()
        return int(result[0])

    def enable_collecting_tab(self, tab, mod_id):

        condition = get_collecting_tab(tab)

        sql = '''
            WITH updated_rows AS (
                UPDATE manager_collectmod
                SET {cond} = TRUE
                WHERE id_mod_id = {id_mod} AND {cond} = FALSE
                RETURNING finished || '_computed' AS a
            )
            SELECT count(*)
            FROM updated_rows;
        '''.format(cond=condition, id_mod=mod_id)

        cursor = connection.cursor()
        cursor.execute(sql)
        result = cursor.fetchone()
        if result and result[0] and result[0] != 0:
            return True
        return False