# -*- coding: utf-8 -*-
import os

import bs4
import requests
from bs4 import BeautifulSoup
import time
import urllib2

from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from scripts.function_util import formatDateTime
from scripts.function_util import formaDateMonthYears
from scripts.function_util import criarBrowser
from scripts.function_util import sendEmail
from scripts.function_util import setDateTimeNow

from manager.models import Modder

from scripts.function_util import addingSeleniumUser


def getModder(name, divs,hdr, browserPerfilUser):
    # URL do usuário
    urlDoModder = divs[3].a['href']

    if not Modder.objects.filter(name=name):

        modderObj = Modder()
        modderObj.begin_date = setDateTimeNow()


        response = requests.get(urlDoModder, headers=hdr)
        contentModder = response.text
        soupContentModder = BeautifulSoup(contentModder, 'lxml')

        nameMod = soupContentModder.findAll("div", attrs={'class': 'user-identity clearfix'})
        modderObj.name = nameMod[0].h1.text.encode('utf-8')

        dataModder = soupContentModder.findAll("ul", attrs={'class': 'stats clearfix'})

        for dtModder in dataModder[0]:
            if isinstance(dtModder, bs4.element.Tag):
                text = dtModder.text.strip("\n").split("\n")
                if (text[1].__eq__("Endorsements given")):
                    modderObj.amount_endorsements =int(str(text[2]).replace(",",""))
                elif(text[1].__eq__("Profile views")):
                    modderObj.amount_views =int(str(text[2]).replace(",",""))
                elif(text[1].__eq__("Topics")):
                    modderObj.amount_topic  =int(str(text[2]).replace(",",""))
                elif (text[1].__eq__("Posts")):
                    modderObj.amount_posts =int(str(text[2]).replace(",",""))
                elif (text[1].__eq__("Kudos")):
                    modderObj.amount_kudos =str(text[2]).replace(",","")
                else:
                    print "Dado desconhecido" + str(text[1])
#rever isso está um for desnecessario eu acho
        dataModderInfo = soupContentModder.find("div", {"id": "fileinfo"})
        for dtModder in dataModderInfo:
            if isinstance(dtModder, bs4.element.Tag):
                text = dtModder.text.strip("\n").split("\n")
                if "User information" in text:
                    #not in
                    pass
                else:
                    if (text[0].__eq__("Status")):
                        modderObj.status = str(text[1])
                    elif(text[0].__eq__("Real name")):
                        modderObj.real_name = text[1].encode('utf-8')
                    elif(text[0].__eq__("Last active")):
                        times = dtModder.findAll("time")
                        modderObj.last_active_date = formatDateTime(str(times[0]['datetime']))
                            #datetime.strptime(str(times[0]['datetime']), '%Y-%m-%d %H:%M')
                    elif (text[0].__eq__("Join date")):
                        times = dtModder.findAll("time")
                        modderObj.join_active_date = formatDateTime(str(times[0]['datetime']))
                        #datetime.strptime(str(times[0]['datetime']), '%Y-%m-%d %H:%M')
                    elif (text[0].__eq__("Country")):
                        if text[1].__eq__("Not specified"):
                            modderObj.country = text[1].encode('utf-8')
                        else:
                            modderObj.country = text[2].encode('utf-8')
                    else:
                        print "Dado desconhecido" + str(text[2])
        #modderObj.save()

        #TO DO Pegar amigos
        modTab = soupContentModder.find("ul", attrs={"class":"modtabs"})
        listsUserTable = modTab.find_all("li")
        #print listsUserTable
        for liUserTable in listsUserTable:
            text = liUserTable.text.strip("\n").split("\n")
            if (text[0].__eq__("User Files")):
                modderObj.amount_user_files = int(str(text[1]).replace(",",""))
            elif (text[0].__eq__("User Images")):
                modderObj.amount_user_images = int(str(text[1]).replace(",",""))
            elif (text[0].__eq__("User Videos")):
                modderObj.amount_user_videos = int(str(text[1]).replace(",",""))
            elif (text[0].__eq__("Friends")):
                modderObj.amount_friends = int(str(text[1]).replace(",",""))
            else:
                print "Dado desconhecido" + str(text)


        forumUrls = soupContentModder.find_all("a", attrs={'class': 'btn inline-flex'})

        for url in forumUrls:
            if isinstance(url, bs4.element.Tag):
                if str(url.text.strip()).__eq__("Forum Profile"):
                    forumUrl = url.get('href')
                    print forumUrl
                    break

        # teste
        #forumUrl = "https://forums.nexusmods.com/index.php?showuser=36620665"

        modderObj.url_perfil_modder = forumUrl
        browserPerfilUser.get(forumUrl)
        soup = BeautifulSoup(browserPerfilUser.page_source, 'html.parser')
        time.sleep(3)
        permissionLogin = soup.find('h1', attrs={'class': 'ipsType_pagetitle'})

        if str(permissionLogin.text.strip()).__eq__("Sorry, you don't have permission for that!"):
            msg = soup.find('p', attrs={'class': 'ipsType_sectiontitle'})
            if str(msg.text.strip()).__eq__("This member is no longer active."):

                link = soup.find('h1', attrs={'class': 'logged_in'})
                ul = link.find('ul',attrs={'class': 'ipsList_inline'})
                valueAs = ul.find_all("a")

                for a in valueAs:
                    if isinstance(a, bs4.element.Tag):
                        if str(a.text.strip()).__eq__("Sign Out"):
                            urlLogin = a.get('href')
                            print urlLogin
                            break
                browserPerfilUser = criarBrowser()
                browserPerfilUser.get(urlLogin)
                #browserPerfilUser.refresh()



            linkClick = browserPerfilUser.find_element_by_link_text('Sign In')
            #linkClick = browserPerfilUser.find_element_by_link_text('Click here to log in')

            if linkClick:
                linkClick.click()

                browserPerfilUser.find_element_by_id('user_login').send_keys('SCapistrano')
                #browserPerfilUser.find_element_by_id('form-username').send_keys('GameUFBA')

                browserPerfilUser.find_element_by_id('user_password').send_keys('Samia22121964')
                #browserPerfilUser.find_element_by_id('form-password').send_keys('ufba123456')

                try:

                    linkClickLogin = WebDriverWait(browserPerfilUser, 5).until(
                        EC.element_to_be_clickable((By.NAME, "commit")))
                except:
                    linkClickLogin = WebDriverWait(browserPerfilUser, 5).until(
                        EC.element_to_be_clickable((By.CLASS_NAME, "btn btn-primary")))
                linkClickLogin.click()

                login = None
                emailEnviado = False
                while login == None:
                    log = soup.find('div', attrs={'id': 'user_navigation'})
                    print log
                    soup = BeautifulSoup(browserPerfilUser.page_source, 'html.parser')
                    user =  soup.find('a', attrs={'id': 'user_link'})
                    if user:
                        break
                    
                    if not emailEnviado:
                        sendEmail('samia.capistrano@gmail.com','Logar no computador de Samia')
                        emailEnviado = True

                    time.sleep(5)
                    print "Não está logado"


                browserPerfilUser.get(forumUrl)
                soup = BeautifulSoup(browserPerfilUser.page_source, 'html.parser')

            else:
                browserPerfilUser.refresh()


        userProfile = soup.find_all("div", attrs={'class': 'general_box clearfix'})

        for profile in userProfile:
            lisProfile = profile.find_all("li", attrs={'class': 'clear clearfix'})
            for li in lisProfile:
                text = li.text.strip("\n").split("\n")
                if (text[0].__eq__("Group")):
                    #print "goup " + text[1]
                    if len(text) > 1:
                        modderObj.group = text[1]
                elif (text[0].__eq__("Active Posts")):
                    modderObj.amount_active_post = text[1].replace(',', '.')
                    #print "Active " + text[1].replace(',', '.')
                elif (text[0].__eq__("Profile Views")):
                    modderObj.amouny_profile_views = text[1]
                    #print "Views" + text[1]
                elif (text[0].__eq__("Member Title")):
                    #print "Member" + text[1]
                    modderObj.memberTitle = text[1]
                elif (text[0].__eq__("Age")):
                    #print "Age" + text[1]
                    if text[1].__eq__("Age Unknown"):
                        modderObj.age = None
                    else:
                        modderObj.age =  text[1]
                elif (text[0].__eq__("Birthday")):
                    if text[1].__eq__("Birthday Unknown"):
                        modderObj.birthday = modderObj.birthday = None
                    else:
                        data = str(text[1]).strip("\n").split(" ")
                        if len(data) == 2:
                            modderObj.birthday = modderObj.birthday = None
                        else:
                            modderObj.birthday = formaDateMonthYears(text[1])
                elif (text[0].__eq__("Gender")):
                    modderObj.genre = text[2]
                    #print "Gender" + text[2]
                elif (text[0].__eq__("Country")):
                    modderObj.country = text[2]
                    #print "Country" + text[2]
                elif (text[0].__eq__("Monitor Size")):
                    modderObj.monitorSize = text[2]
                    #print "Monitor Size" + text[2]
                elif (text[0].__eq__("Website URL")):
                    modderObj.websiteURL = text[2]
                    #print "Website URL" + text[2]
                elif (text[0].__eq__("Interests")):
                    modderObj.interests = text[2]
                    #print "Interests" + text[2]
                elif (text[0].__eq__("Currently Playing")):
                    modderObj.currentlyPlaying = text[2]
                    #print "Currently Playing" + text[2]
                elif (text[0].__eq__("Favourite Game")):
                    modderObj.favouriteGame = text[2]
                    #print "Favourite Game" + text[2]
                elif (text[0].__eq__("Processor")):
                    modderObj.processor = text[2]
                    #print "Processor" + text[2]
                elif (text[0].__eq__("Memory")):
                    modderObj.memory = text[2]
                    #print "Memory" + text[2]
                elif (text[0].__eq__("Motherboard")):
                    modderObj.motherboard = text[2]
                    #print "Motherboard" + text[2]
                elif (text[0].__eq__("Real Name")):
                    modderObj.realName = text[2]
                elif (text[0].__eq__("Graphics Card:")):
                    modderObj.graphicsCard = text[2]
                elif (text[0].__eq__("Location")):
                    modderObj.location = text[2]
                elif (text[0].__eq__("Processor")):
                    modderObj.processor = text[2]
                else:
                    print "Dado desconhecido " + str(text[0])

        # custom_fields__other
        modderObj.modder_capture_finished = True
        modderObj.finish_date = setDateTimeNow()
        modderObj.save()
        print "Modder Salvo"

    else:
        modderObj = Modder.objects.get(name=name)

    return modderObj

