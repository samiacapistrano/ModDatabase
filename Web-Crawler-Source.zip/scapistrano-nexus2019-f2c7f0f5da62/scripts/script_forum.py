#!/usr/bin/env python
# -*- coding: utf-8 -*-

from django.utils import timezone
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.expected_conditions import visibility_of
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
from datetime import datetime
from decimal import Decimal
import requests
import bs4
import django
import ast
from selenium import webdriver
import re
import os
import urllib2,cookielib
import time
import urllib2,cookielib
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import *

from django.conf import settings

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mysite.settings_samia")
django.setup()


import warnings
from manager.models import Mod, TopicForum, CommentForum
from scripts.function_util import addingSelenium
from scripts.function_util import getPagingNumber
from scripts.function_util import formatDescribedDate
from scripts.function_util import formateDateAM_PM
from  scripts.function_util import movePag
from function_util import setDateTimeNow
from datetime import  datetime


# os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mysite.settings_pamsn")



# site = "https://www.nexusmods.com/skyrim/mods/3863"
# site = "https://www.nexusmods.com/skyrim/mods/4929"
# hdr = { 'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
#         'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'}
# r = urllib2.Request(site, headers=hdr)
# try:
#     page = urllib2.urlopen(r) #web
# except urllib2.HTTPError, e:
#     print e.fp.read()
# content = page.read()
# #Criando uma instancia do beautifulSoup
# soup = BeautifulSoup(content, 'lxml')

#def getForum(link_abas):
def getForum(link_abas, idMod, modURL):

    global time

    #browser = addingSelenium("https://www.nexusmods.com/skyrim/mods/4929?tab=forum")
    browser = addingSelenium(link_abas)

    soup = BeautifulSoup(browser.page_source, 'html.parser')
    list = None
    datas = soup.find_all("script")
    for data in datas:
        if "$( function(){Filters_Pagination.Load(" in data.text:
            list = getPagingNumber(data.string)
            break

    forum_links = []
    if list:
        for page_index in list:
            if len(list) > 1 and not int(page_index) == 1:
                elemt = movePag(browser)
                try:
                    elemt[0].send_keys(page_index)
                    elemt[0].send_keys(Keys.ENTER)
                except:
                    browser.refresh()
                    elemt = movePag(browser)
                    elemt[0].send_keys(page_index)
                    elemt[0].send_keys(Keys.ENTER)

                time.sleep(3)

            soup = BeautifulSoup(browser.page_source, 'html.parser')
            table = soup.find('table', attrs={'id': 'mod_forum_topics'})
            if table:
                table_body = table.find('tbody')
                table_head = table.find('thead')

                topics_body = []

                if str(page_index) =='1':
                    topics_head = []
                    rows = table_head.find_all('tr')

                    for row in rows:
                        cols = row.find_all('td')
                        if (cols):
                            atags = row.find_all('a', {'class': 'go-to-topic'}, href=True, text=True)
                            td_replies = row.find_all('td', {'class': 'table-replies'})
                            td_table_views = row.find_all('td', {'class': 'table-views'})
                            td_table_author = row.find_all('td', {'class': 'table-author'}, href=True, text=True)
                            atags_table_author = row.find_all('a', {'class': 'table-link'}, href=True, text=True)
                            td_table_post = row.find_all('td', {'class': 'table-post'})
                            atags_table_posts = row.find_all('a', {'class': 'table-link'}, href=True, text=True)
                            if len(atags) != 0:
                                forum_links.append(atags[0]['href'])
                            cols = [ele.text.strip() for ele in cols]
                            topics_head.append([ele for ele in cols])
                            date = str(td_table_post[0].text).split(",")[0]
                            date = re.sub(r"^\s+", "", date, flags=re.UNICODE)
                            user = td_table_post[0].text.encode('utf-8').split(",")[1].encode('utf-8').split(" ")[2]
                            #user = str(str(td_table_post[0].text).split(",")[1]).split(" ")[2]
                            user = re.sub(r"\s+", "", user, flags=re.UNICODE)

                            topicForum = TopicForum()
                            topicForum.begin_date = setDateTimeNow()
                            topicForum.mod = Mod.objects.get(nexus_id_mod=idMod,url=modURL)
                            #topicForum.mod = Mod.objects.get(nexus_id_mod=4929)
                            topicForum.title = atags[0].text
                            # value_when_true if condition else value_when_false
                            topicForum.description = row.find('span', {'class': 'table-topic-sub'}, text=True).text if row.find('span', {
                                    'class': 'table-topic-sub'}, text=True) != None else " ".encode('utf-8')
                            topicForum.replies = int(td_replies[0].text.encode('utf-8').replace(",",""))
                            topicForum.views = int(td_table_views[0].text.encode('utf-8').replace(",",""))
                            topicForum.author = atags_table_author[0].text.encode('utf-8')
                            topicForum.author_url = atags_table_author[0]['href']
                            topicForum.last_post_date = str(formatDescribedDate(date))
                            topicForum.last_post_user_login = user.encode('utf-8')
                            topicForum.last_post_user_link = atags_table_posts[0]['href']
                            topicForum.last_post_user_name = atags_table_posts[0].text.encode('utf-8')
                            topicForum.finish_date = setDateTimeNow()
                            topicForum.save()

                            getCommentForum(atags[0]['href'], topicForum)

                            continue
                    # print forum_links
                # print len(forum_links)

                rows = table_body.find_all('tr')
                for row in rows:
                    cols = row.find_all('td')
                    atags = row.find_all('a', {'class': 'go-to-topic'}, href=True, text=True)
                    td_replies = row.find_all('td', {'class': 'table-replies'})
                    td_table_views = row.find_all('td', {'class': 'table-views'})
                    td_table_author = row.find_all('td', {'class': 'table-author'}, href=True, text=True)
                    atags_table_author = row.find_all('a', {'class': 'table-link'}, href=True, text=True)
                    td_table_post = row.find_all('td', {'class': 'table-post'})
                    atags_table_posts = row.find_all('a', {'class': 'table-link'}, href=True, text=True)
                    forum_links.append(atags[0]['href'])

                    cols = [ele.text.strip() for ele in cols]
                    topics_body.append([ele for ele in cols])
                    date = str(td_table_post[0].text).split(",")[0]
                    date = re.sub(r"^\s+", "", date, flags=re.UNICODE)
                    #print "Last Post: " + str(formatDescribedDate(date))
                    user = td_table_post[0].text.encode('utf-8').split(",")[1].encode('utf-8').split(" ")[2]
                    #user=str(str(td_table_post[0].text).split(",")[1]).split(" ")[2]
                    user = re.sub(r"\s+", "", user, flags=re.UNICODE)
                    topicForum = TopicForum()
                    topicForum.mod = Mod.objects.get(nexus_id_mod=idMod, url=modURL)
                    topicForum.title = atags[0].text
                    topicForum.description = row.find('span', {'class': 'table-topic-sub'}, text=True).text if row.find('span', {
                                    'class': 'table-topic-sub'}, text=True) != None else " ".encode('utf-8')
                    topicForum.replies = int(td_replies[0].text.encode('utf-8').replace(",", ""))
                    topicForum.views = int(td_table_views[0].text.encode('utf-8').replace(",", ""))
                    topicForum.author = atags_table_author[0].text.encode('utf-8')
                    topicForum.author_url = atags_table_author[0]['href']
                    topicForum.last_post_date = str(formatDescribedDate(date))
                    topicForum.last_post_user_login = user.encode('utf-8')
                    topicForum.last_post_user_link = atags_table_posts[0]['href']
                    topicForum.last_post_user_name = atags_table_posts[0].text.encode('utf-8')
                    topicForum.finish_date = setDateTimeNow()
                    topicForum.save()

                    getCommentForum(atags[0]['href'], topicForum)



    browser.close()

def getContent(li):
    dict = {}
    # print "Comments IDS: " + li['id']
    dict['id'] = li['id']
    divs_comment_head = li.find_all('div', {'class': 'comment-head clearfix'})
    for div in divs_comment_head:
        atags_comment_head = div.find_all('a', {'class': 'comment-user'})
        # HERF indicando o usuario que criou um topico no forum
        # print "Href " + atags_comment_head[0]['href']
        dict['href'] = atags_comment_head[0]['href']
        spans_comment_details = div.find_all('span', {'class': 'comment-name'})
        atag_comment_details = spans_comment_details[0].find_all('a')
        # HERF indicando o usuario que criou um topico no forum
        # print "HREF USER :" + atag_comment_details[0]['href']
        dict['hrefuser'] = atag_comment_details[0]['href']
        # print "USER :" + atag_comment_details[0].text
        dict['user'] = atag_comment_details[0].text
        uls = div.find_all(lambda tag: tag.name == 'ul' and tag.get('class') == ['clearfix'])
        #uls = div.find_all('ul', {'class': 'clearfix'})
        for ul in uls:
            lis = ul.find_all('li')
            if len(lis) != 0:
                # print "User Status: " + lis[0].text
                dict['userstatus'] = lis[0].text
                # print "Posts: " + lis[1].text
                dict['posts'] = lis[1].text
                # print "Kudos: " + lis[2].text
                dict['kudos'] = lis[2].text
        divs_comment_content = li.find_all('div', {'class': 'comment-content'})
        for div_comment in divs_comment_content:
            times = div_comment.find_all('time')
            for tim in times:
                atags = tim.find_all('a')
                for atag in atags:
                    # print "Data Hora: " + atag.text
                    dict['date'] = atag.text
                    comment = div_comment.find_all('div', {'class': 'comment-content-text'})
                    # print "Print comment: " + comment[0].text
                    dict['content'] = comment[0].text
    return dict

def getContentHead(li):
    dict = {}
    # print "Comments IDS: " + li['id']
    dict['id'] = li['id']
    divs_comment_head = li.find_all('div', {'class': 'comment-head clearfix'})
    for div in divs_comment_head:
        atags_comment_head = div.find_all('a', {'class': 'comment-user'})
        # HERF indicando o usuario que criou um topico no forum
        # print "Href " + atags_comment_head[0]['href']
        dict['href'] = atags_comment_head[0]['href']
        spans_comment_details = div.find_all('span', {'class': 'comment-name'})
        atag_comment_details = spans_comment_details[0].find_all('a')
        # HERF indicando o usuario que criou um topico no forum
        # print "HREF USER :" + atag_comment_details[0]['href']
        dict['hrefuser'] = atag_comment_details[0]['href']
        # print "USER :" + atag_comment_details[0].text
        dict['user'] = atag_comment_details[0].text
        uls = div.find_all(lambda tag: tag.name == 'ul' and tag.get('class') == ['clearfix'])
        #uls = div.find_all('ul', {'class': 'clearfix'})
        for ul in uls:
            lis = ul.find_all('li')
            if len(lis) != 0:
                # print "User Status: " + lis[0].text
                dict['userstatus'] = lis[0].text
                # print "Posts: " + lis[1].text
                dict['posts'] = lis[1].text
                # print "Kudos: " + lis[2].text
                dict['kudos'] = lis[2].text
        div_comment = li.find('div', {'class': 'comment-content'})
        times = div_comment.find_all('time')
        for tim in times:
            atags = tim.find_all('a')
            for atag in atags:
                # print "Data Hora: " + atag.text
                dict['date'] = atag.text
                comment = div_comment.find_all('div', {'class': 'comment-content-text'})
                # print "Print comment: " + comment[0].text
                dict['content'] = comment[0].text

        break
    return dict

def salveData(dict,topic_forum,pai,listSavedComments):

    if dict['id'].split('-')[1] in listSavedComments:
        pass
    else:
        comment = CommentForum()
        comment.begin_date = setDateTimeNow()
        comment.topic_forum = topic_forum
        # comment.reply = salveData(dict_reply,topic_forum,None) if dict_reply != None else None
        comment.reply = pai
        comment.comment_id = dict['id'].split('-')[1]
        comment.user_url = dict['hrefuser']
        comment.user_name = dict['user']
        comment.status= dict['userstatus']
        comment.posts=int(dict['posts'].split(" ")[0].encode('utf-8').replace(",",""))
        comment.kudos=int(dict['kudos'].split(" ")[0].encode('utf-8').replace(",",""))
        comment.content=dict['content']
        comment.date=formateDateAM_PM(dict['date'])
        comment.finish_date = setDateTimeNow()
        comment.save()

    # return comment



#getForum('https://www.nexusmods.com/skyrim/mods/4929/?tab=forum')


#link = 'https://www.nexusmods.com/skyrim/mods/4929/?tab=forum&topic_id=5713902'
#link = 'https://www.nexusmods.com/skyrim/mods/4929/?tab=forum&topic_id=512455'
# link = 'https://www.nexusmods.com/skyrim/mods/3863/?tab=forum&topic_id=499517'
# link = 'https://www.nexusmods.com/skyrim/mods/4929/?tab=forum&topic_id=512455'
# link = 'https://www.nexusmods.com/skyrim/mods/4929/?tab=forum&topic_id=7247481'
# link = 'https://www.nexusmods.com/skyrim/mods/4929/?tab=forum&topic_id=7041281'
# link ='https://www.nexusmods.com/skyrim/mods/4929/?tab=forum&topic_id=6802667'
# link = 'https://www.nexusmods.com/skyrim/mods/4929/?tab=forum&topic_id=7247481'
# link = 'https://www.nexusmods.com/skyrim/mods/4929/?tab=forum&topic_id=7148616'
# link = 'https://www.nexusmods.com/skyrim/mods/4929/?tab=forum&topic_id=6345656'
# link = 'https://www.nexusmods.com/skyrim/mods/4929/?tab=forum&topic_id=6675652'
# link = 'https://www.nexusmods.com/skyrim/mods/4929/?tab=forum&topic_id=7261161'
# link = 'https://www.nexusmods.com/skyrim/mods/4929/?tab=forum&topic_id=6748632'

def getCommentForum(link, topicForum):

    browser = addingSelenium(link)
    listSavedComments = []
    soup = BeautifulSoup(browser.page_source, 'html.parser')
    # ol = soup.find('ol')
    # list_comment = ol.find_all('li', {'class': 'comment'})
    # print "Numero TOTAL DE COMENTARIOS: " + str(len(list_comment))
    m = re.findall(r'-?\d+\.?\d*', str(link))
    idTopicForum =  m[0]

    topic_forum = topicForum
    salvos=[]
    list = []
    datas = soup.find_all("script")
    for data in datas:
        if "$( function(){Filters_Pagination.Load(" in data.text:
            list = getPagingNumber(data.string)
            break


    if not len(list):
        list.append(1)

    # salvos_paginacao = []
    for page_index in list:
        if len(page_index) > 1 and not int(page_index) == 1:
            elemt = movePag(browser)
            try:
                elemt[0].send_keys(page_index)
                elemt[0].send_keys(Keys.ENTER)
            except:
                elemt = movePag(browser)
                elemt[0].send_keys(page_index)
                elemt[0].send_keys(Keys.ENTER)
            time.sleep(2)
            soup = BeautifulSoup(browser.page_source, 'html.parser')
        else:
            time.sleep(1)
            soup = BeautifulSoup(browser.page_source, 'html.parser')

        ol = soup.find('ol')

        list_comment = ol.find_all('li', {'class': 'comment'})
        #print "Numero TOTAL DE COMENTARIOS: " + str(len(list_comment))

        #verificar se comentario tem resposta
        for li in list_comment:
            if li.find_all('ol', {'class': 'comment-kids'}): #primeiro nivel quando tem respostas
                # print li.get('id')
                # print "tem resposta: " + str(len(li.find_all('ol', {'class': 'comment-kids'})[0].find_all('li', {'class': 'comment'})))
                salveData(getContentHead(li), topic_forum, None,listSavedComments)
                # salvos.append(getContent(li)['id'].split("-")[1])
                respostas = li.find_all('ol', {'class': 'comment-kids'})[0].find_all('li', {'class': 'comment'})
                for li2 in respostas: #segundo nivel quando tem respostas
                    salveData(getContent(li2), topic_forum, getContent(li)['id'].split("-")[1],listSavedComments)
                    salvos.append(getContent(li2)['id'].split("-")[1])
                    # salvos_paginacao.append(getContent(li2)['id'].split("-")[1])
            else: #quando nao tem respostas
                # print li.get('id')
                # print "nao tem resposta"
                if getContent(li)['id'].split("-")[1] not in salvos : # and getContent(li)['id'].split("-")[1] not in salvos_paginacao:
                    salveData(getContent(li),topic_forum,None,listSavedComments)
                    # salvos.append(getContent(li)['id'].split("-")[1])
                # getContent(li)
                # print getContent(li)
    browser.close()

#link = 'https://www.nexusmods.com/Core/Libs/Common/Widgets/ModTopicsTab?id=4929&game_id=110'
#getForum(link)

#listUrlsCommentForum = Entry.objects.filter(pub_date__year=2006)
#getCommentForum('https://www.nexusmods.com/skyrim/mods/4929/?tab=forum&topic_id=512455')
#getCommentForum('https://www.nexusmods.com/skyrim/mods/4929/?tab=forum&topic_id=5713902')
#getContent(None)
