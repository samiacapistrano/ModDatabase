# -*- coding: utf-8 -*-
import time

from django.utils.datetime_safe import datetime
from selenium.webdriver.common.keys import Keys

from manager.models import Image
from bs4 import BeautifulSoup
from scripts.function_util import addingSelenium
from scripts.function_util import getPagingNumber
from manager.models import Mod
from scripts.function_util import setDateTimeNow

def getImages(soupContent,modObj,link_abas):
    browser = addingSelenium(link_abas)


    divImageAuthor = soupContent.find("div", attrs={'id': 'list-modimages-1'})
    divImageUser = soupContent.find("div", attrs={'id': 'list-modimages-2'})

    scriptAuthor = divImageAuthor.find_all("script")
    listPagAuthor = None
    if scriptAuthor:
        for aux2 in scriptAuthor:
            if '"page"' in aux2.text:
                listPagAuthor = getPagingNumber(aux2.string)
                break


    if listPagAuthor:
        imagemUser = False
        for page_index in range(1, int(listPagAuthor[-1].replace('\'', '')) + 1):
            if len(listPagAuthor) > 1 and page_index != 1:
                browser.refresh()
                browser.execute_script(
                    "return window.RH_ModImagesList1.Send('1page', '" + str(page_index) + "');")
                time.sleep(2)
                soupContent = BeautifulSoup(browser.page_source, 'lxml')

            listImages = soupContent.find("ul", attrs={'class': 'tiles tile-flex lg-mod-image-list'})
            images = listImages.find_all("li", attrs={'class': 'image-tile image-mod-page user-image-tile'})
            getDateImagem(modObj, images, imagemUser)

    scriptUser = divImageUser.find_all("script")
    listPagUser = None
    if scriptUser:
        for aux2 in scriptUser:
            if '"page"' in aux2.text:
                listPagUser = getPagingNumber(aux2.string)
                break

    if listPagUser:
        imagemUser = True
        for page_index in range(1, int(listPagUser[-1].replace('\'', '')) + 1):
            if len(listPagUser) > 1 and page_index != 1:
                browser.refresh()
                browser.execute_script(
                    "return window.RH_ModImagesList2.Send('2page', '" + str(page_index) + "');")
                time.sleep(2)
                #browser.refresh()
                soupContent = BeautifulSoup(browser.page_source, 'lxml')

            listImages = soupContent.find_all("ul", attrs={'class': 'tiles tile-flex lg-mod-image-list'})
            images = listImages[1].find_all("li",
                                            attrs={'class': 'image-tile image-mod-page user-image-tile'})

            getDateImagem(modObj, images, imagemUser)



    browser.close()

def getDateImagem(modObj, images, imagemUser):

    for listIm in images:
        imageObj = Image();
        imageObj.begin_date = setDateTimeNow()

        dataString = str(listIm.find("span", attrs={'class': 'upload-date'}).text).split("at ")
        data = dataString[1].strip().split(" ")

        data = datetime.strptime(str(data[3].strip()) + "/" + str(data[2].strip()) + "/"+ str(data[1].strip()) + " " + str(data[0]), '%Y/%b/%d %H:%M')

        imageObj.uploaded_date = data
        imageObj.name = listIm.h3.text.encode('utf-8')
        imageObj.author = listIm.find("div", attrs={'class': 'author'}).text.encode('utf-8')

        if not imagemUser:
            imageObj.imagemUser = False
        else:
            imageObj.imagemUser = True

        if Mod.objects.filter(name=modObj.name, url=modObj.url):
            #buscar somente o objeto
            #print modObj.name
            #print modObj.url
            modAux = Mod.objects.get(url=modObj.url)
            #modAux = Mod.objects.filter(url=modObj.url)
            #modQ = Mod.objects.filter(name=modObj.name)
            #modAux = modQ.exclude(url=modObj.url)[:1]

            #modAux = Mod.objects.get(name=modObj.name, url=modObj.url)[:1]
            imageObj.mod = modAux
        else:
            print "Erro ao associar Mod ao Arquivo"
        imageObj.finish_date = setDateTimeNow()
        imageObj.save()