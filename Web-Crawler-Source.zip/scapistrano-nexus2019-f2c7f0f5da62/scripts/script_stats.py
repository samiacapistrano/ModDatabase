
import json
import requests
from bs4 import BeautifulSoup

#./manage.py shell < scripts/script_stats.py --settings=mysite.settings_pamsn
# url = "https://staticstats.nexusmods.com/mod_monthly_stats/110/607.json"
# t = requests.get(url)
# newDictionary=json.dumps(t)
# print (newDictionary)

import requests
import urllib2
import re

import django
import os
import time
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mysite.settings_samia")
django.setup()

from manager.models import PageViews, Game, Mod, Downloads, Endorsements
from scripts.function_util import formatDate
from scripts.function_util import setDateTimeNow

#game_id = 110
#mod_id = 607

def getStats(game_id, mod_id, modURL):

    site = "https://staticstats.nexusmods.com/mod_monthly_stats/"+str(game_id)+"/"+str(mod_id)+".json"
    hdr = { 'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'}
    time.sleep(5)
    r = requests.get(site)
    soup = BeautifulSoup(r.content, 'html.parser') # lxml works faster than html.parser
    newDictionary=json.loads(str(soup))
    # print newDictionary['mod_page_views']
    if newDictionary:
        for key, value in newDictionary['mod_page_views'].iteritems():
            #print key
            #print newDictionary['last_updated']
            pageview = PageViews()
            pageview.begin_date = setDateTimeNow()
            pageview.game = Game.objects.get(nexus_id=game_id)
            pageview.mod = Mod.objects.get(nexus_id_mod=mod_id, url=modURL)
            pageview.date = key
            pageview.number_of_views = value
            pageview.last_update = newDictionary['last_updated']
            pageview.finish_date = setDateTimeNow()
            pageview.save()
        for key, value in newDictionary['mod_daily_counts'].iteritems():
            downloads = Downloads()
            downloads.begin_date = setDateTimeNow()
            downloads.game = Game.objects.get(nexus_id=game_id)
            downloads.mod = Mod.objects.get(nexus_id_mod=mod_id, url=modURL)
            downloads.date = key
            downloads.number_of_downloads = value
            downloads.last_update = newDictionary['last_updated']
            downloads.begin_date = setDateTimeNow()
            downloads.save()
    # print newDictionary['mod_daily_counts']
    # print newDictionary['total_downloads']
    # print newDictionary['last_updated']

    #TO DO
    site = modURL + "?tab=stats"
    #"https://www.nexusmods.com/skyrim/mods/607?tab=stats"
    r = urllib2.Request(site, headers=hdr)
    web = urllib2.urlopen(r)
    soup = BeautifulSoup(web.read(), 'lxml')

    pattern = re.compile('var endorsements = (.*?);')
    script = soup.find("script",text=pattern)
    m = re.search('var endorsements = (.+)[,;]{1}', str(script))
    if m:
        found = m.group(1)

    jdata = json.loads(found)
    # print jdata

    for value in jdata:

        endorsements = Endorsements()
        endorsements.begin_date = setDateTimeNow()
        endorsements.game = Game.objects.get(nexus_id=game_id)
        endorsements.mod = Mod.objects.get(nexus_id_mod=mod_id, url=modURL)
        endorsements.date = formatDate(value['year'])
        endorsements.number_of_endorsements = value['endorsements']
        endorsements.last_update = formatDate(str(newDictionary['last_updated']).split('T')[0])
        endorsements.finish_date = setDateTimeNow()
        endorsements.save()


