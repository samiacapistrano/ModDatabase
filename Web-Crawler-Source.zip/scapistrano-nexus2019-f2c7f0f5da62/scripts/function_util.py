# -*- coding: utf-8 -*-
import re
import sys 

from datetime import datetime
from django.conf import settings
from pytz import timezone
from selenium import webdriver

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

import time
import smtplib

# modulo com funções genericas
def getPagingNumber(script):
    mystring = script.replace('\n', ' ').replace('\r', '').replace(' ', '')
    m = re.search('\[.*?\]', mystring)
    if m:
        found = m.group(0)
    listPag = re.findall('(\'.*?\')', found)

    listFormated = []
    for list in listPag:
        list = list.replace('\'', '')
        if listFormated.count(list) < 1:
            listFormated.append(list)

    return listFormated

def getPagingNumber2(script):
    str_script = script.strip().replace('\n', '').replace('\r', '').replace('\t', '').replace(" ", "").replace("\'", "")
    pages = re.findall('(\{id\:.*?\})', str_script)
    if pages:
        last_page = pages[-1].encode('utf-8')
        pages = re.search('\{id\:(.*)\,text', last_page)
        if pages:
            return int(pages.group(1))
    return 0

def tranformationOfComputerMeasureUnit(dado):
    measureUnit = re.findall(r'[A-Z][A-Z]',dado)
    num = re.sub(r'[A-Z]','',dado).replace(",","")
    if (measureUnit[-1].__eq__("KB")):
        result = float(num) * 1024
    elif (measureUnit[-1].__eq__("MB")):
        result =  float(num) * (1024**2)
        #print result
    elif (measureUnit[-1].__eq__("GB")):
        result = float(num) * (1024**3)
    return result

def tranformationAmount(dado):
    amountUnit = re.findall(r'[A-Za-z]'
                            r'', dado)
    if len(amountUnit) > 0:
        amountUnit = amountUnit[-1].strip(" ")
        #print amountUnit[-1]
        #print "----"
        #print amountUnit[0]

    num = re.sub(r'[a-zA-Z]', '', dado)
    if len(amountUnit) >= 1:
        if (amountUnit[-1].__eq__("k") or amountUnit[-1].__eq__("K")):
            result = float(num) * 1000
        elif (amountUnit[-1].__eq__("m") or amountUnit[-1].__eq__("M")):
            result = float(num) * 1000000
            #2011-11-19 result
        elif (amountUnit[-1].__eq__("b") or amountUnit[-1].__eq__("B")):
            result = float(num) * 1000000000
    else:
        result = dado
    return result

def formatDescribedDate(date):
    #  25 Aug 2013
    date = str(date)
    date = date.strip()

    return (datetime.strptime(date, '%d %b %Y'))

def formatDate(date):
# 2008-12-08
    date = str(date)
    return (datetime.strptime(date, '%Y-%m-%d'))

def formatDateTime(date):
    # 2013-02-04 10:44
    date = str(date)
    return (datetime.strptime(date, '%Y-%m-%d %H:%M'))

def formatDescribeMonth(date):
#16 oct 2013, 11:13AM
    date = str(date)
    return (datetime.strptime(date, '%d %b %Y, %I:%M%p').strftime('%Y-%m-%d'))

def addingSelenium(link_abas):
    baseDir = getattr(settings, 'CHROMEDRIVE')
    browser = webdriver.Chrome(baseDir)
    browser.get(link_abas)
    
    return browser

def addingSeleniumUser (link_abas, browser):
    baseDir = getattr(settings, 'CHROMEDRIVE')
    browser = webdriver.Chrome(baseDir)
    browser.get(link_abas)

    return browser

def criarBrowser():
    baseDir = getattr(settings, 'CHROMEDRIVE')
    browser = webdriver.Chrome(baseDir)
    return browser

def formatDescribedDateMonth(date):
# 20 August 2013
    date = str(date)
    date = date.strip()

    return (datetime.strptime(date, '%d %B %Y'))


def formaDateMonthYears(date):
# August 16, 2014
    date = str(date)
    date = date.strip()

    return (datetime.strptime(date, '%B %d, %Y'))

def formaDateMonth(date):
# August 16
    date = str(date)
    date = date.strip()

    return (datetime.strptime(date, '%B %d'))


def formateDateAM_PM(date):
# 06 November 2015, 7:26AM
    date = str(date)
    date = date.strip()
    return (datetime.strptime(date, '%d %B %Y, %M:%S%p'))

def formateDateM_AM_PM(date):
#07 Nov 2018, 9:30PM
    date = str(date)
    date = date.strip()
    return (datetime.strptime(date, '%d %b %Y, %M:%S%p'))

def movePag(browser):
    linkClick = None
    try:
        time.sleep(1)
        linkClick = WebDriverWait(browser, 4).until(
            EC.element_to_be_clickable((By.ID, "select2-page_t-container")))
        time.sleep(1)
        linkClick.click()
    except:
        try:
            linkClick = WebDriverWait(browser, 4).until(
                EC.element_to_be_clickable((By.ID, "select2-page_t-container")))
            time.sleep(1)
            linkClick.click()
        except:
            pass

    try:
        elemt = browser.find_elements_by_class_name('select2-search__field')
    except:
        elemt = browser.find_elements_by_class_name('select2-search__field')
    return elemt

def sendEmail(email, msg):
    # samia.capistrano@gmail.com
    try:
        msgFrom = 'samia.capistrano@gmail.com'
        smtpObj = smtplib.SMTP('smtp.gmail.com', 587)
        smtpObj.ehlo()
        smtpObj.starttls()
        msgTo = email
        toPass = 'as10222421'
        smtpObj.login(msgTo, toPass)
        msg = msg
        smtpObj.sendmail(msgTo, msgFrom, 'Subject: Verificar Script \n{}'.format(msg))
        smtpObj.quit()
        print("Email enviado com sucesso!")
    except:
        print("Erro ao enviar e-mail")
    pass

def setDateTimeNow():
   return datetime.now()

def getBrowser(no_images = False):
    baseDir = getattr(settings, 'CHROMEDRIVE')
    options = webdriver.ChromeOptions()
    options.add_argument("disable-infobars")

    if no_images:
        prefs = {'profile.managed_default_content_settings.images':2}
        options.add_experimental_option("prefs", prefs)

    return webdriver.Chrome(chrome_options=options, executable_path=baseDir)

def getHeadlessBrowser():
    baseDir = getattr(settings, 'CHROMEDRIVE')
    options = webdriver.ChromeOptions()
    options.add_argument("headless")
    # options.add_argument("window-size=1200x600")
    options.add_argument("--disable-infobars")
    options.add_argument("--disable-extensions")
    options.add_argument("--log-level=3")
    options.add_argument("--silent")
    options.add_argument("--proxy-server='direct://'")
    options.add_argument("--proxy-bypass-list=*")
    options.add_argument("--blink-settings=imagesEnabled=false")

    prefs = {'profile.managed_default_content_settings.images':2}
    options.add_experimental_option("prefs", prefs)
    return webdriver.Chrome(chrome_options=options, executable_path=baseDir)