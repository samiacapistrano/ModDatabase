# -*- coding: utf-8 -*-
import atexit
import os
import re
import subprocess
import time
import urllib2
import sys

import django
from bs4 import BeautifulSoup
from django.conf import settings
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

import warnings
warnings.filterwarnings("ignore", category=RuntimeWarning) 

reload(sys)
sys.setdefaultencoding('utf-8')

#./manage.py shell < scripts/selenium_pagination_mods_info.py --settings=mysite.settings_pamsn
#./manage.py shell < scripts/selenium_pagination_mods_info.py --settings=mysite.settings_samia


#from progressbar import ProgressBar
from manager.models import Mod
from manager.models import Game
from scripts.function_util import getPagingNumber
from scripts.function_util import formatDate
from scripts.function_util import tranformationOfComputerMeasureUnit
from scripts.function_util import criarBrowser
from scripts.function_util import formatDescribedDate
from scripts.function_util import tranformationAmount
#from scripts.script_get_mods_info import allDataMod
from scripts.function_util import addingSelenium
from selenium.webdriver.common.keys import Keys

from subprocess import call
from selenium.common.exceptions import TimeoutException
from function_util import setDateTimeNow

# PAGE_LOAD_TIMEOUT = 15

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mysite.settings_samia")
django.setup()

gameRunning = None

# Atualiza flag que sinaliza que o Game está em processamento ao parar a execução do script.
def quit():
    global gameRunning
    if gameRunning != None:
        gameRunning.getting_basic_information = False
        gameRunning.save()
    print 'INFO -> Saindo...'

atexit.register(quit)

def getBasicInformationModIniti(url, pagStart, gameCont):

    listGame = Game.objects.all()

    for game in listGame:

        quantMod = len(Mod.objects.filter(game=game.id))
        time.sleep(3)
        #if game.capturing_mods_finalized != True or quantMod != len(Mod.objects.filter(game=game.id)):
        #para teste
        if game.capturing_mods_finalized != True or quantMod == len(Mod.objects.filter(game=game.id)):
            if url == None:
                site = game.nexusmods_url + "/mods"
            else:
                site = url
                url = None

            hdr = {
                'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'}

            r = urllib2.Request(site, headers=hdr)
            web = urllib2.urlopen(r)
            soup = BeautifulSoup(web.read(), 'lxml')

            script = soup.find_all("script")
            if script:
                for aux2 in script:
                    if '"page"' in aux2.text:
                        pagination = getPagingNumber(aux2.string)
                        break
            browser = addingSelenium(site)

            if pagStart == None:
                pagStart = 1

            for page_index in range(pagStart, int(pagination[-1]) + 1):

                if len(pagination) > 5:
                    next = WebDriverWait(browser, 10).until(
                        EC.element_to_be_clickable((By.CLASS_NAME, "icon-arrow-thin")))
                    browser.execute_script("return window.RH_ModList.Send('page', '" + str(page_index) + "');", next)
                    try:
                        wait = WebDriverWait(browser, 4)
                        element = wait.until(EC.visibility_of_element_located((By.CLASS_NAME, 'flex')))
                        teste = wait.until(EC.invisibility_of_element_located((By.CLASS_NAME, 'flex')))
                    except TimeoutException:
                        try:
                            wait = WebDriverWait(browser, 4)
                            element = wait.until(EC.visibility_of_element_located((By.CLASS_NAME, 'flex')))
                            teste = wait.until(EC.invisibility_of_element_located((By.CLASS_NAME, 'flex')))
                        except TimeoutException:
                            browser.refresh()

                    except Exception as e:
                        print "Generico"

                    soup = BeautifulSoup(browser.page_source, 'lxml')

                elif len(pagination) == 2 | len(pagination) == 3 | len(pagination) == 4:
                    linkClick = browser.find_element_by_id('select2-page_t-container')
                    linkClick.click()
                    elemt = browser.find_elements_by_class_name('select2-search__field')
                    elemt[2].send_keys(page_index)
                    elemt[2].send_keys(Keys.ENTER)

                    try:
                        wait = WebDriverWait(browser, 3)
                        element = wait.until(EC.visibility_of_element_located((By.CLASS_NAME, 'flex')))
                        teste = wait.until(EC.invisibility_of_element_located((By.CLASS_NAME, 'flex')))
                    except TimeoutException:
                        print('Error getting remote ADC value > Timeout reading remote ADC')
                    except Exception as e:
                        print "Generico"

                    soup = BeautifulSoup(browser.page_source, 'lxml')

                try:
                    ultag = soup.find('ul', {'class': 'tiles'})
                    litags = ultag.find_all('li', {'class': 'mod-tile'})
                except:
                    browser.refresh()
                    time.sleep(2)
                    soup = BeautifulSoup(browser.page_source, 'lxml')
                    ultag = soup.find('ul', {'class': 'tiles'})
                    litags = ultag.find_all('li', {'class': 'mod-tile'})

                if ultag:
                    pass
                else:
                    print "deu ruim"
                    print len(litags)
                    print litags[0]



                for litag in litags:
                    #print litag

                    modObj = Mod()
                    modObj.game = game
                    modObjtDataBase = Mod()

                    if toCompareObjMod(litag, modObj, modObjtDataBase) == True:

                        if modObjtDataBase:
                            if modObjtDataBase.capturing_basic_data_finalized != True:
                                modObjtDataBase.delete()
                                savebasicInfomationMod(litag, modObj)
                                #print 'pag' + str(page_index)
                    else:
                        savebasicInfomationMod(litag, modObj)
                        #print 'pag' + str(page_index)


            browser.close()


    game.capturing_mods_finalized = True
    game.save()

# get the next non complete Game 
def getNextGame():
    return Game.objects.filter(
        getting_basic_information=False,
        capturing_mods_finalized=False,
    ).order_by('id')[0]

def getGameCollectedMods(id):
    return Mod.objects.filter(game_id=id).count()

def getGameUrlByDomainName(domainName):
    game = getGameByDomainName(domainName)
    if game:
        return game.nexusmods_url
    else:
        return None;

def getGameByDomainName(domainName):
    return Game.objects.get(domain_name=domainName)

def getBasicInformationModIniti2(domainName, pagStart, url):
    global gameRunning
    global PAGE_LOAD_TIMEOUT

    if domainName == None:
        game = getNextGame()
        if not game:
            print "ERROR -> Falha na função:getNextGame()."
            return
    else:
        try:
            game = getGameByDomainName(domainName)
            if game:
                if game.getting_basic_information:
                    print "\nINFO -> Game:" + game.domain_name + " já está em processamento."
                    return
                if game.capturing_mods_finalized:
                    print "\nINFO -> Game:" + domainName + " já foi concluido."
                    return
            else:
                print "\nERROR -> Falha ao consultar o Game:",domainName
                return
        except:
            print "\nERROR -> Falha ao processar o Game:",domainName
            return

    game_mods = game.amount_mods
    if game_mods == 0:
        print "\nINFO -> Game:" + game.domain_name + " não possui Mod's."
        game.capturing_mods_finalized = True
        game.save()
        return

    # Persistindo no banco que a coleta para o Game está em execução 
    game.getting_basic_information = True
    game.save()
    
    if domainName == None:
        site = game.nexusmods_url
    elif url != None:
        site = url
    else:
        site = getGameUrlByDomainName(game.domain_name)
        if site == None:
            print "ERROR -> Falha ao consultar a Url do Game:",game.domain_name
            return
    site += "/mods"

    # collected_mods = getGameCollectedMods(game.id)

    if not pagStart:
        # Inicia a coleta apartir da última página coletada - 5
        if game.last_page_collected:
            pagStart = game.last_page_collected
            if pagStart > 5:
                pagStart -= 5
            else:
                pagStart = 1
        elif pagStart == None:
            pagStart = 1

    try:
        gameRunning = game
        statusMsgLen = 0
        countMods = getGameCollectedMods(game.id)
        print "\nINFO -> Iniciando a coleta de dados - Id:",game.id," Game:",game.domain_name," Start_Pag:",pagStart

        hdr = {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
        }
        
        r = urllib2.Request(site, headers=hdr)
        web = urllib2.urlopen(r)
        soup = BeautifulSoup(web.read(), 'lxml')

        script = soup.find_all("script")
        if script:
            for aux2 in script:
                if '"page"' in aux2.text:
                    pagination = getPagingNumber(aux2.string)
                    break
        
        browser = addingSelenium(site)

        # Wait and check if page is Ready
        # pageReady = waitUntilPageIsReady(browser, PAGE_LOAD_TIMEOUT)
        # if not pageReady:
        #     browser.refresh()
        #     pageReady = waitUntilPageIsReady(browser, PAGE_LOAD_TIMEOUT)    
        # if not pageReady:
        #     print "ERROR -> Timeout-1 ao carregar a página - Id:",game.id," Game:",game.domain_name
        #     game.getting_basic_information = False
        #     game.save()
        #     return
        
        #  Verify if pagination exists
        pagElement = browser.find_elements_by_class_name('pagination')
        if not pagElement or not len(pagElement) > 0:
            print "INFO -> Game:" + game.domain_name + " não possui Mod's."
            game.capturing_mods_finalized = True
            game.getting_basic_information = False
            game.save()
            return
        
        lastPage = int(pagination[-1]) + 1
        
        for page_index in range(pagStart, lastPage):
            if len(pagination) > 5:
                next = WebDriverWait(browser, 10).until(
                    EC.element_to_be_clickable((By.CLASS_NAME, "icon-arrow-thin")))
                browser.execute_script("return window.RH_ModList.Send('page', '" + str(page_index) + "');", next)
                try:
                    wait = WebDriverWait(browser, 4)
                    element = wait.until(EC.visibility_of_element_located((By.CLASS_NAME, 'flex')))
                    teste = wait.until(EC.invisibility_of_element_located((By.CLASS_NAME, 'flex')))
                except TimeoutException:
                    try:
                        wait = WebDriverWait(browser, 4)
                        element = wait.until(EC.visibility_of_element_located((By.CLASS_NAME, 'flex')))
                        teste = wait.until(EC.invisibility_of_element_located((By.CLASS_NAME, 'flex')))
                    except TimeoutException:
                        browser.refresh()
                        # recarregar ao fazer o jump rodar linhas 


                        # Wait and check if page is Ready
                        # pageReady = waitUntilPageIsReady(browser, PAGE_LOAD_TIMEOUT)
                        # if not pageReady:
                        #     browser.refresh()
                        #     pageReady = waitUntilPageIsReady(browser, PAGE_LOAD_TIMEOUT)    
                        # if not pageReady:
                        #     print "ERROR -> Timeout-2 ao recarregar a página - Id:",game.id," Game:",game.domain_name
                        #     game.getting_basic_information = False
                        #     game.save()
                        #     return

                except Exception as e:
                    print "Generico"

                soup = BeautifulSoup(browser.page_source, 'lxml')

            elif len(pagination) == 2 | len(pagination) == 3 | len(pagination) == 4:
                linkClick = browser.find_element_by_id('select2-page_t-container')
                linkClick.click()
                elemt = browser.find_elements_by_class_name('select2-search__field')
                elemt[2].send_keys(page_index)
                elemt[2].send_keys(Keys.ENTER)

                try:
                    wait = WebDriverWait(browser, 3)
                    element = wait.until(EC.visibility_of_element_located((By.CLASS_NAME, 'flex')))
                    teste = wait.until(EC.invisibility_of_element_located((By.CLASS_NAME, 'flex')))
                except TimeoutException:
                    print('Error getting remote ADC value > Timeout reading remote ADC')
                except Exception as e:
                    print "Generico"

                soup = BeautifulSoup(browser.page_source, 'lxml')

            try:
                ultag = soup.find('ul', {'class': 'tiles'})
                litags = ultag.find_all('li', {'class': 'mod-tile'})
            except:
                browser.refresh()
                
                # time.sleep(2)
                # Wait and check if page is Ready for 15 seconds
                # pageReady = waitUntilPageIsReady(browser, PAGE_LOAD_TIMEOUT)
                # if not pageReady:
                #     browser.refresh()
                #     pageReady = waitUntilPageIsReady(browser, PAGE_LOAD_TIMEOUT)    
                # if not pageReady:
                #     print "ERROR -> Timeout-3 ao recarregar a página - Id:",game.id," Game:",game.domain_name
                #     game.getting_basic_information = False
                #     game.save()
                #     return

                soup = BeautifulSoup(browser.page_source, 'lxml')
                ultag = soup.find('ul', {'class': 'tiles'})
                litags = ultag.find_all('li', {'class': 'mod-tile'})

            if ultag:
                pass
            else:
                print "deu ruim"
                print len(litags)
                print litags[0]


            for litag in litags:
                #print litag
                modObj = Mod()
                modObj.game = game
                modObjtDataBase = Mod()

                if toCompareObjMod(litag, modObj, modObjtDataBase) == True:

                    if modObjtDataBase:
                        if modObjtDataBase.capturing_basic_data_finalized != True:
                            modObjtDataBase.delete()
                            savebasicInfomationMod(litag, modObj)
                            countMods += 1
                            #print 'pag' + str(page_index)
                else:
                    savebasicInfomationMod(litag, modObj)
                    #print 'pag' + str(page_index)
                    countMods += 1
            
                # Status 
                sys.stdout.flush()
                sys.stdout.write((b'\x08' * statusMsgLen).decode())
                statusPercent = 100 * float(page_index)/float(lastPage-1)
                statusMsg = str(round(statusPercent, 2)) + '% Mods:' + str(countMods) + ' '
                statusMsgLen = len(statusMsg)
                sys.stdout.write(statusMsg)

            game.last_page_collected = page_index
            game.save()

        browser.quit()

        game.getting_basic_information = False
        game.capturing_mods_finalized = True
        game.save()
        print "\nINFO -> Coleta de dados Finalizada - Id:",game.id," Game:",game.domain_name," Mods:",countMods

    except Exception as e:
        print "ERROR -> Falha ao coletar dados - Id:",game.id," Game:",game.domain_name,". Exception:",str(e)
        game.getting_basic_information = False
        game.save()

def allModsCollected():
    return Game.objects.filter(capturing_mods_finalized=False, getting_basic_information=False).count() == 0

def toCompareObjMod(litag, modObj, modObjtDataBase):

    divtags = litag.find('div', {'class': 'tile-content'})
    modName = divtags.h3.text
    modObj.name = modName

    atags = litag.find('a', {'class': 'mod-view'}, href=True, text=True)
    modObj.url = atags['href']

    div_meta_cleanfix = litag.find('div', {'class': 'meta clearfix'})
    times = div_meta_cleanfix.find('time', {'class': 'date'})
    originaldateMod = formatDescribedDate(
        times.text.replace("Uploaded: ", '').replace('\n', ''))
    modObj.original_upload = originaldateMod

    div_date = litag.find('div', {'class': 'date'})
    lastUpdate = formatDescribedDate(div_date.text.replace("Last Update: ", ''))
    modObj.last_upload_date = lastUpdate


    if Mod.objects.filter(name=modObj.name, game = modObj.game, url=modObj.url):
        modObjtDataBase1 = Mod.objects.get(name=modObj.name, game = modObj.game, url=modObj.url)

        modObjtDataBase.capturing_basic_data_finalized = modObjtDataBase1.capturing_basic_data_finalized
        modObjtDataBase.id = modObjtDataBase1.id
        modObjtDataBase.game_id = modObjtDataBase1.game_id

        if modObjtDataBase1:
            if modObjtDataBase1.original_upload.replace(tzinfo=None) == modObj.original_upload and modObjtDataBase1.last_upload_date.replace(tzinfo=None) == modObj.last_upload_date:
                return True
    else:
        return False

def savebasicInfomationMod(litag, modObj):

    atags = litag.find('a', {'class': 'mod-view'}, href=True, text=True)
    #print atags[0]['href']

    modObj.url = atags['href']
    #listtUrlsMod.append(atags[0]['href'])

    divcategory = litag.find('div', {'class': 'category'})
    #print divcategory
    a = divcategory.find('a', href=True)
    modObj.url_nexus_category = a['href']
    modObj.nexus_category = a.text

    div_meta_cleanfix = litag.find('div', {'class': 'meta clearfix'})
    times = div_meta_cleanfix.find('time', {'class': 'date'})
    modObj.original_upload = formatDescribedDate(times.text.replace("Uploaded: ", '').replace('\n', ''))

    div_date = litag.find('div', {'class': 'date'})
    modObj.last_upload_date = formatDescribedDate(div_date.text.replace("Last Update: ", ''))

    div_real_author = litag.find('div', {'class': 'realauthor'})
    div_author = litag.find('div', {'class': 'author'})
    a = div_author.find_all('a', href=True)
    p = litag.find('p', {'class': 'desc'})
    div_tile_data = litag.find('div', {'class': 'tile-data'})
    uls = div_tile_data.find('ul', {'class': 'clearfix'})

    li = uls.find('li', {'class': 'sizecount inline-flex'})
    span = li.find('span', {'class': 'flex-label'})
    if span.text.strip(" ") == "--":
        modObj.amount_files = 0
    else:
        modObj.amount_files = tranformationOfComputerMeasureUnit(span.text)

    li = uls.find('li', {'class': 'endorsecount inline-flex'})
    span = li.find('span', {'class': 'flex-label'})

    if span.text.strip(" ") == "--":
        modObj.amount_endorsements = 0
    else:
        modObj.amount_endorsements = tranformationAmount(span.text)

    li = uls.find('li', {'class': 'downloadcount inline-flex'})
    span = li.find('span', {'class': 'flex-label'})
    if span.text.strip(" ") == "--":
        modObj.amount_total_dls = 0
    else:
        modObj.amount_total_dls = tranformationAmount(span.text)

    modObj.capturing_basic_data_finalized = True
    modObj.captura_mod_finalizada = False
    modObj.capturing_statistic_finalized = False
    modObj.capturing_forum_finalized = False
    modObj.capturing_bug_finalized = False
    modObj.capturing_post_finalized = False
    modObj.capturing_article_finalized = False
    modObj.capturing_video_finalized = False
    modObj.capturing_image_finalized = False
    modObj.capturing_files_finalized = False
    modObj.capturing_log_finalized = False
    modObj.mod_running = False
    modObj.finished_execution = False

    #print modObj.name

    modObj.save()

    # print modObj.name.encode('utf-8') + " " + "Informações básicas salvas "

def waitUntilPageIsReady(browser, timeout):
    end_time = time.time() + timeout
    documentReady = False
    while (time.time() < end_time) and (documentReady == False):
        # Check if document is ready
        documentReady = browser.execute_script("return document.readyState != 'loading';")
        if documentReady:
            return True

        # wait for 50 miliseconds
        time.sleep(0.05)
    return False

