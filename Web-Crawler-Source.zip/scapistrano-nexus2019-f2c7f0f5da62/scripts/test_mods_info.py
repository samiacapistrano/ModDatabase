# -*- coding: utf-8 -*-
import django
import time

from scripts.ModInfoCollector2 import ModInfoCollector

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mysite.settings_samia")

django.setup()

# ------  RUN  --------
# ./manage.py shell < scripts/test_mods_info.py --settings=mysite.settings_samia

# 1 - COLETA GAME's INFO
# execfile('./scripts/script_get_games_info.py')

# 2 - COLETA MOD's INFO
collector = ModInfoCollector()
# collector.collect_mods_info()

# print "\n------------------------ With IMGs -----------------------------" 
# start = time.time()
# collector.collect_game_mods_info(None, 213, 1, False)
# print "Execution Time:%.2f" % (time.time() - start)

# print "\n---------------------- Without IMGs ----------------------------" 
# start = time.time()

collector.collect_mods_info()
# collector.collect_game_mods_info(None, 4, 1, 10, True)
# collector.collect_game_mods_info(None, 10, 8, None, True)
# collector.collect_game_mods_info(None, 212, 1, None, True)
# collector.collect_game_mods_info(None, 4, 1, None, True)
# collector.collect_game_mods_info(None, 816, 1, None, True)

# print "\nExecution Time:%.2f" % (time.time() - start)
