# https://www.nexusmods.com/skyrim/mods/3863?tab=articles
# https://www.nexusmods.com/Core/Libs/Common/Widgets/ModArticlesTab?id=3863&game_id=607
# -*- coding: utf-8 -*-
from bs4 import BeautifulSoup
import os
import django
import urllib2

#os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mysite.settings_pamsn")
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mysite.settings_samia")
django.setup()

from scripts.function_util import getPagingNumber
from scripts.function_util import addingSelenium
from scripts.function_util import formatDateTime
from manager.models import Mod, Article
from function_util import setDateTimeNow
import time




#def getArticles(link_abas,soupContent,modObj):
def getArticles(link_abas, modObj):
    #teste
    # https://www.nexusmods.com/skyrim/mods/19733?tab=articles
    #link_abas = "https://www.nexusmods.com/Core/Libs/Common/Widgets/ModArticlesTab?id=3863&game_id=110"

    browser = addingSelenium(link_abas)
    soup = BeautifulSoup(browser.page_source, 'html.parser')

    #modObj = Mod()


    # divVideos1 = soupContentModder.find("div", attrs={'id': 'list-modvideos-1'})
    # divVideos2 = soupContentModder.find("div", attrs={'id': 'list-modvideos-2'})

    # pagination Author Imagens
    datas = soup.find_all("script")
    for data in datas:
        if "$( function(){Filters_Pagination.Load(" in data.text:
            list = getPagingNumber(data.string)
            break


    for page_index in list:

        if len(list) > 1:
            browser.execute_script(
                "return window.RH_ModArticlesTab.Send('1page', '" + str(page_index) + "');")
            time.sleep(5)
            soup = BeautifulSoup(browser.page_source, 'lxml')

        ulArticles = soup.find('ul', attrs={'id':'mod-article-list'})
        liArticles = ulArticles.find_all('li', attrs={'class':'article-tile'})
        for article in liArticles:
            articleObj = Article()
            articleObj.begin_date = setDateTimeNow()

            title = article.find('div', {"class","tile-content"})
            articleObj.name = title.h3.text
            #print title.h3.text

            link = title.find('a', href=True)
            articleObj.link_article = link['href']

            date = article.find('time', {'class','date'})
            articleObj.uploaded_date = formatDateTime(date['datetime'])
            #print date['datetime']

            author = article.find('div', {'class', 'author'})
            #print author.text
            articleObj.author = author.text

            linkAuthor = author.find_all('a',href=True)
            articleObj.link_author = linkAuthor[0]['href']
            #print linkAuthor[0]['href']

            articleObj.description = article.find('p',{'class','desc'}).text
            #print article.find('p',{'class','desc'}).text

            articleObj.amoutComentarios = article.find('span',{'class','flex-label'}).text
            #print article.find('span',{'class','flex-label'}).text

            articleObj.mod = modObj
            #Mod.objects.get(nexus_id_mod=607)
            articleObj.finish_date = setDateTimeNow()
            articleObj.save()


