#coding: utf-8

from __future__ import print_function

import atexit
import django
import os
import sys
import time
import traceback
import urllib2
import warnings

from bs4 import BeautifulSoup
from datetime import datetime
from django.conf import settings
from django.db.models import Sum
from os import system, name
from pytz import timezone

from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains

from scripts.function_util import formatDescribedDate
from scripts.function_util import getBrowser
from scripts.function_util import getPagingNumber
from scripts.function_util import tranformationAmount
from scripts.function_util import tranformationOfComputerMeasureUnit
from scripts.function_util import movePag

from manager.models import Game
from manager.models import Mod

warnings.filterwarnings("ignore", category=RuntimeWarning)

class bcolors:
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'

class ModInfoCollector:

    DETAIL_STATUS = False
    LOADING_ATTEMPTS = 3
    LOADING_TIMEOUT = 60
    MODS_PER_PAGE = 20
    ORDER_PAGE_ATTEMPTS = 0
    TESTING = False
    TIME_FORMATTER = '%d/%m/%Y %H:%M:%S'

    browser = None
    game = None
    game_start_time = None
    games_collecting_count = None
    games_count = 0
    incomplete_games_count = None
    not_games_collecting = None
    not_games_incomplete = None
    start_page = None
    start_time = None
    statusMsgLen = 0

    def __init__(self):
        global django
        global atexit
        global time
        os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mysite.settings_samia")
        django.setup()
        atexit.register(self.exit)
        self.spinner = self.spinning_cursor()
        self.games_count = self.get_games_count()

    def collect_mods_info(self):
        try:
            self.start_time = time.time()
            print("")
            self.log_info("------------------------------------ Iniciando Coleta - Mod's -----------------------------------")
            complete = self.collect_mods_complete()
            if complete:
                self.log_success("Todos os Game's estão concluídos.")

            self.games_to_process_count = self.get_incomplete_games_count() # 50
            self.games_processed_count = 0 # 1

            while not self.collect_mods_complete():
                if self.not_games_incomplete:
                    if self.not_games_collecting:
                        self.log_success("Todos os Game's estão concluídos.")
                        return
                    else:
                        self.log_info("Nao ha Game's disponíveis para coleta.")
                        self.log_info("Game's em processamento:" + str(self.games_collecting_count) + " aguardando conclusão...")
                        self.waiting_message('Nova verificacao em:', 60)
                else:
                    game = self.get_next_game()
                    if game is not None:
                        self.collect_game_mods_info(game, None, None, None, True)

                        # status
                        self.games_processed_count += 1
                        incomplete_games_count = self.get_incomplete_games_count() #48
                        diff = self.games_to_process_count - incomplete_games_count
                        if diff > 0:
                            self.games_to_process_count = self.games_processed_count + incomplete_games_count + diff
                            self.games_processed_count += diff

            self.log_info("Tempo total:%.0f segundo(s)." % (time.time() - self.start_time))
            self.log_info("----------------------------------- Coleta de Mod's finalizada ----------------------------------")
            return

        except Exception as e:
            if (not self.TESTING) and (self.game is not None):
                self.exit_on_error()
            self.log_error("collect_mods_info exception:" + str(e))
            traceback.print_exc()
            return

    def collect_game_mods_info(self, game, game_id, start_page, end_page, no_images):
        global urllib2
        global BeautifulSoup
        global getPagingNumber
        global getBrowser
        global WebDriverWait
        global EC
        global TimeoutException
        global By
        global Keys
        str_page = ""

        try:
            if game_id:
                game = self.get_game_by_id(game_id)
                if not game:
                    self.log_error("Falha ao consultar o Game - id:" + str(game_id) + ".")
                    return
                else:
                    self.game = game
            elif not game:
                self.log_error("Parâmetro Game ou game_id necessário.")
                return
            else:
                # Atualiza Game
                self.game = Game.objects.get(id = game.id)
        except Exception as e:
            self.log_error("Falha ao processar o Game." + str(e))
            traceback.print_exc()
            return

        try:
            if not self.TESTING:
                if self.game.getting_basic_information:
                    self.log_info("Game:" + str(self.game.domain_name) + " já está em processamento.")
                    return

            if self.game.capturing_mods_finalized:
                self.log_info("Game:" + str(self.game.domain_name) + " já foi concluído.")
                return

            if self.game.amount_mods == 0:
                self.log_info("Game:" + str(self.game.domain_name) + " não possui Mod's.")
                self.game.capturing_mods_finalized = True
                self.game.save()
                return

            self.count_all_amount_mods = self.count_all_games_amount_mods()
            self.count_all_collected_mods = self.count_all_games_collected_mods()

            self.game_start_time = time.time()

            # Persistindo no banco que a coleta para o Game esta em execucao 
            if not self.TESTING:
                self.game.getting_basic_information = True
                self.game.save()

            # Game URL
            site = self.game.nexusmods_url + "/mods"

            countMods = self.count_game_collected_mods(self.game.id)
            # self.collect_mods_complete()

            soup = self.soap_collect(site)
            pagination = self.get_pagination(soup)

            if not pagination:
                self.log_info("O Game:" + str(self.game.domain_name) + " não possui Mod's.")
                self.game.capturing_mods_finalized = True
                self.game.save()
                self.exit_on_error()
                return
            pages = int(pagination[-1])

            # Start Page
            if start_page is None:
                # Inicia a coleta apartir da ultima pagina coletada - 1
                if self.game.last_page_collected and self.game.last_page_collected > 1:
                    self.start_page = self.game.last_page_collected - 1
                else:
                    self.start_page = 1
            else:
                if start_page <= pages:
                    self.start_page = start_page
                else:
                    # TODO exibir mensagem de erro
                    self.start_page = pages

            # End Page
            if not end_page:
                self.end_page = pages
            else:
                if end_page <= pages:
                    self.end_page = end_page
                else:
                    # TODO exibir mensagem de erro
                    self.end_page = pages

            # print("DEBUG: PAGINAS:",self.start_page," a ",self.end_page," de ",pages)

            self.get_url(site, True, pages)
            if pages > 1:
                if not self.order_pages_by_date():
                    self.log_error(" Falha ao ordenar os Mod's por data - Game " + str(game.id) + ':' + str(game.domain_name))
                    self.exit_on_error()
                    self.ORDER_PAGE_ATTEMPTS = 0
                    return

            count_progress_len = 0
            mods_progress_len = 0
            game_progress_len = 0
            statusMsg2Len = 0

            count_mods_test = 0
            count_mods_error = 0
            count_mods_saved = 0
            count_pages = 0

            for page_index in range(self.start_page, self.end_page + 1):

                str_page = "Página:" + str(page_index)

                count_pages += 1
                if count_pages > 100:
                    count_pages = 0
                    self.browser.refresh()

                if not self.page_is_ready():
                    self.log_error(" Falha ao carregar a página. - Game " + str(game.id) + ':' + str(game.domain_name))
                    return False

                self.wait_site_loading(site)

                # Skip loading again the first Page
                if page_index != 1:
                    if self.order_is_endorsements():
                        if not self.order_pages_by_date():
                            self.log_error(" Falha ao ordenar os Mod's por data - Game " + str(game.id) + ':' + str(game.domain_name))
                            self.exit_on_error()
                            self.ORDER_PAGE_ATTEMPTS = 0
                            return
                    if not self.go_to_page(page_index, pages):
                        return False
                self.remove_ads()

                #  TODO remover após testes
                # Pagination loading
                # loaded = self.wait_page_loading(page_index)
                # if not loaded:
                #     attempts = 0
                #     while attempts < self.LOADING_ATTEMPTS and not loaded:
                #         attempts += 1
                #         self.browser.refresh()
                #         loaded = self.wait_page_loading(page_index)

                # if not loaded:
                #     print("")
                #     self.log_error("4 - Falha ao carregar paginação - " + str_page + " " + str(site) + ".")
                #     self.exit_on_error()
                #     return

                # Mods loading
                if page_index != pages:
                    mods_count = self.MODS_PER_PAGE
                else:
                    mods_count = 1
                loaded = self.wait_loading_mods(mods_count)
                if not loaded:
                    attempts = 0
                    while attempts < self.LOADING_ATTEMPTS and not loaded:
                        attempts += 1
                        self.browser.refresh()
                        loaded = self.wait_loading_mods(mods_count)
                if not loaded:
                    print("")
                    self.log_error("5 - Falha ao carregar mods - " + str_page + " " + str(site) + ".")
                    self.exit_on_error()
                    return

                soup = BeautifulSoup(self.browser.page_source, 'lxml')
                ultag = soup.find('ul', {'class': 'tiles'})
                if not ultag:
                    print("")
                    self.log_error("Falha ao obter ultags - " + str_page + " " + str(site) + ".")
                    self.exit_on_error()
                    return

                litags = ultag.find_all('li', {'class': 'mod-tile'})
                if not litags:
                    print("")
                    self.log_error("Falha ao obter litags - " + str_page + " " + str(site) + ".")
                    self.exit_on_error()
                    return

                mod_position = 0
                for litag in litags:
                    mod_position += 1
                    mod = self.get_mod_from_litag(litag)
                    if(mod):
                        # TODO: ecapsular em função
                        count_mods_test += 1
                        mod.game = self.game
                        mods = Mod.objects.filter(url=mod.url)
                        if not mods:
                            mod.capturing_basic_data_finalized = True
                            mod.captura_mod_finalizada = False
                            mod.capturing_statistic_finalized = False
                            mod.capturing_forum_finalized = False
                            mod.capturing_bug_finalized = False
                            mod.capturing_post_finalized = False
                            mod.capturing_article_finalized = False
                            mod.capturing_video_finalized = False
                            mod.capturing_image_finalized = False
                            mod.capturing_files_finalized = False
                            mod.capturing_log_finalized = False
                            mod.mod_running = False
                            mod.finished_execution = False
                            mod.save()
                            self.count_all_collected_mods += 1
                            count_mods_saved += 1
                            countMods += 1

                        # Status
                        # games_count_progress = round(100 * float(self.games_processed_count) / float(self.games_to_process_count))
                        mods_progress = round(100 * float(self.count_all_collected_mods) / float(self.count_all_amount_mods))
                        game_progress = round(100 * float(page_index) / float(pages))
                        if self.DETAIL_STATUS:
                            self.clear()
                            print("-"*26 + "INFO" + "-"*26)
                            print("Games em Processamento:",self.games_collecting_count)
                            print("Games Pendentes:",self.incomplete_games_count,"\n")
                            self.print_progressBar(mods_progress, 100,"", "All Mods", 30, mods_progress_len)

                            print("\n")
                            print("-"*26 + "GAME" + "-"*26)
                            print("\nProcessando:",self.game.domain_name,"  id:",self.game.id)
                            print("Mods Coletados:",countMods,"  Total:",game.amount_mods ,"  New Mods:",count_mods_saved)
                            print("Pagina:",page_index," a ",self.end_page," de ",pages,"\n")

                            self.print_progressBar(game_progress, 100, "", "", 30, game_progress_len)
                            print("")
                            print("-"*26 + "----" + "-"*26)
                        else:
                            sys.stdout.flush()
                            sys.stdout.write((b'\x08' * statusMsg2Len).decode())
                            # count_progress = self.get_progress_bar(games_count_progress, 100, "", "", 10, count_progress_len)
                            game_progress = self.get_progress_bar(game_progress, 100, "", "", 10, game_progress_len)
                            mods_progress = self.get_progress_bar(mods_progress, 100, "", "", 10, mods_progress_len)
                            time_stamp = self.get_time_str(self.TIME_FORMATTER)

                            # statusMsg = time_stamp + " Game's" + count_progress + "  Page:" + str(page_index) + "/" + str(pages) + "  Mods:" + str(countMods) + "/" + str(game.amount_mods) + "  New:" + str(count_mods_saved) + "  " + game_progress
                            statusMsg = time_stamp + " Mod's" + mods_progress + "  Page:" + str(page_index) + "/" + str(pages) + "  Mods:" + str(countMods) + "/" + str(game.amount_mods) + "  New:" + str(count_mods_saved) + "  " + game_progress
                            statusMsg2Len = len(statusMsg)
                            sys.stdout.write(statusMsg)
                    else:
                        print("")
                        self.log_error("Falha ao coletar informações do Mod. Página:" + str(page_index) + " posição:"  + str(mod_position))
                        count_mods_error += 1
                        self.exit_on_error()
                        return

                if (not self.game.last_page_collected) or (page_index > self.game.last_page_collected):
                    if not self.TESTING:
                        self.game.last_page_collected = page_index
                        self.game.save()

        except Exception as e:
            print("")
            self.log_error("Erro ao coletar dados do Game:" + str(self.game.domain_name) + str_page + ".")
            traceback.print_exc()
            self.exit_on_error()
            return

        if self.game:
            print("")
        if self.browser:
            self.browser.quit()

        if not self.TESTING:
            # Coletou até a ultima página
            if page_index == pages:
                self.game.capturing_mods_finalized = True

            self.game.getting_basic_information = False
            self.game.save()

        if not self.DETAIL_STATUS:
            str_tempo = "  Tempo:%.0f segudo(s)" % (time.time() - self.game_start_time)
            msg = "Coleta finalizada - Game:" + str(self.game.domain_name) + "  Mods:" + str(countMods) + str_tempo + "\n"
            self.log_success(msg)
        return

    def get_incomplete_games(self):
        return Game.objects.filter(
            capturing_mods_finalized = False,
            getting_basic_information = False
        ).order_by('id')

    def collect_mods_complete(self):
        self.games_collecting_count = self.get_games_collecting_count()
        self.incomplete_games_count = self.get_incomplete_games_count()
        self.not_games_collecting = self.games_collecting_count == 0
        self.not_games_incomplete = self.incomplete_games_count == 0
        return self.not_games_collecting and self.not_games_incomplete

    def get_incomplete_games_count(self):
        global Game
        return Game.objects.filter(
            capturing_mods_finalized = False,
            getting_basic_information = False
        ).count()

    def get_games_count(self):
        global Game
        return Game.objects.count()

    def get_games_collecting_count(self):
        global Game
        return Game.objects.filter(
            getting_basic_information = True
        ).count()

    def exit(self):
        if self.game is not None:
            if not self.TESTING:
                self.game.getting_basic_information = False
                self.game.save()
        # if self.browser:
        #     self.browser.quit()
        self.log_info("Execução finalizada. Saindo...")

    def waiting_message(self, msg, delay):
        global time
        for i in range(delay, -1, -1):
            sys.stdout.flush()
            sys.stdout.write((b'\x08' * self.statusMsgLen).decode())
            statusMsg = msg + ' ' + str(i) + ' segundo(s). '
            self.statusMsgLen = len(statusMsg)
            sys.stdout.write(statusMsg)
            for i in range(4):
                sys.stdout.write(next(self.spinner))
                sys.stdout.flush()
                sys.stdout.write('\b')
                time.sleep(0.25)
        sys.stdout.flush()
        sys.stdout.write((b'\x08' * self.statusMsgLen).decode())
        sys.stdout.write((' ' * self.statusMsgLen).decode())
        sys.stdout.write((b'\x08' * self.statusMsgLen).decode())

    def spinning_cursor(self):
        while True:
            for cursor in '|/-\\':
                yield cursor

    def count_game_collected_mods(self, id):
        global Mod
        return Mod.objects.filter(game_id = id).count()

    def get_game_by_id(self, game_id):
        return Game.objects.get(id = game_id)

    def get_mod_from_litag(self, litag):
        global formatDescribedDate

        mod = Mod()

        mod.name = litag.find('div', {'class': 'tile-content'}).h3.text
        mod.url = litag.find('a', {'class': 'mod-view'}, href=True, text=True)['href']

        mod.original_upload = formatDescribedDate(
            litag.find('div', {'class': 'meta clearfix'})
                    .find('time', {'class': 'date'}).text.replace("Uploaded: ", '').replace('\n', '')
        )

        mod.last_upload_date = formatDescribedDate(
            litag.find('div', {'class': 'date'}).text.replace("Last Update: ", '')
        )

        divcategory = litag.find('div', {'class': 'category'}).find('a', href=True)
        mod.url_nexus_category = divcategory['href']
        mod.nexus_category = divcategory.text

        div_real_author = litag.find('div', {'class': 'realauthor'})
        div_author = litag.find('div', {'class': 'author'})
        a = div_author.find_all('a', href=True)
        p = litag.find('p', {'class': 'desc'})

        uls = litag.find('div', {'class': 'tile-data'}).find('ul', {'class': 'clearfix'})

        span = uls.find('li', {'class': 'sizecount inline-flex'}).find('span', {'class': 'flex-label'})
        if span.text.strip(" ") == "--":
            mod.amount_files = 0
        else:
            mod.amount_files = tranformationOfComputerMeasureUnit(span.text)

        span = uls.find('li', {'class': 'endorsecount inline-flex'}).find('span', {'class': 'flex-label'})
        if span.text.strip(" ") == "--":
            mod.amount_endorsements = 0
        else:
            mod.amount_endorsements = tranformationAmount(span.text)

        span = uls.find('li', {'class': 'downloadcount inline-flex'}).find('span', {'class': 'flex-label'})
        if span.text.strip(" ") == "--":
            mod.amount_total_dls = 0
        else:
            mod.amount_total_dls = tranformationAmount(span.text)
        return mod

    def remove_ads(self):
        if self.browser:
            remove_ads = """
                var ads = document.getElementsByClassName('video-ad clearfix');
                if(ads && ads.length > 0){
                    ads[0].remove();
                    return true;
                }
                return false;
            """
            self.browser.execute_script(remove_ads)

    def print_msg(self,msg,end='\n'):
        global sys
        sys.stdout.write(str(msg))
        sys.stdout.write(end)
        sys.stdout.flush()

    def exit_on_error(self):
        if self.game:
            self.game.getting_basic_information = False
            self.game.save()
        if self.browser:
            self.browser.quit()

    def count_all_games_amount_mods(self):
        global Game
        return int(Game.objects.aggregate(Sum('amount_mods')).get('amount_mods__sum'))

    def count_all_games_collected_mods(self):
        global Mod
        return Mod.objects.count()

    def clear(self):
        global system
        global name
        # for windows
        if name == 'nt':
            _ = system('cls')
        # for mac and linux(here, os.name is 'posix')
        else:
            _ = system('clear')

    def print_progressBar(self, i, max=100, pre="", post="", size=40, progress_len=0):
        j = round(100 * float(i)/float(max))
        char = '█'
        char2 = '▒'

        sys.stdout.write((b'\x08' * progress_len).decode())
        bar = pre + " " + char*int(size*(j/100)) + char2*(size - int(size*(j/100))) + " " + str(round(j,0)) + "% " + post
        progress_len = len(bar)
        sys.stdout.write(bar)
        sys.stdout.flush()

    def get_progress_bar(self, i, max=100, pre="", post="", size=10, progress_len=0):
        j = round(100 * float(i)/float(max))
        char = '█'
        char2 = '▒'

        # return pre + " " + bcolors.OKGREEN + char*int(size*(j/100)) + bcolors.ENDC + char2*(size - int(size*(j/100))) + " " + str(round(j,0)) + "% " + post
        return pre + " " + bcolors.OKGREEN + char*int(size*(j/100)) + bcolors.ENDC + char2*(size - int(size*(j/100))) + " " + "%.0f" % j + "% " + post

    def get_time_str(self, formmater = '%d-%m-%Y %H:%M:%S'):
        global datetime
        global timezone

        zone = 'America/Bahia'
        date_time = datetime.now(timezone(zone)).strftime(formmater)
        return date_time

    def log_info(self, msg):
        time_stamp = self.get_time_str(self.TIME_FORMATTER)
        print(bcolors.WARNING + time_stamp + ' INFO: ' + bcolors.ENDC + msg)

    def log_error(self, msg):
        time_stamp = self.get_time_str(self.TIME_FORMATTER)
        print(bcolors.FAIL + time_stamp + ' ERRO: ' + msg + bcolors.ENDC)

    def log_success(self, msg):
        time_stamp = self.get_time_str(self.TIME_FORMATTER)
        print(bcolors.OKGREEN + time_stamp + ' OKEY: ' + msg + bcolors.ENDC)

    def get_url(self, url, no_images, pages):
        self.browser = getBrowser(no_images)
        self.browser.set_page_load_timeout(self.LOADING_TIMEOUT)
        self.WAIT = WebDriverWait(self.browser, self.LOADING_TIMEOUT)
        self.browser.get(url)
        return

    def wait_site_loading(self, url):
        site_loaded = False
        attempts = 0
        max_attempts = self.LOADING_ATTEMPTS
        while site_loaded and attempts < max_attempts:
            attempts += 1
            try:
                self.WAIT.until(
                    EC.visibility_of_element_located((By.CSS_SELECTOR, "#acc-advanced-collection > dl > dt > span.refine-info"))
                )
                get_mods_count = 'document.querySelector("#acc-advanced-collection > dl > dt > span.refine-info").innerText;'
                mods_count = self.browser.execute_script("return " + get_mods_count)
                if mods_count and mods_count != "Found 0 results.":
                    jump_element = self.WAIT.until(
                        EC.element_to_be_clickable((By.ID, "select2-page_t-container"))
                    )
                    if jump_element:
                        site_loaded = True
            except Exception as e:
                if attempts == max_attempts:
                    self.log_error("wait_site_loadingLoading:" + url + " failed, maximum number of attempts reached. " + str(e))
                    traceback.print_exc()
                else:
                    self.log_info("wait_site_loading():" + url + " failed, attempt:" + str(attempts) + ".")
        return site_loaded

    # TODO remover após testes
    def wait_site_loading_old(self, pages, url):
        global EC
        wait = WebDriverWait(self.browser, self.LOADING_TIMEOUT)
        loaded = False
        attempts = 0
        if pages > 5:
            while (attempts < self.LOADING_ATTEMPTS) and not loaded:
                attempts += 1
                try:
                    wait.until(
                        EC.element_to_be_clickable((By.CLASS_NAME, "icon-arrow-thin"))
                    )
                    loaded = True
                # except TimeoutException:
                    # self.log_error("Tentativa:" + str(attempts) + " Timeout ao carregar a página" + str(url) + ".")

                except Exception as e:
                    self.browser.refresh()
                    self.log_error("Tentativa:" + str(attempts) + ". Erro ao carregar a página" + str(url) + ".")

        elif pages >= 2 and pages <=5:
           pass
            # TODO Corrigir código abaixo
        return loaded

    def get_next_game(self):
        game = Game.objects.filter(
            getting_basic_information=False,
            capturing_mods_finalized=False,
        ).order_by('id')

        if game and len(game) > 0:
            return game[0]
        else:
            return None

    def page_changed_to(self, page_index):
        page_changed = False
        end_time = time.time() + self.LOADING_TIMEOUT
        try:
            while not page_changed and time.time() < end_time:
                curent_page = self.browser.execute_script(
                    "return document.getElementsByClassName('page-selected mfp-prevent-close')[0].innerText;"
                )
                if curent_page == str(page_index):
                    page_changed = True
                time.sleep(0.5)
        except Exception as e:
            self.log_error("page_changed_to() Failed. " + str(e))
            traceback.print_exc()
        return page_changed

    #  TODO remover após testes
    '''
    def wait_page_loading(self, page_index):
        # attempts = 0
        global time
        # loading = True
        loaded = False

        # while loading and attempts < self.LOADING_ATTEMPTS:
            # self.print_msg(".", end="")
            # attempts += 1
        end_time = time.time() + self.LOADING_TIMEOUT

        # while loading and time.time() < end_time:
        while not loaded and time.time() < end_time:
            self.print_msg("#", end="")
            try:
                curent_page = self.browser.execute_script(
                    "return document.getElementsByClassName('page-selected mfp-prevent-close')[0].innerText;"
                )
                if curent_page == str(page_index):
                    # loading = False
                    loaded = True
                time.sleep(0.5)
            except Exception as e:
                self.log_error(str(e))
                traceback.print_exc()
        return loaded
    '''

    def go_to_page(self, page_index, pages):
        global time
        page_changed = False
        attempts = 0
        loading = True
        max_attempts = self.LOADING_ATTEMPTS

        while loading and not page_changed and attempts < max_attempts:
            if attempts > 0:
                self.log_success("Page Refresh()")
                self.browser.refresh()
            attempts += 1

            if pages > 5:
                while not page_changed:
                    try:
                        go_page =  "return window.RH_ModList.Send('page', " + str(page_index) + ");"
                        self.browser.execute_script(go_page)

                        if self.page_is_ready and self.page_changed_to(page_index):
                            page_changed = True
                    except Exception as e:
                        traceback.print_exc()
                        if attempts == max_attempts:
                            self.log_error("go_to_page() Failed. " + str(e))
                            # traceback.print_exc()
            else:
                try:
                    self.page_is_ready()
                    page_changed = self.jump_to_page(page_index)

                    '''
                    loading_wheel = self.browser.find_elements_by_class_name('nexus-ui-blocker')
                    if loading_wheel:
                        self.WAIT.until(
                            EC.invisibility_of_element((By.CLASS_NAME, 'nexus-ui-blocker'))
                        )
                    else:
                        jump = self.browser.find_element_by_id("select2-page_t-container")
                        if not jump:
                            self.log_info("Jump, Not Found")
                        else:
                            #TODO - tratar : stale element reference: element is not attached to the page document
                            time.sleep(2)
                            jump = self.browser.find_element_by_id("select2-page_t-container")
                            jump.click()

                            loading_wheel = self.browser.find_elements_by_class_name('nexus-ui-blocker')
                            if loading_wheel:
                                self.WAIT.until(
                                    EC.invisibility_of_element((By.CLASS_NAME, 'nexus-ui-blocker'))
                                )
                            else:
                                get_jump_input = 'document.querySelector("body > span > span > span.select2-search.select2-search--dropdown > input");'
                                jump_input = self.browser.execute_script('return ' + get_jump_input)
                                if jump_input:
                                    jump_input.clear()
                                    jump_input.click()
                                    jump_input.send_keys(str(page_index))
                                    jump_input.send_keys(Keys.ENTER)

                                    if self.page_is_ready:
                                        if self.page_changed_to(page_index):
                                            page_changed = True
                                        else:
                                            self.log_info("Page NOt Changed.")
                                    else:
                                        self.log_info("Page NOt Ready.")
                                else:
                                    self.log_info("jump_input Not Found.")
                '''
                except Exception as e:
                    traceback.print_exc()
                    if attempts == max_attempts:
                        self.log_error("go_to_page() Failed, maximum number of attempts reached. " + str(e))
                        # traceback.print_exc()
                    else:
                        self.log_info("go_to_page() Failed - attempt:" + str(attempts) + ".")
        return page_changed

    def jump_to_page(self, page_index):
        jump_elem_id = 'select2-page_t-container'
        get_jump_input = 'document.querySelector("body > span > span > span.select2-search.select2-search--dropdown > input");'

        jumping = True
        jumped = False
        end_time = time.time() + self.LOADING_TIMEOUT
        max_attempts = self.LOADING_ATTEMPTS
        attempts = 0

        while jumping and time.time() < end_time and attempts < max_attempts:
            try:
                attempts += 1

                self.WAIT.until(
                    EC.visibility_of_element_located((By.ID, jump_elem_id))
                )

                jump = self.browser.find_element_by_id("select2-page_t-container")
                if not jump:
                    self.log_info("Jump, Not Found")
                else:
                    #TODO - tratar : stale element reference: element is not attached to the page document
                    jump.click()

                    jump_input = self.browser.execute_script('return ' + get_jump_input)
                    if jump_input:
                        # jump_input.clear()
                        # jump_input.click()
                        jump_input.send_keys(str(page_index))
                        jump_input.send_keys(Keys.ENTER)

                        if self.page_is_ready:
                            if self.page_changed_to(page_index):
                                jumped = True
                                jumping = False
                                self.log_success("jump.click() -> OK!")
                            else:
                                self.log_info("Page Not Changed 2.")
                        else:
                            self.log_info("Page Not Ready 2.")
                    else:
                        self.log_info("jump_input Not Found 2.")

            except Exception as e:
                traceback.print_exc()
                if attempts == max_attempts:
                    self.log_error("jump_to_page() Failed, maximum number of attempts reached. " + str(e))
                    # traceback.print_exc()
                else:
                    self.log_info("jump_to_page() Failed - attempt:" + str(attempts) + ".")
            time.sleep(0.5)
        return jumped

    def wait_loading_mods(self, mods_count):
        get_mods_tiles = "return document.getElementsByClassName('mod-tile');"
        mods_tiles = None
        start_time = time.time()
        loading = True
        loaded = False
        while loading:
            mods_tiles = self.browser.execute_script(get_mods_tiles)
            if (mods_tiles and len(mods_tiles) >= mods_count):
                loading = False
                loaded = True
            elif time.time() > (start_time + self.LOADING_TIMEOUT):
                loading = False
            else:
                time.sleep(0.5)
        return loaded

    def order_pages_by_date(self):

        if self.ORDER_PAGE_ATTEMPTS >= self.LOADING_ATTEMPTS + 6:
            print("")
            self.log_error("order_pages_by_date() - Max Attempts.")
            return False

        if not self.page_is_ready():
            print("")
            self.log_error("order_pages_by_date() - Page isn't ready.")
            return

        self.ORDER_PAGE_ATTEMPTS += 1

        if not self.is_filter_loaded():
            print("")
            self.log_error("order_pages_by_date() - Date filter not loaded.")
            return False

        if not self.is_filter_changed():
            print("")
            self.log_error("order_pages_by_date() - Date filter not changed.")
            return False

        if not self.page_is_ready():
            print("")
            self.log_error("order_pages_by_date() - Page isn't ready [2].")
            return False

        if not self.is_order_loaded():
            print("")
            self.log_error("order_pages_by_date() - Order filter not loaded.")
            return False

        if not self.is_order_changed():
            print("")
            self.log_error("order_pages_by_date() - Order filter not changed.")
            return False

        if not self.page_is_ready():
            print("")
            self.log_error("order_pages_by_date() - Page isn't ready [3].")
            return False

        return True

    def page_is_ready(self):
        ready = False
        attempts = 0
        max_attempts = self.LOADING_ATTEMPTS
        while not ready and (attempts < max_attempts):
            attempts += 1
            try:
                loading_wheel_class = 'nexus-ui-blocker'
                loading_wheel = self.browser.find_elements_by_class_name(loading_wheel_class)
                if len(loading_wheel) > 0:
                    self.WAIT.until(
                        EC.invisibility_of_element((By.CLASS_NAME, loading_wheel_class))
                    )
                ready = True
            except Exception as e:
                print("")
                if attempts == max_attempts:
                    self.log_info("page_is_ready() - Failed, maximum number of attempts reached. " + str(e))
                    traceback.print_exc()
                else:
                    self.log_info("page_is_ready() - Waiting page load failed - attempt:" + str(attempts) + ".")
            time.sleep(0.5)

        # if not ready:
        #     print("")
        #     self.log_info("page_is_ready() - Page loading failed.")
        return ready

    def is_filter_loaded(self):
        loading = True
        loaded = False
        attempts = 0
        while loading and not loaded:
            try:
                attempts += 1
                self.WAIT.until(
                    EC.element_to_be_clickable((By.ID, "select2-sort_by-container"))
                )
                loaded = True
            except Exception:
                if attempts < self.LOADING_ATTEMPTS:
                    # self.log_info("is_filter_loaded Attempt " + str(attempts) + " refresh.")
                    self.browser.refresh()
                else:
                    traceback.print_exc()
                    loading = False
        return loaded

    def is_filter_changed(self):
        # TODO Adicionar while attempts 3
        filter = self.browser.find_element_by_id('select2-sort_by-container')
        if not filter:
            # self.log_error("Filter Not found")
            return False
        else:
            filter.click()
            if not self.is_filter_search_loaded():
                # self.log_error("Filter search not Loaded")
                return False

            search_input = self.browser.execute_script(
                "return document.getElementsByClassName('select2-search select2-search--dropdown')[0];"
            )
            if not search_input:
                # self.log_error("Filter input Not found")
                return False

            input = self.browser.execute_script(
                "return document.getElementsByClassName('select2-search select2-search--dropdown')[0].firstChild;"
            )
            input.send_keys("Date published")
            input.send_keys(Keys.ENTER)

            return True

    def is_filter_search_loaded(self):
        loading = True
        loaded = False
        attempts = 0
        end_time = time.time() + self.LOADING_TIMEOUT
        while loading and not loaded:
            attempts += 1
            while (time.time() < end_time) and (not loaded) and (attempts < self.LOADING_ATTEMPTS):
                search_input = self.browser.execute_script(
                    "return document.getElementsByClassName('select2-search select2-search--dropdown')[0];"
                )
                if search_input:
                    loaded = True
                else:
                    time.sleep(0.5)
            if loaded:
                return True
            if attempts >= self.LOADING_ATTEMPTS:
                loading = False
            else:
                if self.ORDER_PAGE_ATTEMPTS >= self.LOADING_ATTEMPTS:
                    print("")
                    self.log_info("Search Attempt " + str(self.ORDER_PAGE_ATTEMPTS) + " refresh.")
                    self.browser.refresh()
                    return self.order_pages_by_date()
        return loaded

    def is_order_loaded(self):
        loading = True
        loaded = False
        attempts = 0
        while loading and not loaded:
            try:
                attempts += 1
                self.WAIT.until(
                    EC.element_to_be_clickable((By.ID, "select2-order-container"))
                )
                loaded = True
            except Exception:
                if attempts < self.LOADING_ATTEMPTS:
                    # self.log_info("is_order_loaded Attempt " + str(attempts) + " refresh.")
                    self.browser.refresh()
                    return self.order_pages_by_date()
                else:
                    traceback.print_exc()
                    loading = False
        return loaded

    def is_order_changed(self):
        self.WAIT.until(
            EC.element_to_be_clickable((By.ID, "select2-order-container"))
        )

        filter = self.browser.find_element_by_id('select2-order-container')
        filter.click()

        id_string = "li[id$='-ASC']"
        get_order_asc = 'return document.querySelectorAll("' + id_string + '")[0];'
        order_asc = self.browser.execute_script(get_order_asc)

        if not order_asc:
            # self.log_error("Order ASC not Found")
            return False

        order_asc.click()

        return True

    def test_page_order_by_date(self):
        global time
        site = "https://www.nexusmods.com/oblivion/mods"
        # site = "https://www.nexusmods.com/aliensvspredator2/mods"

        hdr = {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
        }
        r = urllib2.Request(site, headers=hdr)
        web = urllib2.urlopen(r)
        soup = BeautifulSoup(web.read(), 'lxml')

        list_span = soup.find_all('span', {'class' :'refine-info'})
        print(list_span)
        for span in list_span:
            if span.text.startswith("Found"):

                res = [int(i) for i in span.text.split() if i.isdigit()]

                # amount_mods = int(filter(text.isdigit, text))
                print("Mods:" + str(res))
        return

        # Pagination
        pagination = None
        script = soup.find_all("script")
        if script:
            for aux2 in script:
                if '"page"' in aux2.text:
                    pagination = getPagingNumber(aux2.string)
                    break
        if not pagination:
            self.log_info("O Game:" + str(self.game.domain_name) + " não possui Mod's.")
            self.game.capturing_mods_finalized = True
            self.game.save()
            self.exit_on_error()
            return
        pages = int(pagination[-1])

        if not pages:
            self.log_info("Without Pages")
            return
        self.get_url(site, True, pages)

        ordered = self.order_pages_by_date()
        if not ordered:
            self.log_error("Order Fail")
            self.ORDER_PAGE_ATTEMPTS = 0
            return
        self.log_success("Order OK")
        time.sleep(15)
        return

    def order_is_endorsements(self):
        if self.is_filter_loaded():
            filter = self.browser.find_element_by_id('select2-sort_by-container')
            if filter and filter.get_attribute("innerText") == 'Endorsements':
                return True
        return False

    def test_pagination(self):
        global time
        # games_list = [894, 802, 203, 64, 606, 672, 42, 475, 91, 53, 43, 726, 703, 884, 398, 45, 10]
        games_list = [894, 802, 203, 64, 606, 672, 475, 91, 53, 43, 726, 703, 884, 398]
        # games_list = [53]
        games = Game.objects.filter(id__in = games_list)

        for game in games:
            site = game.nexusmods_url + "/mods"

            soup = self.soap_collect(site)
            pagination = self.get_pagination(soup)

            if not pagination:
                self.log_info("O Game:" + str(game.domain_name) + " não possui Mod's.")
                return

            pages = int(pagination[-1])

            if not pages:
                self.log_info("Without Pages")
                return

            msg = "Game " + str(game.id) + ":" + str(game.domain_name) + " pages:" + str(pages) + " - 1 "
            self.print_msg(msg, "")

            if pages > 1:
                self.get_url(site, True, pages)

            if not self.page_is_ready():
                return

            self.remove_ads()
            for page_index in range(1, pages + 1):
                self.remove_ads()
                print("")
                if page_index != 1:
                    # self.log_info("Page:" + str(page_index))
                    if not self.go_to_page(page_index, pages):
                        self.log_error("Error on Page:" + str(page_index))
                        return
                    else:
                        self.log_success("Page: " + str(page_index))

                    # msg = str(page_index) + " "
                    # self.print_msg(msg, end="")
            print("")
            if self.browser:
                self.browser.quit()

    def soap_collect(self, url):
        hdr = {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
        }

        r = urllib2.Request(url, headers=hdr)
        web = urllib2.urlopen(r)
        return BeautifulSoup(web.read(), 'lxml')

    def get_pagination(self, soup):
        pagination = None
        script = soup.find_all("script")
        if script:
            for aux2 in script:
                if '"page"' in aux2.text:
                    pagination = getPagingNumber(aux2.string)
                    break
        return pagination
