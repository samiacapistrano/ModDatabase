# -*- coding: utf-8 -*-

import atexit
import bs4
import os
import re
import sys
import time
import traceback
import warnings


from pprint import pprint

from bs4 import BeautifulSoup
from django.db import IntegrityError

from pprint import pprint

from scripts.Logger import Logger
from scripts.function_util import setDateTimeNow
from scripts.function_util import tranformationAmount
from scripts.function_util import getHeadlessBrowser

from manager.models import AmountInfoMod
from manager.models import Mod
from manager.models import Tag

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

reload(sys)
sys.setdefaultencoding("utf8")

warnings.filterwarnings("ignore", category=RuntimeWarning)

ivan_dell = False
ivan_pc = False
samia = True
ufba = False
test = False

TESTING = False
mod = None
logger = Logger()
all_mods_count = 0
progress_msg_len = 0
progress_msg_len_test = 0
complete_mods_count = 0
browser = None

def stop_mod_capturing(mod):
    global TESTING
    if not TESTING:
        if mod:
            mod.mod_running = False
            mod.save()
    return

def exit():
    global stop_mod_capturing
    global mod
    global browser
    if browser:
        browser.quit()
    if mod :
        stop_mod_capturing(mod)
    print "Saindo..."
    return

atexit.register(exit)

def count_complete_mods():
    global Mod
    global ivan_dell
    global ivan_pc
    global samia
    global ufba
    global test

    # Mod id 1..57500
    if ivan_dell == True:
        return Mod.objects.filter(
            capturing_amount_mod = True,
            id__range=(1, 57500)
        ).count()

    # Mod id 57501..115000
    elif samia == True:
        return Mod.objects.filter(
            capturing_amount_mod = True,
            id__range=(57501, 115000)
        ).count()

    # Mod id 115001..172500
    elif ufba == True:
        return Mod.objects.filter(
            capturing_amount_mod = True,
            id__range=(115001, 172500)
        ).count()

    # Mod id > 172500
    elif ivan_pc == True:
        return Mod.objects.filter(
            capturing_amount_mod = True,
            id__gt = 172500
        ).count()
    else:
        return Mod.objects.filter(capturing_amount_mod = True).count()

def count_all_mods():
    global Mod
    global ivan_dell
    global ivan_pc
    global samia
    global ufba
    global test

    # Mod id 1..57500
    if ivan_dell == True:
        return Mod.objects.filter(
            id__range=(1, 57500)
        ).count()

    # Mod id 57501..115000
    elif samia == True:
        return Mod.objects.filter(
            id__range=(57501, 115000)
        ).count()

    # Mod id 115001..172500
    elif ufba == True:
        return Mod.objects.filter(
            id__range=(115001, 172500)
        ).count()

    # Mod id > 172500
    elif ivan_pc == True:
        return Mod.objects.filter(
            id__gt = 172500
        ).count()
    else:
        return Mod.objects.count() 

def print_status():
    global all_mods_count
    global progress_msg_len
    global complete_mods_count

    status_count = "%3d" % complete_mods_count + "/" + "%3d" % all_mods_count
    progress = logger.get_progress_bar(complete_mods_count, all_mods_count, 40, True, " Mod's", " " + status_count) + "  ID:" + str(mod.id) + "      " # + mod[0].url
    logger.print_inline(progress, progress_msg_len)
    progress_msg_len = len(progress) - 5
    return

def get_next_incomplete_mod():
    global ivan_dell
    global ivan_pc
    global samia
    global ufba
    global test

    sql_test = '''
        SELECT
            m.*
        FROM manager_mod as m
        JOIN manager_collectmod as cm ON cm.id_mod_id = m.id
        WHERE
            m.capturing_amount_mod = False
            AND m.mod_running = False
            AND m.error is not TRUE
        ORDER BY cm.collect_order
        LIMIT 1;
    '''
    mods = None
    if test == True:
        mods = Mod.objects.raw(sql_test)[:]

    # Mod id 1..57500
    elif ivan_dell == True:
        mods = Mod.objects.filter(
            capturing_amount_mod = False,
            mod_running = False,
            id__range=(1, 57500)
        ).exclude(error = True).order_by('id')[:1]

    # Mod id 57501..115000
    elif samia == True:
        mods = Mod.objects.filter(
            capturing_amount_mod = False,
            mod_running = False,
            id__range=(57501, 115000)
        ).exclude(error = True).order_by('id')[:1]

    # Mod id 115001..172500
    elif ufba == True:
        mods = Mod.objects.filter(
            capturing_amount_mod = False,
            mod_running = False,
            id__range=(115001, 172500)
        ).exclude(error = True).order_by('id')[:1]

    # Mod id > 172500
    elif ivan_pc == True:
        mods = Mod.objects.filter(
            capturing_amount_mod = False,
            mod_running = False,
            id__gt = 172500
        ).exclude(error = True).order_by('id')[:1]

    if mods and len(mods) > 0:
        return mods[0]

    return None

def get_mod_page_soup2(mod, browser):

    DEBUG = False
    TESTING = False

    attempts = 0
    soup = None
    while True:
        try:
            attempts += 1

            if attempts >= 3:
                logger.error("\nFalha ao carregar página do mod. Url:" + mod.url + ".")
                break

            url = mod.url

            WAIT = WebDriverWait(browser, 60)

            browser.set_page_load_timeout(90)

            # if DEBUG:
            #     logger.info("\nLoading Page:", url)

            browser.get(url)

            WAIT.until(
                EC.url_to_be(url)
            )

            # WAIT.until(
            #     lambda driver: browser.execute_script("return document.readyState") == "complete"
            # )

            # if DEBUG:
            # logger.info("Page Loaded")

            soup = BeautifulSoup(browser.page_source, "html.parser")

            # check for errors on Mod Page
            div_error = soup.find("div", attrs={"class": "info warning clearfix site-notice"})
            if div_error and len(div_error) > 0:
                error_msg = u''.join(div_error.findAll(text=True))
                error_msg = error_msg.encode().strip().replace('\n',' ')
                logger.error("\nFalha ao coletar dados do Mod ID:" + str(mod.id) + ".")
                logger.error(error_msg)
                mod.error_msg = error_msg
                mod.error = True
                if not TESTING:
                    mod.save()
                break

            #  Awaiting stats load
            tries = 0
            loaded = True
            while True:
                tries += 1
                if tries > 240:
                    break

                list_stat_item = browser.find_elements_by_class_name('statitem')
                if not list_stat_item or len(list_stat_item) == 0:
                    # logger.info("List Empty")
                    time.sleep(0.5)
                    soup = BeautifulSoup(browser.page_source, "html.parser")
                    continue

                loaded = True
                for stat_item in list_stat_item:
                    div_value = stat_item.find_elements_by_class_name('stat')
                    if div_value and len(div_value) > 0 and div_value[0]:
                        if div_value[0].text.strip() == ("--"):
                            # if DEBUG:
                            #     logger.info("value: '--'")
                            loaded = False
                            break

                if loaded == False:
                    soup = BeautifulSoup(browser.page_source, "html.parser")
                    time.sleep(0.5)
                    continue
                break

            if loaded == False:
                time.sleep(0.5)
                soup = BeautifulSoup(browser.page_source, "html.parser")
                continue

            # if DEBUG:
            # logger.success("Stats Loaded")
            # for stat_item in list_stat_item:
            #     div_value = stat_item.find_elements_by_class_name('stat')
            #     if div_value and len(div_value) > 0:
            #         logger.info(div_value[0].text.strip())
            break
        except TimeoutException as e:
            if attempts >= 3:
                logger.error("\nFalha ao acessar página. Url:" + url + ".")
                logger.error("Exception " + str(type(e)) + " {}".format(e))
                break
        except Exception as e:
            if attempts >= 3:
                logger.error("\nException " + str(type(e)) + " {}".format(e))
                break
    return soup

def collect_amount_info():

    TESTING = False
    DEBUG = False

    global BeautifulSoup
    global Mod
    global mod
    global traceback
    global browser

    global count_all_mods
    global logger
    global all_mods_count
    global complete_mods_count

    logger.info("\n ------------------- Coleta AmountInfoMod Iniciada ------------------- ")

    all_mods_count = count_all_mods()
    complete_mods_count = count_complete_mods()

    browser = None

    count = 0

    while True:
        try:

            mod_db = get_next_incomplete_mod()
            if mod_db is None:
                break

            mod = mod_db
            print_status()
            # if DEBUG:
            #     logger.info("Mod Id:", mod_db.id)

            # Status
            if count == 0 or count == 11:
                if browser:
                    browser.quit()
                browser = getHeadlessBrowser()
                browser.set_page_load_timeout(90)
                count = 1
                complete_mods_count = count_complete_mods()
            else:
                complete_mods_count += 1
                count += 1
            

            # time.sleep(0.25)
            collect_amount_info_mod(mod_db, browser)

        except Exception as e:
            stop_mod_capturing(mod)
            if browser:
                browser.quit()
            logger.error("Exception " + str(type(e)) + " {}".format(e))
            logger.error("\nFalha na coleta de Amount Info Mod. id:", 1)
            traceback.print_exc()
            return

    logger.info("\n ------------------------- Coleta Finalizada -------------------------")
    if browser:
        browser.quit()

def amount_info_test():
    global collect_amount_info_mod
    mod = Mod.objects.get(id = 11945)
    browser = getHeadlessBrowser()
    browser.set_page_load_timeout(90)
    collect_amount_info_mod(mod, browser)

def collect_amount_info_mod(mod, browser):
    TESTING = False
    DEBUG = False

    global BeautifulSoup
    global Mod
    global traceback
    global tranformationAmount
    global count_all_mods
    global logger
    global all_mods_count
    global complete_mods_count

    # if not TESTING:
    mod.mod_running = True
    mod.save()

    try:
        if not mod.url:
            logger.info("\nMod with id:" + str(mod.id) + " not have Url.")
            mod.error = True
            mod.error_msg = "Mod without Url"
            # if not TESTING:
            mod.save()
            stop_mod_capturing(mod)
            return

        # Get mod page soup
        get_mod_page_soup2(mod, browser)
        soup = BeautifulSoup(browser.page_source, "html.parser")

        if mod.error:
            stop_mod_capturing(mod)
            return

        # Check network Error
        if not soup or not soup.getText():
            logger.info("\nPage Request Failed. Mod with id:" + str(mod.id) + " Url:" + mod.url)
            logger.wait_message("New attempt in ", 30, post=" seconds.")
            stop_mod_capturing(mod)
            return

        # Ajuste Nexus_id pela URL
        mod.nexus_id_mod = mod.url.rsplit('/', 1)[-1]
        # if DEBUG:
        #     logger.info("Nexus_id_mod:", mod.nexus_id_mod)

        #  --------------------- Info Mod --------------------------
        list_stat = soup.find_all('ul', {'class': 'stats clearfix'})
        if not list_stat or len(list_stat) == 0:
            logger.info("\nMod without stats. Id:" + str(mod.id) + " stopping collect.")
            stop_mod_capturing(mod)
            return

        # logger.info("\nSaving")
        for stat in list_stat[0]:
            if isinstance(stat, bs4.element.Tag):
                text = stat.text.encode().strip("\n").split("\n")
                if text and len(text) > 1:
                    if (text[1].encode().__eq__("Unique DLs")):
                        if len(text) > 2 and (text[2].encode().strip() != ("--")):
                            mod.amount_unique_dls = int(text[2].encode().replace(",", ""))
                    elif (text[1].encode().__eq__("Total views")):
                        if len(text) > 2 and (text[2].encode().strip() != ("--")):
                            mod.amount_views = int(text[2].encode().replace(",", ""))
                    elif (text[1].__eq__("Version")):
                        if len(text) > 2 and (text[2].encode().strip() != ("--")):
                            mod.number_versions = text[2].encode()
                    elif (text[1].encode().__eq__("Endorsements")):
                        if not mod.amount_endorsements and len(text) > 2 and (text[2].encode().strip() != ("--")):
                            mod.amount_endorsements = int(text[2].encode().replace(",", ""))
                    elif (text[1].encode().__eq__("Total DLs")):
                        if not mod.amount_total_dls and len(text) > 2 and (text[2].encode().strip() != ("--")):
                            mod.amount_total_dls = int(text[2].encode().replace(",", ""))
                    # else:
                    #     print "Dado desconhecido" + str(text[1])

        list_info_file = soup.find_all("div", attrs={"id": "fileinfo"})
        if list_info_file and len(list_info_file) > 0:
            divs = list_info_file[0].findAll("div", attrs={'class': 'sideitem'})
            if divs and len(divs) > 2:
                aux_tex = divs[2].text.encode().strip("\n").split("\n")
                if aux_tex and len(aux_tex) == 2:
                    mod.created_by = aux_tex[1].encode()

        # ------------ TAGS --------------
        tags = soup.find('ul', attrs={'class': 'tags'})
        if tags and len(tags) > 0:
            for tag in tags:
                if isinstance(tag, bs4.element.Tag):
                    text4 = tag.text.encode().strip("\n").split("\n")
                    for tag1 in text4:
                        if tag1 and tag1.encode() != ' ':
                            old_tag = Tag.objects.filter(name=tag1)

                            try:
                                if old_tag and len(old_tag) > 0:
                                    # check if mod already has the tag
                                    if not mod.tag.filter(id=old_tag[0].id).exists():
                                        # if not TESTING:
                                        mod.tag.add(old_tag[0])
                                else:
                                    new_tag = Tag()
                                    new_tag.begin_date = setDateTimeNow()
                                    new_tag.name = tag1.encode()
                                    new_tag.finish_date = setDateTimeNow()
                                    # if not TESTING:
                                    new_tag.save()
                                    mod.tag.add(new_tag)
                            except IntegrityError:
                                pass
                                # logger.info("\nMod with id:" + str(mod.id) + " already has the Tag:" + str(old_tag[0].id) + ".")

        # if DEBUG:
            # logger.info("\nurl: " + str(mod.url))
            # logger.info("nexus_id_mod: " + str(mod.nexus_id_mod))
            # logger.info("amount_unique_dls: " + str(mod.amount_unique_dls))
            # logger.info("amount_views: " + str(mod.amount_views))
            # logger.info("number_versions: " + str(mod.number_versions))
            # logger.info("amount_endorsements: " + str(mod.amount_endorsements))
            # logger.info("amount_total_dls: " + str(mod.amount_total_dls))
            # logger.info("created_by: " + str(mod.created_by))
            # logger.info("tag: " + str(mod.tag))

        #  ------------------ Amount Info Mod ----------------------
        dbAmountMod = AmountInfoMod.objects.filter(id_mod_id = mod.id)
        if not dbAmountMod or (len(dbAmountMod) == 0):
            # FILES
            files_count = 0
            span_files = soup.find_all('li', {'id' :'mod-page-tab-files'})
            if len(span_files) > 0:
                span_alert = span_files[0].find_all('span', {'class' :'alert'})
                if len(span_alert) > 0:
                    files_count = int(span_alert[0].text.replace(",", "").strip())

            # IMAGES
            images_count = 0
            span_images = soup.find_all('li', {'id' :'mod-page-tab-images'})
            if len(span_images) > 0:
                span_alert = span_images[0].find_all('span', {'class' :'alert'})
                if len(span_alert) > 0:
                    images_count = int(span_alert[0].text.replace(",", "").strip())

            # VIDEOS
            videos_count = 0
            span_videos = soup.find_all('li', {'id' :'mod-page-tab-videos'})
            if len(span_videos) > 0:
                span_alert = span_videos[0].find_all('span', {'class' :'alert'})
                if len(span_alert) > 0:
                    videos_count = int(span_alert[0].text.replace(",", "").strip())

            # ARTICLES
            articles_count = 0
            span_articles = soup.find_all('li', {'id' :'mod-page-tab-articles'})
            if len(span_articles) > 0:
                span_alert = span_articles[0].find_all('span', {'class' :'alert'})
                if len(span_alert) > 0:
                    articles_count = int(span_alert[0].text.replace(",", "").strip())

            # POSTS
            posts_count = 0
            span_posts = soup.find_all('li', {'id' :'mod-page-tab-posts'})
            if len(span_posts) > 0:
                span_alert = span_posts[0].find_all('span', {'class' :'alert'})
                if len(span_alert) > 0:
                    posts_count = int(span_alert[0].text.replace(",", "").strip())

            # BUGS
            bugs_count = 0
            span_bugs = soup.find_all('li', {'id' :'mod-page-tab-bugs'})
            if len(span_bugs) > 0:
                span_alert = span_bugs[0].find_all('span', {'class' :'alert'})
                if len(span_alert) > 0:
                    bugs_count = int(span_alert[0].text.replace(",", "").strip())

            # FORUMS
            forums_count = 0
            span_forums = soup.find_all('li', {'id' :'mod-page-tab-forums'})
            if len(span_forums) > 0:
                span_alert = span_forums[0].find_all('span', {'class' :'alert'})
                if len(span_alert) > 0:
                    forums_count = int(span_alert[0].text.replace(",", "").strip())

            # if DEBUG:
            #     logger.info("\nfiles_count:", str(files_count))
            #     logger.info("images_count:", str(images_count))
            #     logger.info("videos_count:", str(videos_count))
            #     logger.info("articles_count:", str(articles_count))
            #     logger.info("posts_count:", str(posts_count))
            #     logger.info("forums_count:", str(forums_count))
            #     logger.info("bugs_count:", str(bugs_count))

            # if not TESTING:
            try:
                amountInfoMod = AmountInfoMod()
                amountInfoMod.id_mod_id = mod.id
                amountInfoMod.amount_file = files_count
                amountInfoMod.amount_imagem = images_count
                amountInfoMod.amount_video = videos_count
                amountInfoMod.amount_articles = articles_count
                amountInfoMod.amount_post = posts_count
                amountInfoMod.amount_forum = forums_count
                amountInfoMod.amount_bug = bugs_count
                amountInfoMod.save()
            except IntegrityError:
                pass
                # logger.info("\nMod já foi coletado. Id:" + str(mod.id))

        mod.capturing_amount_mod = True
        mod.mod_running = False
        # if not TESTING:
        mod.save()

    except Exception as e:
        stop_mod_capturing(mod)
        logger.error("Exception " + str(type(e)) + " {}".format(e))
        logger.error("\nFalha na coleta de Amount Info Mod. id:", 1)
        # traceback.print_exc()
        return

