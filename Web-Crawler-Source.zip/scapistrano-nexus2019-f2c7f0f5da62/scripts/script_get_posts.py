#!/usr/bin/env python
# -*- coding: utf-8 -*-

from django.utils import timezone
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.expected_conditions import visibility_of
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
from datetime import datetime
from decimal import Decimal
import requests
import bs4
import django
import ast
from selenium import webdriver
import re
import os
import urllib2,cookielib
import time
import urllib2,cookielib
from selenium.webdriver.common.keys import Keys

from django.conf import settings
from urllib3.exceptions import TimeoutError

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "mysite.settings_samia")
django.setup()

import warnings
from manager.models import Post, Mod

from scripts.function_util import addingSelenium
from scripts.function_util import getPagingNumber
from scripts.function_util import formateDateAM_PM
from scripts.function_util import movePag
from scripts.function_util import setDateTimeNow

def getContent(li):
    dict = {}
    dict['id'] = li['id']
    divs_comment_head = li.find_all('div', {'class': 'comment-head clearfix'})
    for div in divs_comment_head:
        atags_comment_head = div.find_all('a', {'class': 'comment-user'})
        dict['href'] = atags_comment_head[0]['href']
        spans_comment_details = div.find_all('span', {'class': 'comment-name'})
        atag_comment_details = spans_comment_details[0].find_all('a')
        dict['hrefuser'] = atag_comment_details[0]['href']
        dict['user'] = atag_comment_details[0].text
        #uls = div.find_all('ul', {'class': 'clearfix'})
        uls = div.find_all(lambda tag: tag.name == 'ul' and tag.get('class') == ['clearfix'])
        for ul in uls:
            lis = ul.find_all('li')
            if len(lis) != 0:
                dict['userstatus'] = lis[0].text
                dict['posts'] = lis[1].text
                dict['kudos'] = lis[2].text
        divs_comment_content = li.find_all('div', {'class': 'comment-content'})
        for div_comment in divs_comment_content:
            times = div_comment.find_all('time')
            for tim in times:
                atags = tim.find_all('a')
                for atag in atags:
                    dict['date'] = atag.text
                    comment = div_comment.find_all('div', {'class': 'comment-content-text'})
                    dict['content'] = comment[0].text
    return dict


def getContentHead(li):
    dict = {}
    dict['id'] = li['id']
    divs_comment_head = li.find_all('div', {'class': 'comment-head clearfix'})
    for div in divs_comment_head:
        atags_comment_head = div.find_all('a', {'class': 'comment-user'})
        dict['href'] = atags_comment_head[0]['href']
        spans_comment_details = div.find_all('span', {'class': 'comment-name'})
        atag_comment_details = spans_comment_details[0].find_all('a')
        dict['hrefuser'] = atag_comment_details[0]['href']
        dict['user'] = atag_comment_details[0].text
        uls = div.find_all(lambda tag: tag.name == 'ul' and tag.get('class') == ['clearfix'])
        #uls = div.find_all('ul', {'class': 'clearfix'})
        for ul in uls:
            lis = ul.find_all('li')
            if len(lis) != 0:
                dict['userstatus'] = lis[0].text
                dict['posts'] = lis[1].text
                dict['kudos'] = lis[2].text
        div_comment = li.find('div', {'class': 'comment-content'})
        times = div_comment.find_all('time')
        for tim in times:
            atags = tim.find_all('a')
            for atag in atags:
                dict['date'] = atag.text
                comment = div_comment.find_all('div', {'class': 'comment-content-text'})
                dict['content'] = comment[0].text

        break
    return dict

def salveData(dict,pai,idMod, listSavedComments, modURL):
    if dict['id'].split('-')[1] in listSavedComments:
        pass
    else:
        listSavedComments.append(dict['id'].split('-')[1])
        comment = Post()
        comment.begin_date = setDateTimeNow()
        comment.reply_comment = pai
        comment.comment_id = dict['id'].split('-')[1]
        comment.user_url = dict['hrefuser']
        comment.user_name = dict['user']
        comment.status= dict['userstatus']
        comment.posts=int(str(dict['posts'].split(" ")[0]).replace(",",""))
        comment.kudos=int(str(dict['kudos'].split(" ")[0]).replace(",",""))
        comment.content=dict['content']
        comment.date=formateDateAM_PM(dict['date'])
        comment.mod = Mod.objects.get(nexus_id_mod=idMod,url=modURL)
        comment.finish_date = setDateTimeNow()
        comment.save()
    # return comment


def getCommentPost(link,idMod, modURL):

    modObj = Mod.objects.get(nexus_id_mod=idMod,url=modURL)
    listSavedComments = []
    browser = addingSelenium(link)
    soup = BeautifulSoup(browser.page_source, 'html.parser')
    salvos=[]

    listPag = None
    datas = soup.find_all("script")
    for data in datas:
        if "$( function(){Filters_Pagination.Load(" in data.text:
            listPag = getPagingNumber(data.string)
            break

    cont = soup.find('div', {'id': 'comment-container'})
    msg = cont.find('div', {'class': 'comment-nav clearfix head-nav'})
    if msg:
        if str(msg.text.strip()).__eq__("No topics at this time"):
            forumCont = False

    if listPag:
        for page_index in listPag:
            if len(listPag) > 1 and not int(page_index) == 1:
                elemt = movePag(browser)
                try:
                    elemt[0].send_keys(page_index)
                    elemt[0].send_keys(Keys.ENTER)
                except:
                    browser.refresh()
                    time.sleep(1)
                    #adicionar algo para aguardar até que o elemento seja clicavél
                    elemt = movePag(browser)
                    elemt[0].send_keys(page_index)
                    elemt[0].send_keys(Keys.ENTER)

                if int(page_index) != 1:
                    try:
                        load = WebDriverWait(browser, 3).until(
                            EC.visibility_of_element_located((By.CLASS_NAME, "col-1-2loading-wheel")))
                    except:
                        try:
                            load = WebDriverWait(browser, 3).until(
                            EC.visibility_of_element_located((By.CLASS_NAME, "col-1-2loading-wheel")))
                        except:
                            pass

                    try:
                        load = WebDriverWait(browser, 3).until(
                            EC.invisibility_of_element((By.CLASS_NAME, "col-1-2loading-wheel")))
                    except TimeoutError:
                        try:
                            linkClick = WebDriverWait(browser, 3).until(
                                EC.invisibility_of_element((By.CLASS_NAME, "col-1-2loading-wheel")))
                        except:
                            pass


            # section > div > div.wrap.flex > div:nth-child(2) > div > div.tabcontent.tabcontent-mod-page > div.nexus-ui-blocker > div > div > div
            #/ html / body / div[2] / section / div / div[2] / div[2] / div / div[2] / div[2] / div / div / div
            soup = BeautifulSoup(browser.page_source, 'html.parser')
            ol = soup.find('ol')

            list_comment = ol.find_all('li', {'class': 'comment'})
            #print "Numero TOTAL DE COMENTARIOS: " + str(len(list_comment))
            for li in list_comment:
                if li.find_all('ol', {'class': 'comment-kids'}): #primeiro nivel quando tem respostas
                    # print li.get('id')
                    # print "tem resposta: " + str(len(li.find_all('ol', {'class': 'comment-kids'})[0].find_all('li', {'class': 'comment'})))
                    salveData(getContentHead(li), None, idMod, listSavedComments, modURL)

                    respostas = li.find_all('ol', {'class': 'comment-kids'})[0].find_all('li', {'class': 'comment'})
                    for li2 in respostas: #segundo nivel quando tem respostas
                        salveData(getContent(li2), getContent(li)['id'].split("-")[1],idMod, listSavedComments, modURL)
                        salvos.append(getContent(li2)['id'].split("-")[1])
                        # salvos_paginacao.append(getContent(li2)['id'].split("-")[1])
                else: #quando nao tem respostas
                    if getContent(li)['id'].split("-")[1] not in salvos : # and getContent(li)['id'].split("-")[1] not in salvos_paginacao:
                        salveData(getContent(li),None,idMod, listSavedComments, modURL)
                        # salvos.append(getContent(li)['id'].split("-")[1])
                    # getContent(li)
                    # print getContent(li)
    browser.close()

#https://www.nexusmods.com/Core/Libs/Common/Widgets/ModPostsTab?id=2&game_id=168

# https://www.nexusmods.com/Core/Libs/Common/Widgets/CommentContainer?tabbed=1&object_id=2&game_id=168&object_type=1&thread_id=1066787&skip_opening_post=1
# https://www.nexusmods.com/Core/Libs/Common/Widgets/CommentContainer?tabbed=1&object_id=2&game_id=168&object_type=1&thread_id=1066787&skip_opening_post=1&BH=2
#https://www.nexusmods.com/chivalry/mods/2?tab=posts
#/Core/Libs/Common/Widgets/CommentContainer?tabbed=1&object_id=2&game_id=168&object_type=1&thread_id=1066787&skip_opening_post=1
#getCommentPost('https://www.nexusmods.com/Core/Libs/Common/Widgets/CommentContainer?tabbed=1&object_id=4&game_id=168&object_type=1&thread_id=1067121&skip_opening_post=1')
#getCommentPost('https://www.nexusmods.com/Core/Libs/Common/Widgets/CommentContainer?tabbed=1&object_id=2&game_id=168&object_type=1&thread_id=1066787&skip_opening_post=1')