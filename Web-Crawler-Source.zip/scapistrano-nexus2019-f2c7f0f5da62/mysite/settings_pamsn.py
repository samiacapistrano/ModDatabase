from mysite.settings import *
CHROMEDRIVE = '/home/nexusmods/Documentos/nexusMods/nexus2019/chromedriver80'

