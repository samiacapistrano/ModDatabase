# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from manager.models import Tag, Game, Mod, Modder, File, Image, Video, TopicForum, CommentForum, Bug, BugComment, ModBaseInformationCollectToGame, AmountInfoMod
from import_export import resources
from django.contrib import admin
from import_export.admin import ImportExportModelAdmin

# Register your models here.


class ModderResource(resources.ModelResource):
    class Meta:
        model = Modder


class ModderAdmin(ImportExportModelAdmin):
    resource_class = ModderResource
    model = Modder
    list_display = ['name','amount_endorsements','amount_views','country', 'last_active_date', 'join_active_date', 'amount_friends']
    search_fields = ['name','amount_endorsements','amount_views','country', 'last_active_date', 'join_active_date', 'amount_friends']


class TagResource(resources.ModelResource):
    class Meta:
        model = Tag


class TagAdmin(ImportExportModelAdmin):
    resource_class = TagResource
    model = Tag
    list_display = ['name']
    search_fields = ['name']


class GameResource(resources.ModelResource):
    class Meta:
        model = Game


class GameAdmin(ImportExportModelAdmin):
    resource_class = GameResource
    model = Game
    list_display = ['nexus_id','name', 'domain_name', 'name_lower', 'amount_mods', 'genre', 'forum_url', 'approved_date', 'amount_downloads', 'file_count', 'nexusmods_url']
    search_fields = ['nexus_id','name', 'domain_name', 'name_lower', 'amount_mods', 'genre', 'forum_url', 'approved_date', 'amount_downloads', 'file_count', 'nexusmods_url']


class ModResource(resources.ModelResource):
    class Meta:
        model = Mod


class ModAdmin(ImportExportModelAdmin):
    resource_class = ModResource
    model = Mod
    list_display = ['name','nexus_id_mod','amount_endorsements', 'amount_unique_dls', 'amount_total_dls', 'amount_views', 'file_size', 'number_versions', 'last_upload_date',  'phase', 'get_tags', 'uploads_by','created_by','game']
    search_fields = ['name','nexus_id_mod','amount_endorsements', 'amount_unique_dls', 'amount_total_dls', 'amount_views', 'file_size', 'number_versions', 'last_upload_date', 'phase', 'tags', 'uploads_by', 'created_by','game']

    def get_tags(self, obj):
        return "\n".join([t.name for t in obj.tag.all()])

class FileResource(resources.ModelResource):
    class Meta:
        model = File


class FileAdmin(ImportExportModelAdmin):
    resource_class = FileResource
    model = File
    list_display = ['name', 'file_size', 'main_file','miscellauneous_file', 'update_file', 'optional_file','old_file','uploaded_date', 'file_size', 'unique_dls', 'total_dls', 'version' ,'mod']
    search_fields = ['name', 'file_size','main_file', 'miscellauneous_file', 'update_file','optional_file', 'old_file', 'uploaded_date','file_size', 'unique_dls', 'total_dls', 'version','mod']

class ImageResource(resources.ModelResource):
    class Meta:
        model = Image


class ImageAdmin(ImportExportModelAdmin):
    resource_class = ImageResource
    model = Image
    list_display = ['name', 'uploaded_date', 'author', 'mod','imagemUser']
    search_fields = ['name', 'uploaded_date', 'author', 'mod','imagemUser']

class VideoResource(resources.ModelResource):
    class Meta:
        model = Video


class VideoAdmin(ImportExportModelAdmin):
    resource_class = VideoResource
    model = Video
    list_display = ['name', 'uploaded_date','mod']
    search_fields = ['name', 'uploaded_date','mod']


class TopicForumResource(resources.ModelResource):
    class Meta:
        model = TopicForum


class TopicForumAdmin(ImportExportModelAdmin):
    resource_class = TopicForumResource
    model = TopicForum
    list_display = ['id','title', 'description','replies', 'views']
    search_fields = ['id','title', 'description','replies', 'views']


class CommentForumResource(resources.ModelResource):
    class Meta:
        model = CommentForum


class CommentForumAdmin(ImportExportModelAdmin):
    resource_class = CommentForumResource
    model = CommentForum
    list_display = ['id', 'comment_id', 'reply_comment_forum', 'user_url','user_name', 'content']
    search_fields = ['id', 'comment_id', 'reply_comment_forum', 'user_url','user_name', 'content']


class BugResource(resources.ModelResource):
    class Meta:
        model = Bug


class BugAdmin(ImportExportModelAdmin):
    resource_class = BugResource
    model = Bug
    list_display = ['id', 'mod', 'title', 'status','replies', 'version']
    search_fields = ['id', 'mod', 'title', 'status','replies', 'version']


class BugCommentResource(resources.ModelResource):
    class Meta:
        model = BugComment


class BugCommentAdmin(ImportExportModelAdmin):
    resource_class = BugCommentResource
    model = BugComment
    list_display = ['id', 'bug', 'name', 'status','content']
    search_fields = ['id', 'bug', 'name', 'status','content']

class ModBaseInformationCollectToGameResource(resources.ModelResource):
    class Meta:
        model = ModBaseInformationCollectToGame

class ModBaseInformationCollectToGameAdmin(ImportExportModelAdmin):
    resource_class = ModBaseInformationCollectToGameResource
    model = ModBaseInformationCollectToGame
    list_display = ['game']
    search_fields = ['game']


class AmountInfoModResource(resources.ModelResource):
    class Meta:
        model = AmountInfoMod

class AmountInfoModAdmin(ImportExportModelAdmin):
    resource_class = AmountInfoModResource
    model = AmountInfoMod
    list_display = ['id_mod']
    search_fields = ['id_mod']


admin.site.register(Bug, BugAdmin)
admin.site.register(BugComment, BugCommentAdmin)
admin.site.register(Modder, ModderAdmin)
admin.site.register(TopicForum, TopicForumAdmin)
admin.site.register(CommentForum, CommentForumAdmin)
admin.site.register(Tag, TagAdmin)
admin.site.register(Game, GameAdmin)
admin.site.register(Mod, ModAdmin)
admin.site.register(File,FileAdmin)
admin.site.register(Image,ImageAdmin)
admin.site.register(Video,VideoAdmin)
admin.site.register(ModBaseInformationCollectToGame, ModBaseInformationCollectToGameAdmin)
admin.site.register(AmountInfoMod, AmountInfoModAdmin)