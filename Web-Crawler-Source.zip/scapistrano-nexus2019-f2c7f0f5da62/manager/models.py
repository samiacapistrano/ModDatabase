# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
from django.db.models import IntegerField


class Modder(models.Model):
    name = models.CharField(max_length=2000)
    real_name = models.CharField(max_length=3000)
    amount_endorsements = models.IntegerField()
    amount_views = models.IntegerField()
    country = models.CharField(max_length=1000)
    amount_topic = models.IntegerField()
    amount_posts = models.IntegerField()
    amount_kudos = models.IntegerField()
    last_active_date = models.DateField(null=True, blank=True)
    join_active_date = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=1000)
    city = models.CharField(max_length=1000, null=True, blank=True)
    # GENRE_TYPES = (
    #     ('male', 'Male'),
    #     ('female', 'Female'),
    # )
#    genre = models.CharField(max_length=800, choices=GENRE_TYPES,null=True, blank=True)
    genre = models.CharField(max_length=800, null=True, blank=True)
    age = models.CharField(max_length=800, null=True, blank=True)
    group = models.CharField(max_length=1000,null=True, blank=True)
    amount_active_post = models.CharField(max_length=400,null=True, blank=True)
    amouny_profile_views = models.CharField(max_length=400,null=True, blank=True)
    birthday = models.DateField(null=True, blank=True)
    monitorSize = models.CharField(max_length=1000,null=True, blank=True)
    memberTitle = models.CharField(max_length=1000,null=True, blank=True)
    websiteURL = models.CharField(max_length=1000,null=True, blank=True)
    interests = models.CharField(max_length=1600,null=True, blank=True)
    currentlyPlaying = models.CharField(max_length=1000,null=True, blank=True)
    favouriteGame = models.CharField(max_length=1000,null=True, blank=True)
    processor = models.CharField(max_length=1000,null=True, blank=True)
    memory = models.CharField(max_length=1000,null=True, blank=True)
    motherboard = models.CharField(max_length=1000,null=True, blank=True)
    graphicsCard = models.CharField(max_length=1000,null=True, blank=True)
    amount_user_files = models.IntegerField(null=True, blank=True)
    amount_user_images = models.IntegerField(null=True, blank=True)
    amount_user_videos = models.IntegerField(null=True, blank=True)
    amount_friends = models.IntegerField(null=True, blank=True)
    url_perfil_modder = models.CharField(max_length=200,null=True, blank=True)
    realName = models.CharField(max_length=2000,null=True, blank=True)
    location = models.CharField(max_length=2000,null=True, blank=True)
    processor = models.CharField(max_length=2000,null=True, blank=True)
    modder_capture_finished = models.BooleanField()
    begin_date = models.DateTimeField(null=True, blank=True)
    finish_date = models.DateTimeField(null=True, blank=True)
    running = models.BooleanField(default=False)
    url_forum = models.CharField(max_length=200,null=True, blank=True)
    is_active = models.NullBooleanField() # Modder sem perfil privado
    error = models.NullBooleanField()
    error_msg = models.CharField(max_length=500,null=True, blank=True) # User not found

    def __unicode__(self):
        return self.name

    def __str__(self):
        return  self.name


class Game(models.Model):
    nexus_id = models.IntegerField()
    name = models.CharField(max_length=2000)
    domain_name = models.CharField(max_length=1000)
    name_lower = models.CharField(max_length=1000)
    amount_mods = models.IntegerField()
    genre = models.CharField(max_length=1000)
    forum_url = models.CharField(max_length=3000)
    approved_date = models.DateField()
    amount_downloads = models.IntegerField()
    file_count = models.IntegerField()
    nexusmods_url = models.CharField(max_length=1000)
    begin_date = models.DateTimeField(null=True, blank=True)
    finish_date = models.DateTimeField(null=True, blank=True)

    

    def __unicode__(self):
        return self.name

    def __str__(self):
        return  self.name

class Tag(models.Model):
    name = models.CharField(max_length=400, null=True)
    begin_date = models.DateTimeField(null=True, blank=True)
    finish_date = models.DateTimeField(null=True, blank=True)



class Mod(models.Model):
    # Dados iniciais do mods
    url = models.CharField(max_length=3000)
    name = models.CharField(max_length=3500)
    nexus_category = models.CharField(max_length=1000)
    url_nexus_category = models.CharField(max_length=1000)
    last_upload_date = models.DateTimeField()
    original_upload = models.DateTimeField()
    description = models.CharField(max_length=5000, null=True, blank=True)
    amount_endorsements = models.IntegerField()
    amount_total_dls = models.IntegerField()
    amount_files = models.PositiveIntegerField

    # Dados do mod da Url
    active_modder = models.NullBooleanField()
    created_by = models.CharField(max_length=1000, null=True, blank=True)
    uploads_by = models.ForeignKey(Modder, null=True, blank=True, related_name='link_uploaded_by')
    nexus_id_mod = models.IntegerField(null=True,blank=True)
    category = models.CharField(max_length=3000,null=True,blank=True)
    amount_unique_dls = models.IntegerField(null=True, blank=True)
    amount_views = models.IntegerField(null=True, blank=True)
    number_versions = models.CharField(max_length=1000,null=True, blank=True)
    tag = models.ManyToManyField(Tag)
    game = models.ForeignKey(Game, null=True, blank=True, related_name='link_game')
    PHASES = (
        ('establishment', 'Establishment'),
        ('reinforcement', 'Reinforcement'),
        ('adjustment', 'Adjustment'),
        ('promotion', 'Promotion'),
        ('expassion', 'Expassion'),
    )
    phase = models.CharField(max_length=1000, choices=PHASES)
    MOD_TYPES = (
        ('user_interface_customizations', 'User Interface Customizations'),
        ('game_conversion_mods', 'Game Conversion Mods'),
        ('machinima_and_art_mods', 'Machinima and Art Mods'),
        ('game_console_hacking', 'Game Console Hacking'),
    )
    type = models.CharField(max_length=1000, choices=MOD_TYPES)
    file_size = models.DecimalField(max_digits=1000, decimal_places=2, null=True, blank=True)
    capturing_basic_data_finalized = models.BooleanField()

    # amount_videos = models.IntegerField(null=True,blank=True)
    # amount_articles = models.IntegerField(null=True,blank=True)
    # captura_mod_finalizada = models.BooleanField()
    # capturing_files_finalized = models.BooleanField()
    # capturing_image_finalized = models.BooleanField()
    # capturing_video_finalized = models.BooleanField()
    # capturing_statistic_finalized = models.BooleanField()
    # capturing_article_finalized = models.BooleanField()
    # capturing_post_finalized = models.BooleanField()
    # capturing_forum_finalized = models.BooleanField()
    # capturing_bug_finalized = models.BooleanField()
    # capturing_log_finalized = models.BooleanField()

    capturing_amount_mod = models.BooleanField()
    mod_running = models.BooleanField()
    finished_execution = models.BooleanField()
    begin_date = models.DateTimeField(null=True, blank=True)
    finish_date = models.DateTimeField(null=True, blank=True)
    error = models.NullBooleanField()
    error_msg = models.CharField(max_length=500,null=True, blank=True)

    def __unicode__(self):
        return self.name

    def __str__(self):
        return  self.name

class AmountInfoMod(models.Model):
    id_mod = models.ForeignKey(Mod, primary_key=True)
    amount_file = models.IntegerField()
    amount_imagem = models.IntegerField()
    amount_video = models.IntegerField()
    amount_articles = models.IntegerField()
    amount_bug = models.IntegerField()
    amount_post = models.IntegerField()
    amount_forum = models.IntegerField()



class File(models.Model):
    name = models.CharField(max_length=2000)
    mod = models.ForeignKey(Mod, null=True,blank=True)
    main_file = models.BooleanField()
    miscellauneous_file = models.BooleanField()
    update_file = models.BooleanField()
    optional_file = models.BooleanField()
    old_file = models.BooleanField()
    uploaded_date = models.DateField()
    file_size = models.FloatField()
    unique_dls = models.FloatField()
    total_dls = models.FloatField()
    version = models.CharField(max_length=1000)
    url_download_main_file = models.CharField(max_length=3000)
    begin_date = models.DateTimeField(null=True, blank=True)
    finish_date = models.DateTimeField(null=True, blank=True)


class Image(models.Model):
    name = models.CharField(max_length=2000)
    uploaded_date = models.DateTimeField()
    author = models.CharField(max_length=2000)
    imagemUser = models.BooleanField()
    mod = models.ForeignKey(Mod, null=True, blank=True)
    url = models.CharField(max_length=200,null=True, blank=True)
    begin_date = models.DateTimeField(null=True, blank=True)
    finish_date = models.DateTimeField(null=True, blank=True)


class Video(models.Model):
    name = models.CharField(max_length=2000)
    mod = models.ForeignKey(Mod)
    uploaded_date = models.DateField()
    videosUser = models.BooleanField()
    url = models.CharField(max_length=400,null=True, blank=True)
    begin_date = models.DateTimeField(null=True, blank=True)
    finish_date = models.DateTimeField(null=True, blank=True)


class Article(models.Model):

    name = models.CharField(max_length=2000)
    link_article = models.CharField(max_length=2000)
    author = models.CharField(max_length=2000)
    link_author = models.CharField(max_length=3000)
    description = models.CharField(max_length=1000)
    amoutComentarios = models.CharField(max_length=500)
    mod = models.ForeignKey(Mod)
    uploaded_date = models.DateField()
    begin_date = models.DateTimeField(null=True, blank=True)
    finish_date = models.DateTimeField(null=True, blank=True)

class Post(models.Model):
    comment_id = models.IntegerField()
    user_url = models.CharField(max_length=2000)
    user_name = models.CharField(max_length=2000)
    status = models.CharField(max_length=2000)
    posts = models.IntegerField()
    kudos = models.IntegerField()
    content = models.TextField()
    date = models.DateTimeField()
    mod = models.ForeignKey(Mod)
    reply_comment = models.IntegerField(null=True)
    id_reply_comment = models.IntegerField(null=True)

    begin_date = models.DateTimeField(null=True, blank=True)
    finish_date = models.DateTimeField(null=True, blank=True)



class TopicForum(models.Model):
    mod = models.ForeignKey(Mod)
    title = models.CharField(max_length=2000)
    description = models.TextField()
    replies = models.IntegerField()
    views = models.IntegerField()
    author = models.CharField(max_length=2000)
    author_url = models.CharField(max_length=2000)
    last_post_date = models.DateTimeField()
    last_post_user_login = models.CharField(max_length=3000)
    last_post_user_link = models.CharField(max_length=2000)
    last_post_user_name = models.CharField(max_length=4000)
    url = models.CharField(max_length=200,null=True, blank=True)
    begin_date = models.DateTimeField(null=True, blank=True)
    finish_date = models.DateTimeField(null=True, blank=True)
    last_page_collected = models.IntegerField(null=True, blank=True)
    number_of_pages = models.IntegerField(null=True, blank=True)

    def __unicode__(self):
        return str(self.id)

    def __str__(self):
        return  str(self.id)


class CommentForum(models.Model):
    topic_forum = models.ForeignKey(TopicForum)
    comment_id = models.IntegerField()
    user_url = models.CharField(max_length=2000)
    user_name = models.CharField(max_length=2000)
    status = models.CharField(max_length=2000)
    posts = models.IntegerField()
    kudos = models.IntegerField()
    content = models.TextField()
    date = models.DateTimeField()
    reply_comment_forum = models.IntegerField(null=True)
    id_reply_comment_forum = models.IntegerField(null=True)
    begin_date = models.DateTimeField(null=True, blank=True)
    finish_date = models.DateTimeField(null=True, blank=True)
    #TODO
    last_page_collected = models.IntegerField(null=True, blank=True)
    number_of_pages = models.IntegerField(null=True, blank=True)

    def __unicode__(self):
        return str(self.id)

    def __str__(self):
        return  str(self.id)


class Endorsements(models.Model):
    mod = models.ForeignKey(Mod)
    game = models.ForeignKey(Game)
    date = models.DateTimeField()
    number_of_endorsements = models.IntegerField()
    last_update = models.DateTimeField()
    begin_date = models.DateTimeField(null=True, blank=True)
    finish_date = models.DateTimeField(null=True, blank=True)


class PageViews(models.Model):
    mod = models.ForeignKey(Mod)
    game = models.ForeignKey(Game)
    date = models.DateTimeField()
    number_of_views = models.IntegerField()
    last_update = models.DateTimeField()
    begin_date = models.DateTimeField(null=True, blank=True)
    finish_date = models.DateTimeField(null=True, blank=True)


class Downloads(models.Model):
    mod = models.ForeignKey(Mod)
    game = models.ForeignKey(Game)
    date = models.DateTimeField()
    number_of_downloads = models.IntegerField()
    last_update = models.DateTimeField()
    begin_date = models.DateTimeField(null=True, blank=True)
    finish_date = models.DateTimeField(null=True, blank=True)


class Bug(models.Model):
    mod = models.ForeignKey(Mod)
    bug_id = models.IntegerField()
    title = models.CharField(max_length=9000)
    status = models.CharField(max_length=3000)
    replies = models.IntegerField()
    version = models.CharField(max_length=4000)
    priority = models.CharField(max_length=3000)
    last_post = models.DateTimeField()
    begin_date = models.DateTimeField(null=True, blank=True)
    finish_date = models.DateTimeField(null=True, blank=True)

    def __unicode__(self):
        return str(self.id)

    def __str__(self):
        return  str(self.id)


class BugComment(models.Model):
    bug = models.ForeignKey(Bug)
    bug_comment_id = models.CharField(max_length=40)
    name = models.CharField(max_length=3000)
    status = models.CharField(max_length=3000)
    content = models.TextField()
    date = models.DateTimeField(null=True)
    begin_date = models.DateTimeField(null=True, blank=True)
    finish_date = models.DateTimeField(null=True, blank=True)



    #TODO
    last_page_collected = models.IntegerField(null=True, blank=True)
    number_of_pages = models.IntegerField(null=True, blank=True)

    def __unicode__(self):
        return str(self.id)

    def __str__(self):
        return  str(self.id)

class Changelogs(models.Model):
    mod = models.ForeignKey(Mod)
    version = models.CharField(max_length=4000)
    begin_date = models.DateTimeField(null=True, blank=True)
    finish_date = models.DateTimeField(null=True, blank=True)

    def __unicode__(self):
        return str(self.id)

    def __str__(self):
        return  str(self.id)




class ListChange(models.Model):
    changelog = models.ForeignKey(Changelogs)
    change = models.TextField()
    begin_date = models.DateTimeField(null=True, blank=True)
    finish_date = models.DateTimeField(null=True, blank=True)

    def __unicode__(self):
        return str(self.id)

    def __str__(self):
        return  str(self.id)

class AuthorActivity(models.Model):
    mod = models.ForeignKey(Mod)
    date = models.DateTimeField()
    user = models.CharField(max_length=1000)
    user_url = models.CharField(max_length=3000)
    title = models.CharField(max_length=4000)
    content = models.TextField()
    begin_date = models.DateTimeField(null=True, blank=True)
    finish_date = models.DateTimeField(null=True, blank=True)

    def __unicode__(self):
        return str(self.id)

    def __str__(self):
        return  str(self.id)

class ModPageActivity(models.Model):
    mod = models.ForeignKey(Mod)
    date = models.DateTimeField()
    user = models.CharField(max_length=1000)
    user_url = models.CharField(max_length=3000)
    title = models.CharField(max_length=4000)
    content = models.CharField(max_length=3000)
    begin_date = models.DateTimeField(null=True, blank=True)
    finish_date = models.DateTimeField(null=True, blank=True)

    def __unicode__(self):
        return str(self.id)

    def __str__(self):
        return  str(self.id)

class ModBaseInformationCollectToGame(models.Model):
    game = models.ForeignKey(Game, null=True,blank=True)
    capturing_mods_finalized = models.BooleanField()
    getting_basic_information = models.BooleanField()
    last_page_collected = models.IntegerField()
    amount_mods_real = models.IntegerField()
    number_of_pages = models.IntegerField()
    begin_date = models.DateTimeField(null=True, blank=True)
    finish_date = models.DateTimeField(null=True, blank=True)

    def __unicode__(self):
        return str(self.game)

    def __str__(self):
        return  str(self.game)


class CollectMod(models.Model):
    id_mod = models.ForeignKey(Mod, primary_key=True)

    basic_data_finished = models.BooleanField(default=False) # Coleta informações básicas concluída
    amount_items_finished = models.BooleanField(default=False) # Coleta quantidade de itens por aba concluída
    finished = models.BooleanField(default=False) # Coleta concluída
    collecting = models.BooleanField(default=False) # Coletando dados
    collect_order = models.IntegerField(null=True, blank=True, unique=True) # Ordem de coleta

    # Files tab
    files_finalized = models.BooleanField(default=False) # Aba Files concluída
    collecting_files = models.BooleanField(default=False) # Coletando dados aba Files

    # Images tab
    images_finalized = models.BooleanField(default=False) # Aba Images concluída
    images_author_finalized = models.BooleanField(default=False)
    images_user_finalized = models.BooleanField(default=False)
    images_author_last_page = models.IntegerField(null=True, blank=True) # Última página coletada Images Author
    images_user_last_page = models.IntegerField(null=True, blank=True) # Última página coletada aba Images User
    collecting_images = models.BooleanField(default=False) # Coletando dados aba Images

    # Videos tab
    videos_finalized = models.BooleanField(default=False) # Aba Videos concluída
    videos_author_finalized = models.BooleanField(default=False)
    videos_user_finalized = models.BooleanField(default=False)
    videos_author_last_page = models.IntegerField(null=True, blank=True) # Última página coletada aba Videos Author
    videos_user_last_page = models.IntegerField(null=True, blank=True) # Última página coletada aba Videos User
    collecting_videos = models.BooleanField(default=False) # Coletando dados aba Videos

    # Articles tab
    articles_finalized = models.BooleanField(default=False) # Aba Articles concluída
    articles_last_page = models.IntegerField(null=True, blank=True) # Última página coletada aba Articles
    collecting_articles = models.BooleanField(default=False) # Coletando dados aba Articles

    # Posts tab
    posts_finalized = models.BooleanField(default=False) # Aba Posts concluída
    posts_last_page = models.IntegerField(null=True, blank=True) # Última página coletada aba Posts
    collecting_posts = models.BooleanField(default=False) # Coletando dados aba Posts

    # Forum tab
    forum_finalized = models.BooleanField(default=False) # Aba Forum concluída
    forum_last_page = models.IntegerField(null=True, blank=True) # Última página coletada aba Forum
    url_last_topic = models.CharField(max_length=200,null=True, blank=True) # Url do último tópico coletado
    last_topic_page = models.IntegerField(null=True, blank=True) # Última página coletada do tópico
    collecting_forum = models.BooleanField(default=False) # Coletando dados aba Forum

    # Bugs tab
    bugs_finalized = models.BooleanField(default=False) # Aba Bugs concluída
    bugs_last_page = models.IntegerField(null=True, blank=True) # Última página coletada aba Bugs
    collecting_bugs = models.BooleanField(default=False) # Coletando dados aba Bugs

    # Logs tab
    logs_finalized = models.BooleanField(default=False) # Aba Logs concluída
    collecting_logs = models.BooleanField(default=False) # Coletando dados aba Logs
    logs_last_offset_author = models.IntegerField(null=True, blank=True) # Última página coletada do log Author
    logs_last_offset_users = models.IntegerField(null=True, blank=True) # Última página coletada do log User

    # Statistics
    statistics_finalized = models.BooleanField(default=False) # Coleta de estatísticas concluída
    collecting_statistics = models.BooleanField(default=False) # Coletando estatísticas

    begin_date = models.DateTimeField(null=True, blank=True) # início da coleta
    finish_date = models.DateTimeField(null=True, blank=True) # Término da coleta

    error = models.NullBooleanField()
    error_msg = models.CharField(max_length=500,null=True, blank=True)

class ModTabs(models.Model):
    id_mod = models.ForeignKey(Mod, primary_key=True)
    has_files = models.NullBooleanField()
    has_images = models.NullBooleanField()
    has_videos = models.NullBooleanField()
    has_articles = models.NullBooleanField()
    has_posts = models.NullBooleanField()
    has_bugs = models.NullBooleanField()
    has_forum = models.NullBooleanField()
    has_log = models.NullBooleanField()
    has_statistics = models.NullBooleanField()
